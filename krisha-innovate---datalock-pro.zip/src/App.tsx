import React, { useState, useEffect } from "react";
import { Header, TabType } from "./components/Header";
import { DataInputView } from "./components/DataInputView";
import { YAnalysisView } from "./components/YAnalysisView";
import { ComparativeAnalysisView } from "./components/ComparativeAnalysisView";
import { StratificationView } from "./components/StratificationView";
import { IsIsNotView } from "./components/IsIsNotView";
import { CapabilityView } from "./components/CapabilityView";
import { CorrelationView } from "./components/CorrelationView";
import { RegressionView } from "./components/RegressionView";
import { PatternsView } from "./components/PatternsView";
import { DOEView } from "./components/DOEView";
import { RSMView } from "./components/RSMView";
import { TestVerificationModal } from "./components/TestVerificationModal";
import { ComparisonResult, ValidationResult, YOrientation } from "./types";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>("data");
  const [datasetName, setDatasetName] = useState<string>("VMC_OPTIMIZATION_RUN_042.CSV");
  const [datasetId, setDatasetId] = useState<string>(() => `DS_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`);
  const [activeRequestId, setActiveRequestId] = useState<string>("");
  const [rawData, setRawData] = useState<any[]>([]);
  const [validation, setValidation] = useState<ValidationResult | null>(null);
  const [isValidating, setIsValidating] = useState<boolean>(false);

  // Y-selection & orientation
  const [selectedY, setSelectedY] = useState<string>("cycle_time_sec");
  const [yOrientation, setYOrientation] = useState<YOrientation>("Higher Y = Worse");
  const [selectedBadIds, setSelectedBadIds] = useState<string[]>([]);
  const [selectedGoodIds, setSelectedGoodIds] = useState<string[]>([]);

  // Comparison Results
  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [isComparing, setIsComparing] = useState<boolean>(false);

  // Verification modal
  const [isTestModalOpen, setIsTestModalOpen] = useState<boolean>(false);

  // Wrapped handlers to ensure strict state invalidation on selection changes
  const handleSelectY = (col: string) => {
    if (col !== selectedY) {
      setSelectedY(col);
      setSelectedBadIds([]);
      setSelectedGoodIds([]);
      setComparison(null);
    }
  };

  const handleSetYOrientation = (orientation: YOrientation) => {
    if (orientation !== yOrientation) {
      setYOrientation(orientation);
      setSelectedBadIds([]);
      setSelectedGoodIds([]);
      setComparison(null);
    }
  };

  const handleSetSelectedBadIds: React.Dispatch<React.SetStateAction<string[]>> = (action) => {
    setComparison(null);
    setSelectedBadIds(action);
  };

  const handleSetSelectedGoodIds: React.Dispatch<React.SetStateAction<string[]>> = (action) => {
    setComparison(null);
    setSelectedGoodIds(action);
  };

  // Generate Benchmark Manufacturing Cases
  const generateVMCBenchmark = () => {
    const rows = [];
    for (let i = 1; i <= 30; i++) {
      const id = `VMC_RUN_${String(i).padStart(3, "0")}`;
      const spindle_speed = 1800 + Math.floor(Math.random() * 800);
      const feed_rate = 450 + Math.floor(Math.random() * 300);
      const depth_of_cut = parseFloat((0.8 + Math.random() * 1.4).toFixed(2));
      const coolant_flow = parseFloat((12.0 + Math.random() * 6.0).toFixed(1));
      const tool_wear_flank = parseFloat((0.02 + i * 0.008 + (Math.random() * 0.04)).toFixed(3));
      const fixture_clamping_bar = parseFloat((35 + Math.random() * 8).toFixed(1));
      const shift = i % 3 === 0 ? "Shift C (Night)" : i % 2 === 0 ? "Shift B (Evening)" : "Shift A (Day)";
      const operator = i % 4 === 0 ? "Op_Kiran" : i % 2 === 0 ? "Op_Ramesh" : "Op_Anand";

      // Cycle time model with strong dependence on spindle speed & feed rate
      const cycle_time_sec = parseFloat(
        (135.0 - (spindle_speed - 1800) * 0.025 + (feed_rate - 450) * 0.04 - (depth_of_cut - 0.8) * 5.0 + (tool_wear_flank * 80.0) + (Math.random() * 4.0 - 2.0)).toFixed(2)
      );

      rows.push({
        id,
        cycle_time_sec,
        spindle_speed,
        feed_rate,
        depth_of_cut,
        coolant_flow,
        tool_wear_flank,
        fixture_clamping_bar,
        shift,
        operator,
      });
    }
    return rows;
  };

  const generatePumpLeakageBenchmark = () => {
    const rows = [];
    for (let i = 1; i <= 60; i++) {
      const id = `PUMP_OBS_${String(i).padStart(3, "0")}`;
      const seal_face_pressure = parseFloat((4.5 + Math.random() * 3.5).toFixed(2));
      const barrier_fluid_temp = parseFloat((38.0 + Math.random() * 24.0).toFixed(1));
      const vibration_rms_mms = parseFloat((1.2 + Math.random() * 4.8).toFixed(2));
      const shaft_runout_um = parseFloat((8.0 + Math.random() * 25.0).toFixed(1));
      const elastomer_shore_a = 75 + Math.floor(Math.random() * 10);
      const supplier_lot = i % 2 === 0 ? "Lot_Alpha" : "Lot_Beta";
      
      const leakage_ml_hr = parseFloat(
        (0.5 + (barrier_fluid_temp > 50 ? (barrier_fluid_temp - 50) * 0.35 : 0) + (vibration_rms_mms * 1.2) + (shaft_runout_um * 0.18) + (Math.random() * 0.6)).toFixed(2)
      );

      rows.push({
        id,
        leakage_ml_hr,
        seal_face_pressure,
        barrier_fluid_temp,
        vibration_rms_mms,
        shaft_runout_um,
        elastomer_shore_a,
        supplier_lot,
      });
    }
    return rows;
  };

  const generateGearFlankBenchmark = () => {
    const rows = [];
    for (let i = 1; i <= 40; i++) {
      const id = `GEAR_PART_${String(i).padStart(3, "0")}`;
      const dressing_depth_um = parseFloat((15.0 + Math.random() * 20.0).toFixed(1));
      const grinding_infeed_mms = parseFloat((0.15 + Math.random() * 0.35).toFixed(3));
      const workpiece_hardness_hrc = parseFloat((58.0 + Math.random() * 4.0).toFixed(1));
      const coolant_temp_c = parseFloat((20.0 + Math.random() * 12.0).toFixed(1));
      const tooth_module = 4.5; // Constant test column

      const profile_angle_dev_um = parseFloat(
        (2.0 + (dressing_depth_um * 0.22) - (grinding_infeed_mms * 6.0) + (Math.random() * 1.5)).toFixed(2)
      );

      rows.push({
        id,
        profile_angle_dev_um,
        dressing_depth_um,
        grinding_infeed_mms,
        workpiece_hardness_hrc,
        coolant_temp_c,
        tooth_module,
      });
    }
    return rows;
  };

  // Run validation on raw dataset
  const validateDataset = async (data: any[], filename?: string) => {
    if (!data || !Array.isArray(data) || data.length === 0) return;
    setIsValidating(true);
    try {
      const res = await fetch("/api/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rows: data, data, filename: filename || datasetName }),
      });
      const valResult: ValidationResult = await res.json();
      if (valResult) {
        setValidation(valResult);

        // Auto-set Y column if not set or invalid
        if (valResult.numeric_columns && valResult.numeric_columns.length > 0) {
          if (!selectedY || !valResult.numeric_columns.includes(selectedY)) {
            setSelectedY(valResult.numeric_columns[0]);
          }
        }
      }
    } catch (err: any) {
      console.error("Validation failed:", err);
    } finally {
      setIsValidating(false);
    }
  };

  // Load a demo case
  const handleLoadDemo = (name: string) => {
    let rows: any[] = [];
    let fname = "";
    let defaultY = "";

    if (name === "vmc") {
      rows = generateVMCBenchmark();
      fname = "VMC_OPTIMIZATION_RUN_042.CSV";
      defaultY = "cycle_time_sec";
      setYOrientation("Higher Y = Worse");
    } else if (name === "pump") {
      rows = generatePumpLeakageBenchmark();
      fname = "CENTRIFUGAL_PUMP_SEAL_RUN_100K.CSV";
      defaultY = "leakage_ml_hr";
      setYOrientation("Higher Y = Worse");
    } else if (name === "gear") {
      rows = generateGearFlankBenchmark();
      fname = "GEAR_PROFILE_GRINDING_SERIES.CSV";
      defaultY = "profile_angle_dev_um";
      setYOrientation("Higher Y = Worse");
    } else if (name === "zero_variance") {
      rows = generateVMCBenchmark().map((r) => ({ ...r, spindle_speed: 2000, feed_rate: 500 }));
      fname = "ZERO_VARIANCE_INVARIANT_TEST.CSV";
      defaultY = "cycle_time_sec";
    } else if (name === "false_range") {
      rows = generateVMCBenchmark().map((r, i) => ({ ...r, spindle_speed: i % 2 === 0 ? 1800 : 2600 }));
      fname = "FALSE_RANGE_SEPARATION_TEST.CSV";
      defaultY = "cycle_time_sec";
    }

    const newDsId = `DS_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    setDatasetId(newDsId);
    setActiveRequestId("");
    setDatasetName(fname);
    setRawData(rows);
    setSelectedY(defaultY);
    setSelectedBadIds([]);
    setSelectedGoodIds([]);
    setComparison(null);
    validateDataset(rows, fname);
  };

  // Initial Load
  useEffect(() => {
    handleLoadDemo("vmc");
  }, []);

  // When dataset changes, auto-select 5 BAD and 5 GOOD
  const handleDataLoaded = (data: any[], filename?: string) => {
    const fname = filename || "CUSTOM_MANUFACTURING_DATA.CSV";
    const newDsId = `DS_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    setDatasetId(newDsId);
    setActiveRequestId("");
    setDatasetName(fname);
    setRawData(data);
    setSelectedBadIds([]);
    setSelectedGoodIds([]);
    setComparison(null);
    validateDataset(data, fname);
  };

  // Reset workspace
  const handleReset = () => {
    setSelectedBadIds([]);
    setSelectedGoodIds([]);
    setComparison(null);
    setActiveRequestId("");
    setActiveTab("data");
  };

  // Execute 5 BAD vs 5 GOOD Diagnostic Comparison
  const handleRunComparison = async () => {
    if (selectedBadIds.length !== 5 || selectedGoodIds.length !== 5) {
      alert("Please select exactly 5 BAD and 5 GOOD observations.");
      return;
    }

    const currentReqId = `REQ_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    setActiveRequestId(currentReqId);
    setIsComparing(true);

    try {
      const res = await fetch("/api/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dataset_id: datasetId,
          request_id: currentReqId,
          data: rawData,
          y_col: selectedY,
          bad_ids: selectedBadIds,
          good_ids: selectedGoodIds,
          y_orientation: yOrientation,
          id_col: validation?.id_column || "id",
        }),
      });
      
      const data = await res.json();

      // Verify request identity token and dataset identity to prevent race conditions
      if (data.request_id && data.request_id !== currentReqId) {
        console.warn(`[DataLock] Stale analysis response discarded: returned ${data.request_id}, active is ${currentReqId}`);
        return;
      }
      if (data.dataset_id && data.dataset_id !== datasetId) {
        console.warn(`[DataLock] Mismatched dataset response discarded: returned ${data.dataset_id}, active is ${datasetId}`);
        return;
      }

      if (!res.ok || data.error) {
        setComparison(null);
        alert(data.error || "Analysis engine unavailable. No statistical result was generated.");
        return;
      }

      setComparison(data as ComparisonResult);
      setActiveTab("comparison");
    } catch (err: any) {
      setComparison(null);
      alert("Analysis engine unavailable. No statistical result was generated.");
    } finally {
      setIsComparing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0F172A] text-[#F1F5F9] flex flex-col font-sans selection:bg-[#38BDF8] selection:text-[#020617]">
      {/* Global Technical Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        datasetName={datasetName}
        rowCount={rawData.length}
        selectedBadCount={selectedBadIds.length}
        selectedGoodCount={selectedGoodIds.length}
        hasCompared={!!comparison}
        onLoadDemo={handleLoadDemo}
        onReset={handleReset}
        onOpenTestModal={() => setIsTestModalOpen(true)}
      />

      {/* Main Workspace Body */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto p-3 sm:p-5 lg:p-6 space-y-6">
        {activeTab === "data" && (
          <DataInputView
            rawData={rawData}
            validation={validation}
            isValidating={isValidating}
            onDataLoaded={handleDataLoaded}
            onProceedToY={() => setActiveTab("y_analysis")}
            onLoadDemo={handleLoadDemo}
          />
        )}

        {activeTab === "y_analysis" && (
          <YAnalysisView
            rawData={rawData}
            validation={validation}
            selectedY={selectedY}
            setSelectedY={handleSelectY}
            yOrientation={yOrientation}
            setYOrientation={handleSetYOrientation}
            selectedBadIds={selectedBadIds}
            setSelectedBadIds={handleSetSelectedBadIds}
            selectedGoodIds={selectedGoodIds}
            setSelectedGoodIds={handleSetSelectedGoodIds}
            onRunComparison={handleRunComparison}
            isComparing={isComparing}
          />
        )}

        {activeTab === "comparison" && (
          <ComparativeAnalysisView
            comparison={comparison}
            selectedBadIds={selectedBadIds}
            selectedGoodIds={selectedGoodIds}
            rawData={rawData}
            onNavigateToDOE={() => setActiveTab("doe")}
            onNavigateToRSM={() => setActiveTab("rsm")}
          />
        )}

        {activeTab === "stratification" && (
          <StratificationView
            rawData={rawData}
            validation={validation}
            selectedY={selectedY}
          />
        )}

        {activeTab === "is_is_not" && <IsIsNotView />}

        {activeTab === "capability" && (
          <CapabilityView
            rawData={rawData}
            validation={validation}
            selectedY={selectedY}
          />
        )}

        {activeTab === "correlation" && (
          <CorrelationView
            rawData={rawData}
            validation={validation}
            selectedY={selectedY}
          />
        )}

        {activeTab === "regression" && (
          <RegressionView
            rawData={rawData}
            validation={validation}
            selectedY={selectedY}
          />
        )}

        {activeTab === "patterns" && (
          <PatternsView
            rawData={rawData}
            validation={validation}
            selectedY={selectedY}
          />
        )}

        {activeTab === "doe" && <DOEView />}

        {activeTab === "rsm" && <RSMView />}
      </main>

      {/* Engine Verification Modal (12 Benchmark Tests) */}
      <TestVerificationModal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
      />
    </div>
  );
}
