/**
 * Krisha Innovate - DataLock Pro TypeScript Definitions
 */

export type YOrientation = "Higher Y = Worse" | "Lower Y = Worse";

export type EvidenceTier =
  | "VERY STRONG OBSERVED SEPARATION"
  | "STRONG OBSERVED SEPARATION"
  | "MODERATE OBSERVED SEPARATION"
  | "WEAK OBSERVED SEPARATION"
  | "NO / VERY WEAK OBSERVED SEPARATION"
  | "Very Strong"
  | "Strong"
  | "Moderate"
  | "Weak"
  | "No / Very Weak Observed Separation";

export type EvidenceConsistency =
  | "CONCORDANT"
  | "PARTIALLY CONCORDANT"
  | "DISCORDANT"
  | "INCONCLUSIVE";

export interface ColumnStat {
  name: string;
  type: "Numeric" | "Categorical";
  missing_count: number;
  missing_pct: number;
  is_constant: boolean;
  summary?: {
    min?: number | null;
    max?: number | null;
    mean?: number | null;
    median?: number | null;
    stdev?: number | null;
    distinct_count?: number;
    top_categories?: string[];
  };
}

export interface ValidationResult {
  is_valid: boolean;
  error?: string;
  row_count: number;
  col_count: number;
  id_column: string;
  has_duplicate_ids: boolean;
  duplicate_id_count: number;
  numeric_columns: string[];
  categorical_columns: string[];
  constant_columns: string[];
  columns: ColumnStat[];
}

export interface ConfirmationPlan {
  variable: string;
  tier: EvidenceTier;
  direction: string;
  evidence_summary: string;
  risk_level: string;
  suggested_action: string;
  assumptions_limitations: string;
  caution_note: string;
}

export interface CandidateResult {
  variable: string;
  type: "Numeric" | "Categorical";
  evidence_strength: EvidenceTier;
  direction: string;
  justification: string;
  confirmation_plan: ConfirmationPlan;

  // Sample counts & missing data handling
  n_bad_total?: number;
  n_bad_used?: number;
  n_bad_excluded?: number;
  n_good_total?: number;
  n_good_used?: number;
  n_good_excluded?: number;
  effective_n?: number;

  // Numeric specifics
  mean_bad?: number;
  mean_good?: number;
  mean_diff?: number;
  median_bad?: number;
  median_good?: number;
  median_diff?: number;
  sd_bad?: number;
  sd_good?: number;
  welch_t?: number | null;
  welch_df?: number | null;
  welch_p?: number | null;
  welch_note?: string;
  mann_whitney_u?: number;
  mann_whitney_p?: number;
  mw_calc_type?: string;
  has_ties?: boolean;
  auc?: number;
  cohens_d?: number | null;
  hedges_g?: number | null;
  consistency?: string;
  range_info?: {
    bad_range: [number, number];
    good_range: [number, number];
    overlap: number;
    disclaimer: string;
  };

  // Categorical specifics
  chi2_stat?: number;
  chi2_p?: number;
  cramers_v?: number;
  distribution?: Array<{
    category: string;
    bad_count: number;
    bad_pct: number;
    good_count: number;
    good_pct: number;
  }>;
}

export interface ComparisonResult {
  dataset_id?: string;
  request_id?: string;
  calculation_status?: string;
  analysis_method?: string;
  effective_n?: number;
  bad_ids?: string[];
  good_ids?: string[];
  y_variable: string;
  y_orientation: YOrientation;
  y_summary: {
    mean_bad: number;
    median_bad: number;
    sd_bad: number;
    mean_good: number;
    median_good: number;
    sd_good: number;
    n_bad_total?: number;
    n_bad_used?: number;
    n_bad_missing?: number;
    n_good_total?: number;
    n_good_used?: number;
    n_good_missing?: number;
  };
  orientation_consistency: boolean;
  candidates: CandidateResult[];
  rules_enforced: string[];
  error?: string;
}

export interface RegressionCoefficient {
  term: string;
  coef: number;
  se: number;
  t_stat: number;
  p_value: number;
  ci_95_low: number;
  ci_95_high: number;
}

export interface RegressionResult {
  n: number;
  p: number;
  df_resid: number;
  df_reg: number;
  r_squared: number;
  adj_r_squared: number;
  f_stat: number;
  f_p_value: number;
  rmse: number;
  coefficients: RegressionCoefficient[];
  residuals: number[];
  fitted_values: number[];
  error?: string;
}

export interface CapabilityResult {
  n: number;
  mean: number;
  median: number;
  stdev_overall: number;
  stdev_within: number;
  lsl?: number | null;
  usl?: number | null;
  cp?: number | null;
  cpk?: number | null;
  cpu?: number | null;
  cpl?: number | null;
  pp?: number | null;
  ppk?: number | null;
  ppm_total?: number;
  ppm_lower?: number;
  ppm_upper?: number;
  status: string;
  error?: string;
}

export interface AnomalyItem {
  index: number;
  label: string;
  value: number;
  z_score: number;
  modified_z: number;
  type: string;
  note: string;
}

export interface PatternItem {
  pattern: string;
  description: string;
  rule: string;
  indices: number[];
}

export interface AnomalyPatternResult {
  n: number;
  mean: number;
  median: number;
  iqr: number;
  q1: number;
  q3: number;
  lower_fence_1_5: number;
  upper_fence_1_5: number;
  anomaly_count: number;
  anomalies: AnomalyItem[];
  patterns: PatternItem[];
  error?: string;
}

export interface DOEPlanFactor {
  name: string;
  low: number;
  high: number;
  unit?: string;
}

export interface DOERunRow {
  std_order: number;
  run_order?: number;
  replicate: number;
  type: "Factorial" | "Center";
  coded: Record<string, number>;
  actual: Record<string, number>;
  response_y?: number | null;
}

export interface DOEPlanResult {
  num_factors: number;
  factors: DOEPlanFactor[];
  total_runs: number;
  factorial_runs: number;
  center_points: number;
  design_matrix: DOERunRow[];
  error?: string;
}

export interface DOEAnalysisResult {
  model_summary: {
    r_squared: number;
    adj_r_squared: number;
    f_stat: number;
    f_p_value: number;
    rmse: number;
  };
  coefficients: RegressionCoefficient[];
  pareto_effects: Array<{
    term: string;
    effect: number;
    abs_effect: number;
    t_stat: number;
    p_value: number;
    significant: boolean;
  }>;
  num_runs: number;
  error?: string;
}

export interface RSMPlanResult {
  design_type: string;
  num_factors: number;
  total_runs: number;
  factors: DOEPlanFactor[];
  design_matrix: DOERunRow[];
  error?: string;
}

export interface RSMOptimizationResult {
  model_summary: {
    r_squared: number;
    adj_r_squared: number;
    rmse: number;
    f_stat: number;
    f_p_value: number;
  };
  coefficients: RegressionCoefficient[];
  stationary_point_coded: Record<string, number>;
  stationary_y?: number | null;
  nature_of_surface: string;
  optimal_solution: {
    goal: string;
    target_value?: number | null;
    optimal_coded: Record<string, number>;
    predicted_optimal_y: number;
  };
  contour_grid?: Array<Array<{ x1: number; x2: number; predicted_y: number }>>;
  error?: string;
}
