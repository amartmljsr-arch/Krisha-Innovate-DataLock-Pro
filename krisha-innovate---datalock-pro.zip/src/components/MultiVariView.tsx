import React, { useState, useEffect } from "react";
import {
  Activity,
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Filter,
  Info,
  Layers,
  PieChart,
  RefreshCw,
  Sliders,
  Sparkles,
  TrendingUp
} from "lucide-react";
import { MultiVariResult, MultiVariLeafSubgroup } from "../types";

interface MultiVariViewProps {
  rawData: any[];
  numericColumns: string[];
  categoricalColumns: string[];
  selectedY: string;
  selectedBadIds: string[];
  selectedGoodIds: string[];
  onSelectBad: (id: string) => void;
  onSelectGood: (id: string) => void;
  onProceedTo5vs5: () => void;
}

export const MultiVariView: React.FC<MultiVariViewProps> = ({
  rawData,
  numericColumns,
  categoricalColumns,
  selectedY: initialY,
  selectedBadIds,
  selectedGoodIds,
  onSelectBad,
  onSelectGood,
  onProceedTo5vs5,
}) => {
  // Helper to identify ID-like columns that should not be used as process stratification factors
  const isIdColumn = (col: string) => {
    if (!col) return false;
    const lower = col.toLowerCase().trim();
    return (
      lower === "id" ||
      lower === "_dl_id" ||
      lower === "part_id" ||
      lower === "sample_id" ||
      lower === "obs_id" ||
      lower === "run_id" ||
      lower === "serial_no" ||
      lower === "sn" ||
      lower === "turb_id"
    );
  };

  // Configurable factors
  const validNumericColumns = numericColumns.filter((c) => !isIdColumn(c));
  const [targetY, setTargetY] = useState<string>(
    initialY && validNumericColumns.includes(initialY)
      ? initialY
      : validNumericColumns.length > 0
      ? validNumericColumns[0]
      : ""
  );
  const [factor1, setFactor1] = useState<string>("");
  const [factor2, setFactor2] = useState<string>("");
  const [factor3, setFactor3] = useState<string>("");

  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<MultiVariResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hoveredPoint, setHoveredPoint] = useState<{
    id: string;
    y: number;
    f1: string;
    f2?: string;
    f3?: string;
    xPos: number;
    yPos: number;
  } | null>(null);

  // Auto-pick intelligent default factors when columns or initialY change
  useEffect(() => {
    const validNumeric = numericColumns.filter((c) => !isIdColumn(c));
    let effectiveY = targetY;
    if (!effectiveY && initialY && validNumeric.includes(initialY)) {
      effectiveY = initialY;
      setTargetY(initialY);
    } else if (!effectiveY && validNumeric.length > 0) {
      effectiveY = validNumeric[0];
      setTargetY(validNumeric[0]);
    }

    const availableFactors = categoricalColumns.filter(
      (c) => c !== effectiveY && !isIdColumn(c)
    );
    if (availableFactors.length > 0) {
      if (!factor1 || factor1 === effectiveY || isIdColumn(factor1)) {
        const nextF1 = availableFactors[0];
        setFactor1(nextF1);
        if (availableFactors.length > 1 && (!factor2 || factor2 === nextF1 || factor2 === effectiveY || isIdColumn(factor2))) {
          setFactor2(availableFactors[1]);
        }
      }
    }
  }, [numericColumns, categoricalColumns, initialY]);

  // Execute Multi-Vari Analysis via Python analytical engine API
  const runMultiVari = async (overrides?: {
    y?: string;
    f1?: string;
    f2?: string;
    f3?: string;
  }) => {
    const curY = overrides?.y !== undefined ? overrides.y : targetY;
    const curF1 = overrides?.f1 !== undefined ? overrides.f1 : factor1;
    const curF2 = overrides?.f2 !== undefined ? overrides.f2 : factor2;
    const curF3 = overrides?.f3 !== undefined ? overrides.f3 : factor3;

    if (!curY) {
      setError("Target response variable Y is required.");
      setResult(null);
      return;
    }
    if (!curF1) {
      setError("Primary stratification factor 1 is required.");
      setResult(null);
      return;
    }
    if (!rawData || rawData.length === 0) {
      setError("Dataset is empty for Multi-Vari analysis.");
      setResult(null);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/multivari", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rows: rawData,
          y_col: curY,
          factor1: curF1,
          factor2: curF2 || undefined,
          factor3: curF3 || undefined,
          factor1_col: curF1,
          factor2_col: curF2 || undefined,
          factor3_col: curF3 || undefined,
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || `HTTP error ${response.status}`);
      }

      const data: MultiVariResult = await response.json();
      if (data.status === "ERROR" || data.error) {
        setError(data.error || "Failed to compute Multi-Vari chart.");
        setResult(null);
      } else {
        setResult(data);
        setError(null);
      }
    } catch (err: any) {
      setError(err.message || "Analytical engine unavailable. No statistical result was generated.");
      setResult(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Run automatically when factors change
  useEffect(() => {
    if (targetY && factor1 && rawData && rawData.length > 0) {
      runMultiVari();
    }
  }, [targetY, factor1, factor2, factor3, rawData]);

  // Calculate Chart Layout Metrics
  const chartHeight = 360;
  const chartWidth = 900;
  const padLeft = 65;
  const padRight = 30;
  const padTop = 30;
  const padBottom = 75;

  const innerWidth = chartWidth - padLeft - padRight;
  const innerHeight = chartHeight - padTop - padBottom;

  const yMin = result?.grand_stats ? result.grand_stats.min - (result.grand_stats.max - result.grand_stats.min) * 0.08 : 0;
  const yMax = result?.grand_stats ? result.grand_stats.max + (result.grand_stats.max - result.grand_stats.min) * 0.08 : 100;
  const yRange = yMax - yMin > 0 ? yMax - yMin : 1;

  const scaleY = (val: number) => {
    return padTop + innerHeight - ((val - yMin) / yRange) * innerHeight;
  };

  const leafSubgroups = result?.leaf_subgroups || [];
  const subgroupCount = Math.max(1, leafSubgroups.length);
  const subgroupColWidth = innerWidth / subgroupCount;

  return (
    <div className="space-y-5">
      {/* Top Header & Context */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">
              MULTI-VARI EXPLORATION & STRATIFICATION
            </span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              ENGINE: PYTHON IPC AUTHORITATIVE
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Multi-Vari Process Variation Stratifier
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Multi-Vari charts partition overall process variation into positional (within-unit), cyclical (unit-to-unit), 
            and temporal (subgroup-to-subgroup) components without assuming cause. All observations retain unique identifiers 
            for direct feed into the 5 BAD / 5 GOOD diagnostic queue.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => runMultiVari()}
            disabled={isLoading}
            className="px-4 py-2 bg-[#0F172A] border border-[#38BDF8]/40 hover:border-[#38BDF8] text-[#38BDF8] rounded text-xs font-mono font-bold flex items-center gap-2 transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
            <span>Re-Stratify</span>
          </button>

          <button
            onClick={onProceedTo5vs5}
            className="tech-btn-run px-4 py-2 rounded text-xs font-mono font-bold flex items-center gap-2 transition cursor-pointer shadow-md"
          >
            <span>Proceed to 5 BAD / 5 GOOD</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Factor Selection Configuration Bar */}
      <div className="tech-grid-card p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#F1F5F9] uppercase tracking-wider">
            <Sliders className="w-4 h-4 text-[#38BDF8]" />
            <span>Multi-Vari Stratification Hierarchy Configuration</span>
          </div>
          <span className="text-[11px] font-mono text-[#94A3B8]">
            Missing values excluded (Missing ≠ Zero)
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Target Y */}
          <div className="tech-subcard p-3">
            <label className="block text-[10px] font-mono uppercase text-[#38BDF8] font-bold mb-1">
              Response Variable (Y) *
            </label>
            <select
              value={targetY}
              onChange={(e) => {
                const newY = e.target.value;
                setTargetY(newY);
                if (factor1 === newY) setFactor1("");
                if (factor2 === newY) setFactor2("");
                if (factor3 === newY) setFactor3("");
              }}
              className="w-full bg-[#0F172A] border border-[#334155] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] font-mono focus:border-[#38BDF8] focus:outline-none"
            >
              {validNumericColumns.map((col) => (
                <option key={col} value={col}>
                  {col} (Numeric)
                </option>
              ))}
            </select>
          </div>

          {/* Primary Factor 1 */}
          <div className="tech-subcard p-3">
            <label className="block text-[10px] font-mono uppercase text-[#F1F5F9] font-bold mb-1">
              Primary Factor 1 (Major Group) *
            </label>
            <select
              value={factor1}
              onChange={(e) => {
                const newF1 = e.target.value;
                setFactor1(newF1);
                if (factor2 === newF1) setFactor2("");
                if (factor3 === newF1) setFactor3("");
              }}
              className="w-full bg-[#0F172A] border border-[#334155] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] font-mono focus:border-[#38BDF8] focus:outline-none"
            >
              <option value="" disabled>Select Primary Factor...</option>
              {categoricalColumns.filter((c) => c !== targetY && !isIdColumn(c)).map((col) => (
                <option key={col} value={col}>
                  {col}
                </option>
              ))}
              {numericColumns.filter((c) => c !== targetY && !isIdColumn(c)).map((col) => (
                <option key={col} value={col}>
                  {col} (Numeric as Discrete)
                </option>
              ))}
            </select>
          </div>

          {/* Secondary Factor 2 */}
          <div className="tech-subcard p-3">
            <label className="block text-[10px] font-mono uppercase text-[#94A3B8] font-bold mb-1">
              Secondary Factor 2 (Nested Level)
            </label>
            <select
              value={factor2}
              onChange={(e) => {
                const newF2 = e.target.value;
                setFactor2(newF2);
                if (factor3 === newF2) setFactor3("");
              }}
              className="w-full bg-[#0F172A] border border-[#334155] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] font-mono focus:border-[#38BDF8] focus:outline-none"
            >
              <option value="">-- None (Single Stratification) --</option>
              {categoricalColumns.filter((c) => c !== targetY && c !== factor1 && !isIdColumn(c)).map((col) => (
                <option key={col} value={col}>
                  {col}
                </option>
              ))}
              {numericColumns.filter((c) => c !== targetY && c !== factor1 && !isIdColumn(c)).map((col) => (
                <option key={col} value={col}>
                  {col} (Numeric as Discrete)
                </option>
              ))}
            </select>
          </div>

          {/* Tertiary Factor 3 */}
          <div className="tech-subcard p-3">
            <label className="block text-[10px] font-mono uppercase text-[#94A3B8] font-bold mb-1">
              Tertiary Factor 3 (Sub-Nested)
            </label>
            <select
              value={factor3}
              onChange={(e) => setFactor3(e.target.value)}
              className="w-full bg-[#0F172A] border border-[#334155] rounded px-2.5 py-1.5 text-xs text-[#F1F5F9] font-mono focus:border-[#38BDF8] focus:outline-none"
            >
              <option value="">-- None --</option>
              {categoricalColumns.filter((c) => c !== targetY && c !== factor1 && c !== factor2 && !isIdColumn(c)).map((col) => (
                <option key={col} value={col}>
                  {col}
                </option>
              ))}
              {numericColumns.filter((c) => c !== targetY && c !== factor1 && c !== factor2 && !isIdColumn(c)).map((col) => (
                <option key={col} value={col}>
                  {col} (Numeric as Discrete)
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="p-4 bg-[#4C0519]/60 border border-[#F43F5E] rounded text-[#F43F5E] flex items-center gap-3 text-xs font-mono">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Multi-Vari Diagnostic Chart Area */}
      {result && result.status === "SUCCESS" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Chart Panel */}
          <div className="lg:col-span-2 tech-grid-card p-4 sm:p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#334155]">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#38BDF8]" />
                <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                  Multi-Vari Chart: {targetY} by {factor1} {factor2 ? `→ ${factor2}` : ""} {factor3 ? `→ ${factor3}` : ""}
                </h3>
              </div>
              <div className="flex items-center gap-2 text-[10px] font-mono text-[#94A3B8]">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#38BDF8]"></span>
                  <span>Observation</span>
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rotate-45 bg-[#F59E0B] inline-block"></span>
                  <span>Subgroup Mean</span>
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-0.5 bg-[#F43F5E] inline-block border-b border-dashed border-[#F43F5E]"></span>
                  <span>Grand Mean</span>
                </span>
              </div>
            </div>

            {/* SVG Multi-Vari Chart */}
            <div className="relative overflow-x-auto bg-[#0A0F1D] border border-[#334155] rounded p-2">
              <svg
                viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                className="w-full h-auto min-w-[700px] select-none"
              >
                {/* Horizontal Gridlines & Y-Axis */}
                {[0, 0.25, 0.5, 0.75, 1].map((pct, idx) => {
                  const val = yMin + pct * yRange;
                  const yPos = scaleY(val);
                  return (
                    <g key={idx}>
                      <line
                        x1={padLeft}
                        y1={yPos}
                        x2={chartWidth - padRight}
                        y2={yPos}
                        stroke="#1E293B"
                        strokeDasharray="2,2"
                        strokeWidth="1"
                      />
                      <text
                        x={padLeft - 8}
                        y={yPos + 3}
                        fill="#64748B"
                        fontSize="10"
                        fontFamily="monospace"
                        textAnchor="end"
                      >
                        {val.toFixed(2)}
                      </text>
                    </g>
                  );
                })}

                {/* Grand Mean Reference Line */}
                {result.grand_stats && (
                  <g>
                    <line
                      x1={padLeft}
                      y1={scaleY(result.grand_stats.mean)}
                      x2={chartWidth - padRight}
                      y2={scaleY(result.grand_stats.mean)}
                      stroke="#F43F5E"
                      strokeWidth="1.5"
                      strokeDasharray="4,4"
                    />
                    <text
                      x={chartWidth - padRight - 5}
                      y={scaleY(result.grand_stats.mean) - 5}
                      fill="#F43F5E"
                      fontSize="9"
                      fontFamily="monospace"
                      textAnchor="end"
                      fontWeight="bold"
                    >
                      Grand Mean: {result.grand_stats.mean.toFixed(2)}
                    </text>
                  </g>
                )}

                {/* Subgroup Vertical Panels & Points */}
                {leafSubgroups.map((sg: MultiVariLeafSubgroup, sgIdx: number) => {
                  const xCenter = padLeft + sgIdx * subgroupColWidth + subgroupColWidth / 2;
                  const yMeanPos = scaleY(sg.mean);
                  const yMinPos = scaleY(sg.min);
                  const yMaxPos = scaleY(sg.max);

                  // Vertical divider between subgroups
                  return (
                    <g key={sg.label || `sg-${sgIdx}`}>
                      {/* Background Subgroup Column */}
                      <rect
                        x={padLeft + sgIdx * subgroupColWidth + 2}
                        y={padTop}
                        width={subgroupColWidth - 4}
                        height={innerHeight}
                        fill={sgIdx % 2 === 0 ? "#0F172A" : "#131E35"}
                        opacity="0.6"
                      />

                      {/* Subgroup Range Line (Min to Max) */}
                      <line
                        x1={xCenter}
                        y1={yMinPos}
                        x2={xCenter}
                        y2={yMaxPos}
                        stroke="#64748B"
                        strokeWidth="2"
                        strokeLinecap="round"
                      />
                      {/* Horizontal ticks at min & max */}
                      <line
                        x1={xCenter - 6}
                        y1={yMinPos}
                        x2={xCenter + 6}
                        y2={yMinPos}
                        stroke="#64748B"
                        strokeWidth="1.5"
                      />
                      <line
                        x1={xCenter - 6}
                        y1={yMaxPos}
                        x2={xCenter + 6}
                        y2={yMaxPos}
                        stroke="#64748B"
                        strokeWidth="1.5"
                      />

                      {/* Raw Observations Scatter Points */}
                      {sg.observations.map((obs, obsIdx) => {
                        const obsYPos = scaleY(obs.y_val);
                        // Slight horizontal jitter for distinct visibility
                        const jitterOffset = sg.observations.length > 1
                          ? ((obsIdx % 3) - 1) * (Math.min(18, subgroupColWidth * 0.25))
                          : 0;
                        const obsXPos = xCenter + jitterOffset;
                        const isBad = selectedBadIds.includes(obs._dl_id);
                        const isGood = selectedGoodIds.includes(obs._dl_id);

                        return (
                          <g
                            key={obs._dl_id || obsIdx}
                            className="cursor-pointer group"
                            onMouseEnter={() =>
                              setHoveredPoint({
                                id: obs._dl_id,
                                y: obs.y_val,
                                f1: obs.f1,
                                f2: obs.f2,
                                f3: obs.f3,
                                xPos: obsXPos,
                                yPos: obsYPos,
                              })
                            }
                            onMouseLeave={() => setHoveredPoint(null)}
                          >
                            <circle
                              cx={obsXPos}
                              cy={obsYPos}
                              r={isBad || isGood ? "5.5" : "3.5"}
                              fill={isBad ? "#F43F5E" : isGood ? "#10B981" : "#38BDF8"}
                              stroke={isBad || isGood ? "#FFFFFF" : "#0284C7"}
                              strokeWidth={isBad || isGood ? "2" : "1"}
                              className="transition-all hover:scale-150"
                            />
                          </g>
                        );
                      })}

                      {/* Subgroup Mean Marker (Diamond) */}
                      <polygon
                        points={`${xCenter},${yMeanPos - 5} ${xCenter + 5},${yMeanPos} ${xCenter},${yMeanPos + 5} ${xCenter - 5},${yMeanPos}`}
                        fill="#F59E0B"
                        stroke="#78350F"
                        strokeWidth="1"
                      />

                      {/* X-Axis Labels (Factor 1, Factor 2) */}
                      <text
                        x={xCenter}
                        y={chartHeight - padBottom + 16}
                        fill="#F1F5F9"
                        fontSize="10"
                        fontFamily="monospace"
                        fontWeight="bold"
                        textAnchor="middle"
                      >
                        {String(sg.f1)}
                      </text>
                      {sg.f2 !== undefined && (
                        <text
                          x={xCenter}
                          y={chartHeight - padBottom + 30}
                          fill="#94A3B8"
                          fontSize="9"
                          fontFamily="monospace"
                          textAnchor="middle"
                        >
                          {String(sg.f2)}
                        </text>
                      )}
                      {sg.f3 !== undefined && (
                        <text
                          x={xCenter}
                          y={chartHeight - padBottom + 42}
                          fill="#64748B"
                          fontSize="8"
                          fontFamily="monospace"
                          textAnchor="middle"
                        >
                          {String(sg.f3)}
                        </text>
                      )}
                      <text
                        x={xCenter}
                        y={chartHeight - padBottom + (sg.f3 ? 54 : 44)}
                        fill="#38BDF8"
                        fontSize="8"
                        fontFamily="monospace"
                        textAnchor="middle"
                      >
                        (n={sg.n})
                      </text>
                    </g>
                  );
                })}

                {/* Connecting lines between subgroup means */}
                {leafSubgroups.map((sg, idx) => {
                  if (idx === 0) return null;
                  const prevSg = leafSubgroups[idx - 1];
                  const x1 = padLeft + (idx - 1) * subgroupColWidth + subgroupColWidth / 2;
                  const y1 = scaleY(prevSg.mean);
                  const x2 = padLeft + idx * subgroupColWidth + subgroupColWidth / 2;
                  const y2 = scaleY(sg.mean);

                  // Connect lines within same primary factor or continuous
                  return (
                    <line
                      key={`conn-${idx}`}
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke="#F59E0B"
                      strokeWidth="1.5"
                      strokeDasharray={prevSg.factor1_val === sg.factor1_val ? "none" : "3,3"}
                      opacity="0.8"
                    />
                  );
                })}

                {/* Y-Axis Label */}
                <text
                  transform={`rotate(-90)`}
                  x={-(chartHeight / 2)}
                  y={18}
                  fill="#94A3B8"
                  fontSize="11"
                  fontFamily="monospace"
                  textAnchor="middle"
                  fontWeight="bold"
                >
                  {targetY} (Value)
                </text>
              </svg>

              {/* Hover Tooltip */}
              {hoveredPoint && (
                <div
                  className="absolute z-30 bg-[#0F172A] border border-[#38BDF8] p-2.5 rounded shadow-2xl text-[11px] font-mono text-[#F1F5F9] pointer-events-none"
                  style={{
                    left: `${(hoveredPoint.xPos / chartWidth) * 100}%`,
                    top: `${(hoveredPoint.yPos / chartHeight) * 100 - 15}%`,
                    transform: "translate(-50%, -100%)",
                  }}
                >
                  <div className="font-bold text-[#38BDF8] flex items-center gap-1.5">
                    <span>Obs ID: {hoveredPoint.id}</span>
                  </div>
                  <div className="mt-1 space-y-0.5 text-[#94A3B8]">
                    <div>{targetY}: <span className="text-[#F1F5F9] font-bold">{hoveredPoint.y}</span></div>
                    <div>{factor1}: <span className="text-[#F1F5F9]">{hoveredPoint.f1}</span></div>
                    {hoveredPoint.f2 && <div>{factor2}: <span className="text-[#F1F5F9]">{hoveredPoint.f2}</span></div>}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Action Bar for Point Tagging */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs font-mono text-[#94A3B8]">
              <div className="flex items-center gap-4">
                <span>Selected BAD: <strong className="text-[#F43F5E]">{selectedBadIds.length}/5</strong></span>
                <span>Selected GOOD: <strong className="text-[#10B981]">{selectedGoodIds.length}/5</strong></span>
              </div>
              <span className="text-[11px] text-[#64748B]">
                Observations retain stable _dl_id across the pipeline.
              </span>
            </div>
          </div>

          {/* Statistical Breakdown & Non-Causal Interpretation Sidecard */}
          <div className="space-y-4">
            {/* Variance Decomposition Card */}
            <div className="tech-grid-card p-4 space-y-3">
              <div className="flex items-center gap-2 pb-2 border-b border-[#334155] text-xs font-mono font-bold text-[#F1F5F9] uppercase tracking-wider">
                <PieChart className="w-4 h-4 text-[#38BDF8]" />
                <span>Variance Decomposition</span>
              </div>

              {result.variance_decomposition && (
                <div className="space-y-3 font-mono text-xs">
                  {/* Primary Factor Variance */}
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[#94A3B8] text-[11px]">Between {factor1} (Primary):</span>
                      <span className="text-[#38BDF8] font-bold">
                        {result.variance_decomposition.pct_between_primary.toFixed(1)}%
                      </span>
                    </div>
                    <div className="w-full bg-[#1E293B] rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-[#38BDF8] h-2 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(100, Math.max(0, result.variance_decomposition.pct_between_primary))}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Secondary Factor Variance (if present) */}
                  {result.variance_decomposition.pct_between_secondary !== undefined && (
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-[#94A3B8] text-[11px]">Between {factor2} (Secondary):</span>
                        <span className="text-[#A855F7] font-bold">
                          {result.variance_decomposition.pct_between_secondary.toFixed(1)}%
                        </span>
                      </div>
                      <div className="w-full bg-[#1E293B] rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-[#A855F7] h-2 rounded-full transition-all duration-500"
                          style={{ width: `${Math.min(100, Math.max(0, result.variance_decomposition.pct_between_secondary))}%` }}
                        ></div>
                      </div>
                    </div>
                  )}

                  {/* Within-Subgroup Residual Variance */}
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[#94A3B8] text-[11px]">Within Subgroup (Positional / Noise):</span>
                      <span className="text-[#F59E0B] font-bold">
                        {result.variance_decomposition.pct_within.toFixed(1)}%
                      </span>
                    </div>
                    <div className="w-full bg-[#1E293B] rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-[#F59E0B] h-2 rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(100, Math.max(0, result.variance_decomposition.pct_within))}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Summary Metric Chips */}
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#334155]">
                    <div className="tech-subcard p-2">
                      <div className="text-[9px] uppercase text-[#94A3B8]">Total SS</div>
                      <div className="font-bold text-[#F1F5F9]">
                        {result.variance_decomposition.total_ss.toFixed(2)}
                      </div>
                    </div>
                    <div className="tech-subcard p-2">
                      <div className="text-[9px] uppercase text-[#94A3B8]">Grand Mean</div>
                      <div className="font-bold text-[#38BDF8]">
                        {result.grand_stats?.mean.toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Non-Causal Manufacturing Interpretations */}
            <div className="tech-grid-card p-4 space-y-3">
              <div className="flex items-center gap-2 pb-2 border-b border-[#334155] text-xs font-mono font-bold text-[#F1F5F9] uppercase tracking-wider">
                <Info className="w-4 h-4 text-[#10B981]" />
                <span>Exploratory Observations (Non-Causal)</span>
              </div>

              <div className="space-y-2 font-mono text-xs">
                {result.interpretations?.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded bg-[#0F172A] border border-[#334155] flex items-start gap-2"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-[#10B981] shrink-0 mt-0.5" />
                    <p className="text-[11px] text-[#E2E8F0] leading-relaxed">{item}</p>
                  </div>
                ))}

                <div className="p-2 bg-[#0F172A]/80 border border-[#334155] rounded text-[10px] text-[#94A3B8] leading-normal">
                  <strong className="text-[#38BDF8]">Statistical Guardrail:</strong> Multi-Vari charts surface stratification patterns. 
                  They isolate candidate variation components and do not constitute proof of physical causation without experimental confirmation.
                </div>
              </div>
            </div>

            {/* Direct 5 BAD / 5 GOOD Feed Subgroups List */}
            <div className="tech-grid-card p-4 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#334155] text-xs font-mono font-bold text-[#F1F5F9] uppercase tracking-wider">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-[#F43F5E]" />
                  <span>Subgroup Observations Queue</span>
                </div>
              </div>

              <div className="max-h-60 overflow-y-auto space-y-2 pr-1 scrollbar-thin">
                {leafSubgroups.map((sg) => (
                  <div key={sg.leaf_id} className="p-2 bg-[#0F172A] border border-[#334155] rounded text-[11px] font-mono">
                    <div className="flex justify-between items-center font-bold text-[#F1F5F9] mb-1">
                      <span>{sg.factor1_val} {sg.factor2_val ? `• ${sg.factor2_val}` : ""}</span>
                      <span className="text-[#38BDF8]">x̄ = {sg.mean.toFixed(2)}</span>
                    </div>
                    <div className="text-[10px] text-[#94A3B8] flex flex-wrap gap-1 mt-1">
                      {sg.observations.map((obs) => {
                        const isBad = selectedBadIds.includes(obs._dl_id);
                        const isGood = selectedGoodIds.includes(obs._dl_id);
                        return (
                          <div
                            key={obs._dl_id}
                            className={`flex items-center gap-1 px-1.5 py-0.5 rounded border text-[9px] ${
                              isBad
                                ? "bg-[#F43F5E]/20 border-[#F43F5E] text-[#FB7185]"
                                : isGood
                                ? "bg-[#10B981]/20 border-[#10B981] text-[#34D399]"
                                : "bg-[#1E293B] border-[#334155] text-[#94A3B8]"
                            }`}
                          >
                            <span>{obs._dl_id.replace("DL_", "")} ({obs.y})</span>
                            <button
                              onClick={() => onSelectBad(obs._dl_id)}
                              className="px-1 text-[#F43F5E] hover:font-bold cursor-pointer"
                              title="Toggle BAD"
                            >
                              B
                            </button>
                            <button
                              onClick={() => onSelectGood(obs._dl_id)}
                              className="px-1 text-[#10B981] hover:font-bold cursor-pointer"
                              title="Toggle GOOD"
                            >
                              G
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
