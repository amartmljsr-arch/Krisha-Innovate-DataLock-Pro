import React, { useMemo } from "react";
import {
  ArrowRight,
  Check,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  Target,
  TrendingDown,
  TrendingUp,
  X,
  Zap,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
  ScatterChart,
  Scatter,
  Cell,
} from "recharts";
import { ValidationResult, YOrientation } from "../types";

interface YAnalysisViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  selectedY: string;
  setSelectedY: (col: string) => void;
  yOrientation: YOrientation;
  setYOrientation: (orientation: YOrientation) => void;
  selectedBadIds: string[];
  setSelectedBadIds: React.Dispatch<React.SetStateAction<string[]>>;
  selectedGoodIds: string[];
  setSelectedGoodIds: React.Dispatch<React.SetStateAction<string[]>>;
  onRunComparison: () => void;
  isComparing: boolean;
}

export const YAnalysisView: React.FC<YAnalysisViewProps> = ({
  rawData,
  validation,
  selectedY,
  setSelectedY,
  yOrientation,
  setYOrientation,
  selectedBadIds,
  setSelectedBadIds,
  selectedGoodIds,
  setSelectedGoodIds,
  onRunComparison,
  isComparing,
}) => {
  const idCol = validation?.id_column || Object.keys(rawData[0] || {})[0] || "id";
  const numericCols = validation?.numeric_columns || [];

  // Parse Y values without converting missing data to zero
  const parsedObservations = useMemo(() => {
    if (!selectedY || rawData.length === 0) return [];
    return rawData
      .map((row, index) => {
        const rawVal = row[selectedY];
        const obsId = String(row._dl_id ?? (idCol ? row[idCol] : null) ?? `Obs_${index + 1}`);
        if (rawVal === null || rawVal === undefined || rawVal === "" || rawVal === "NaN" || rawVal === "nan" || rawVal === "null" || rawVal === "N/A") {
          return null;
        }
        const numVal = typeof rawVal === "number" ? rawVal : parseFloat(String(rawVal).trim());
        if (isNaN(numVal) || !isFinite(numVal)) {
          return null;
        }
        return {
          originalIndex: index,
          id: obsId,
          yValue: numVal,
          row,
        };
      })
      .filter((o): o is { originalIndex: number; id: string; yValue: number; row: any } => o !== null);
  }, [rawData, selectedY, idCol]);

  // Descriptive statistics of Y
  const stats = useMemo(() => {
    if (parsedObservations.length === 0) return null;
    const yValues = parsedObservations.map((o) => o.yValue).sort((a, b) => a - b);
    const n = yValues.length;
    const min = yValues[0];
    const max = yValues[n - 1];
    const sum = yValues.reduce((acc, v) => acc + v, 0);
    const mean = sum / n;
    const mid = Math.floor(n / 2);
    const median = n % 2 !== 0 ? yValues[mid] : (yValues[mid - 1] + yValues[mid]) / 2;
    const variance = n > 1 ? yValues.reduce((acc, v) => acc + (v - mean) ** 2, 0) / (n - 1) : 0;
    const stdev = Math.sqrt(variance);

    const q1 = yValues[Math.floor(n * 0.25)] ?? min;
    const q3 = yValues[Math.floor(n * 0.75)] ?? max;
    const iqr = q3 - q1;

    return {
      n,
      min,
      max,
      mean,
      median,
      stdev,
      range: max - min,
      iqr,
      q1,
      q3,
    };
  }, [parsedObservations]);

  // Ordered observation chart data (sorted by Y value for visual clarity)
  const orderedData = useMemo(() => {
    return [...parsedObservations]
      .sort((a, b) => (yOrientation === "Higher Y = Worse" ? a.yValue - b.yValue : b.yValue - a.yValue))
      .map((obs, rank) => {
        const badIndex = selectedBadIds.indexOf(obs.id);
        const goodIndex = selectedGoodIds.indexOf(obs.id);
        const isBad = badIndex !== -1;
        const isGood = goodIndex !== -1;
        return {
          ...obs,
          rank: rank + 1,
          status: isBad ? "BAD" : isGood ? "GOOD" : "NORMAL",
          code: isBad ? `B${badIndex + 1}` : isGood ? `G${goodIndex + 1}` : "",
        };
      });
  }, [parsedObservations, yOrientation, selectedBadIds, selectedGoodIds]);

  // Histogram Bins
  const histogramData = useMemo(() => {
    if (!stats || parsedObservations.length === 0) return [];
    const numBins = Math.min(14, Math.max(5, Math.floor(Math.sqrt(parsedObservations.length))));
    const binWidth = (stats.range > 0 ? stats.range : 1) / numBins;
    const bins = Array.from({ length: numBins }, (_, i) => ({
      binStart: stats.min + i * binWidth,
      binEnd: stats.min + (i + 1) * binWidth,
      binLabel: `${(stats.min + i * binWidth).toFixed(1)}-${(stats.min + (i + 1) * binWidth).toFixed(1)}`,
      count: 0,
      badCount: 0,
      goodCount: 0,
    }));

    parsedObservations.forEach((obs) => {
      let binIdx = Math.floor((obs.yValue - stats.min) / binWidth);
      if (binIdx >= numBins) binIdx = numBins - 1;
      if (binIdx < 0) binIdx = 0;
      bins[binIdx].count += 1;
      if (selectedBadIds.includes(obs.id)) bins[binIdx].badCount += 1;
      if (selectedGoodIds.includes(obs.id)) bins[binIdx].goodCount += 1;
    });

    return bins;
  }, [parsedObservations, stats, selectedBadIds, selectedGoodIds]);

  // Toggle selection handlers (ensures mutual exclusivity)
  const toggleBad = (id: string) => {
    if (selectedBadIds.includes(id)) {
      setSelectedBadIds(selectedBadIds.filter((item) => item !== id));
    } else {
      if (selectedBadIds.length >= 5) {
        alert("You have already selected 5 BAD observations. Remove one first.");
        return;
      }
      setSelectedGoodIds(selectedGoodIds.filter((item) => item !== id));
      setSelectedBadIds([...selectedBadIds, id]);
    }
  };

  const toggleGood = (id: string) => {
    if (selectedGoodIds.includes(id)) {
      setSelectedGoodIds(selectedGoodIds.filter((item) => item !== id));
    } else {
      if (selectedGoodIds.length >= 5) {
        alert("You have already selected 5 GOOD observations. Remove one first.");
        return;
      }
      setSelectedBadIds(selectedBadIds.filter((item) => item !== id));
      setSelectedGoodIds([...selectedGoodIds, id]);
    }
  };

  // Auto-select extreme 5 BAD and 5 GOOD
  const handleAutoSelectExtreme = () => {
    if (parsedObservations.length < 10) {
      alert("At least 10 observations are required to select 5 BAD and 5 GOOD.");
      return;
    }

    const sorted = [...parsedObservations].sort((a, b) => a.yValue - b.yValue);
    let bads: string[] = [];
    let goods: string[] = [];

    if (yOrientation === "Higher Y = Worse") {
      bads = sorted.slice(-5).map((o) => o.id);
      goods = sorted.slice(0, 5).map((o) => o.id);
    } else {
      bads = sorted.slice(0, 5).map((o) => o.id);
      goods = sorted.slice(-5).map((o) => o.id);
    }

    setSelectedBadIds(bads);
    setSelectedGoodIds(goods);
  };

  const isSelectionReady = selectedBadIds.length === 5 && selectedGoodIds.length === 5;

  return (
    <div className="space-y-5">
      {/* Top Banner & Orientation Bar */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">02. Y-OUTPUT & SELECTION</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              ORIENTATION: {yOrientation.toUpperCase()}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Define Target Y & Contrast Groups (5 BAD vs 5 GOOD)
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Inspect the ordered Y output distribution. Select exactly <strong>5 BAD</strong> and <strong>5 GOOD</strong> observations from the tails to isolate discriminatory manufacturing X factors.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={handleAutoSelectExtreme}
            className="px-3 py-2 rounded bg-[#0F172A] hover:bg-[#334155] text-[#38BDF8] border border-[#38BDF8]/40 text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 shadow-sm"
          >
            <Zap className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>AUTO-SELECT EXTREMES (5+5)</span>
          </button>

          <button
            disabled={!isSelectionReady || isComparing}
            onClick={onRunComparison}
            className={`px-5 py-2 rounded font-mono font-bold text-xs uppercase transition cursor-pointer shadow-md flex items-center gap-2 ${
              isSelectionReady && !isComparing
                ? "tech-btn-run"
                : "bg-[#334155] text-[#64748B] cursor-not-allowed opacity-50"
            }`}
          >
            <span>{isComparing ? "CALCULATING..." : "RUN X-CANDIDATE ANALYSIS"}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Target Y & Orientation Selectors */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="tech-grid-card p-3.5 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono uppercase text-[#94A3B8] block mb-1">
              Target Y Output Variable
            </span>
            <select
              value={selectedY}
              onChange={(e) => setSelectedY(e.target.value)}
              className="font-mono font-bold text-sm bg-transparent text-[#38BDF8] focus:outline-none cursor-pointer"
            >
              {numericCols.map((col) => (
                <option key={col} value={col} className="bg-[#1E293B] text-[#F1F5F9]">
                  {col}
                </option>
              ))}
            </select>
          </div>
          <Target className="w-6 h-6 text-[#38BDF8] shrink-0" />
        </div>

        <div className="tech-grid-card p-3.5 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono uppercase text-[#94A3B8] block mb-1">
              Failure Direction / Defect Polarisation
            </span>
            <div className="flex items-center gap-2 mt-1">
              <button
                onClick={() => setYOrientation("Higher Y = Worse")}
                className={`px-3 py-1 rounded text-xs font-mono font-bold flex items-center gap-1.5 transition cursor-pointer ${
                  yOrientation === "Higher Y = Worse"
                    ? "bg-[#F43F5E]/20 text-[#FB7185] border border-[#F43F5E]"
                    : "bg-[#0F172A] text-[#94A3B8] border border-[#334155] hover:text-[#F1F5F9]"
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>HIGHER Y = WORSE</span>
              </button>

              <button
                onClick={() => setYOrientation("Lower Y = Worse")}
                className={`px-3 py-1 rounded text-xs font-mono font-bold flex items-center gap-1.5 transition cursor-pointer ${
                  yOrientation === "Lower Y = Worse"
                    ? "bg-[#F59E0B]/20 text-[#FBBF24] border border-[#F59E0B]"
                    : "bg-[#0F172A] text-[#94A3B8] border border-[#334155] hover:text-[#F1F5F9]"
                }`}
              >
                <TrendingDown className="w-3.5 h-3.5" />
                <span>LOWER Y = WORSE</span>
              </button>
            </div>
          </div>
          <HelpCircle className="w-5 h-5 text-[#64748B]" />
        </div>
      </div>

      {/* Stats Bar (Matching Design HTML) */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Observations (N)</div>
            <div className="font-mono text-base font-bold text-[#F1F5F9]">{stats?.n?.toLocaleString?.() ?? (rawData?.length ? rawData.length.toLocaleString() : 0)}</div>
          </div>
          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Y-Mean ({selectedY})</div>
            <div className="font-mono text-base font-bold text-[#38BDF8]">{stats.mean.toFixed(2)}</div>
          </div>
          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Std. Deviation (s)</div>
            <div className="font-mono text-base font-bold text-[#F1F5F9]">{stats.stdev.toFixed(2)}</div>
          </div>
          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Y-Range [Min - Max]</div>
            <div className="font-mono text-xs font-bold text-[#F1F5F9] truncate mt-1">
              {stats.min.toFixed(1)} - {stats.max.toFixed(1)}
            </div>
          </div>
          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Median (Q2)</div>
            <div className="font-mono text-base font-bold text-[#C084FC]">{stats.median.toFixed(2)}</div>
          </div>
          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">IQR Span (Q3-Q1)</div>
            <div className="font-mono text-base font-bold text-[#94A3B8]">{stats.iqr.toFixed(2)}</div>
          </div>
        </div>
      )}

      {/* Main Grid: Visualizations on Left, Technical Side Panel on Right (Matching Design HTML) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left 2 Cols: Ordered Visualization & Frequency Histogram */}
        <div className="lg:col-span-2 space-y-4">
          {/* Ordered Y Output Chart Container */}
          <div className="tech-viz-container flex flex-col h-[320px]">
            <div className="p-3 border-b border-[#334155] flex flex-wrap items-center justify-between gap-2 bg-[#0F172A]">
              <div className="text-xs font-bold font-mono text-[#F1F5F9] flex items-center gap-2">
                <span>Ordered Y-Output:</span>
                <span className="text-[#38BDF8]">{selectedY}</span>
              </div>
              <div className="flex items-center gap-2 text-[11px] font-mono">
                <span className="tech-tag">
                  {yOrientation === "Higher Y = Worse" ? "HIGHER = WORSE" : "LOWER = WORSE"}
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  selectedBadIds.length === 5 ? "bg-[#F43F5E] text-white" : "tech-pill-bad"
                }`}>
                  BAD: {selectedBadIds.length}/5
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  selectedGoodIds.length === 5 ? "bg-[#10B981] text-[#020617]" : "tech-pill-good"
                }`}>
                  GOOD: {selectedGoodIds.length}/5
                </span>
              </div>
            </div>

            <div className="flex-1 p-3">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 15, right: 20, bottom: 20, left: 10 }}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.6} />
                  <XAxis
                    type="number"
                    dataKey="rank"
                    name="Rank"
                    label={{ value: "Ranked Order", position: "bottom", offset: 0, fontSize: 10, fill: "#94A3B8" }}
                    tick={{ fill: "#94A3B8", fontSize: 10 }}
                    stroke="#334155"
                  />
                  <YAxis
                    type="number"
                    dataKey="yValue"
                    name={selectedY}
                    tick={{ fill: "#94A3B8", fontSize: 10 }}
                    stroke="#334155"
                  />
                  <Tooltip
                    cursor={{ strokeDasharray: "2 2", stroke: "#38BDF8" }}
                    content={({ payload }) => {
                      if (!payload || payload.length === 0) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2.5 rounded shadow-xl text-xs font-mono space-y-1">
                          <p className="font-bold text-[#38BDF8]">{data.id}</p>
                          <p>{selectedY}: <strong className="text-white">{data.yValue}</strong></p>
                          <p>Status: <span className={data.status === "BAD" ? "text-[#F43F5E] font-bold" : data.status === "GOOD" ? "text-[#10B981] font-bold" : "text-[#94A3B8]"}>{data.status} {data.code && `(${data.code})`}</span></p>
                        </div>
                      );
                    }}
                  />
                  {stats && (
                    <ReferenceLine
                      y={stats.median}
                      stroke="#C084FC"
                      strokeDasharray="3 3"
                      label={{ value: `Median (${stats.median.toFixed(1)})`, fill: "#C084FC", fontSize: 10, position: "insideTopRight" }}
                    />
                  )}
                  <Scatter
                    data={orderedData}
                    onClick={(entry) => {
                      if (entry && entry.id) {
                        if (selectedBadIds.includes(entry.id)) {
                          toggleBad(entry.id);
                        } else if (selectedGoodIds.includes(entry.id)) {
                          toggleGood(entry.id);
                        } else if (selectedBadIds.length < 5) {
                          toggleBad(entry.id);
                        } else if (selectedGoodIds.length < 5) {
                          toggleGood(entry.id);
                        }
                      }
                    }}
                  >
                    {orderedData.map((entry, index) => {
                      let fill = "#334155";
                      let r = 4;
                      if (entry.status === "BAD") {
                        fill = "#F43F5E";
                        r = 6;
                      } else if (entry.status === "GOOD") {
                        fill = "#10B981";
                        r = 6;
                      }
                      return (
                        <Cell
                          key={`cell-${index}`}
                          fill={fill}
                          r={r}
                          cursor="pointer"
                          stroke={entry.status !== "NORMAL" ? "#FFFFFF" : "none"}
                          strokeWidth={1}
                        />
                      );
                    })}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Histogram Bins */}
          <div className="tech-viz-container flex flex-col h-[220px]">
            <div className="p-2.5 border-b border-[#334155] flex justify-between items-center bg-[#0F172A] text-xs font-mono">
              <span className="font-bold text-[#F1F5F9]">Y FREQUENCY DENSITY HISTOGRAM</span>
              <span className="text-[#94A3B8] text-[11px]">BIN DISTRIBUTION</span>
            </div>
            <div className="flex-1 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={histogramData} margin={{ top: 10, right: 10, bottom: 15, left: 0 }}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="binLabel" fontSize={9} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                  <YAxis fontSize={10} tick={{ fill: "#94A3B8" }} stroke="#334155" allowDecimals={false} />
                  <Tooltip
                    content={({ payload }) => {
                      if (!payload || payload.length === 0) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2 rounded text-xs font-mono">
                          <p className="font-bold text-[#38BDF8]">Bin: {data.binLabel}</p>
                          <p>Count: {data.count}</p>
                          <p className="text-[#F43F5E]">BAD in bin: {data.badCount}</p>
                          <p className="text-[#10B981]">GOOD in bin: {data.goodCount}</p>
                        </div>
                      );
                    }}
                  />
                  <Bar dataKey="count" fill="#475569" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Technical Side Panel (Matching Design HTML) */}
        <div className="space-y-4">
          {/* Data Health Card */}
          <div className="tech-grid-card p-3.5 space-y-2.5">
            <div className="text-[10px] uppercase font-mono font-bold text-[#38BDF8] tracking-wider">
              Data Health Profile
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between py-1 border-b border-[#334155]">
                <span className="text-[#94A3B8]">Duplicates</span>
                <span className={validation?.has_duplicate_ids ? "text-[#F59E0B]" : "text-[#10B981]"}>
                  {validation?.has_duplicate_ids ? `${validation.duplicate_id_count} IDs` : "None (0)"}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#334155]">
                <span className="text-[#94A3B8]">Missing Values</span>
                <span className="text-[#10B981]">0.0%</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#334155]">
                <span className="text-[#94A3B8]">Zero Var X</span>
                <span className={validation?.constant_columns?.length ? "text-[#F59E0B]" : "text-[#10B981]"}>
                  {validation?.constant_columns?.length || 0} Columns
                </span>
              </div>
            </div>
          </div>

          {/* Categorical Variables */}
          <div className="tech-grid-card p-3.5 space-y-2">
            <div className="text-[10px] uppercase font-mono font-bold text-[#94A3B8]">
              Categorical Variables
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {validation?.categorical_columns?.length ? (
                validation.categorical_columns.map((c) => (
                  <span key={c} className="tech-tag">
                    {c}
                  </span>
                ))
              ) : (
                <span className="text-[11px] font-mono text-[#64748B]">None detected</span>
              )}
            </div>
          </div>

          {/* Selection Queue Inspector */}
          <div className="tech-grid-card p-3.5 space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-[#334155]">
              <span className="text-[10px] uppercase font-mono font-bold text-[#38BDF8]">
                Selection Queue (5+5)
              </span>
              <span className="text-[10px] font-mono text-[#94A3B8]">
                {selectedBadIds.length + selectedGoodIds.length}/10 SELECTED
              </span>
            </div>

            <div className="font-mono text-xs space-y-1 max-h-56 overflow-y-auto">
              {/* BAD group items */}
              {selectedBadIds.map((id, idx) => {
                const obs = parsedObservations.find((o) => o.id === id);
                return (
                  <div key={id} className="flex justify-between items-center text-[#F43F5E] bg-[#F43F5E]/10 px-2 py-1 rounded border border-[#F43F5E]/30">
                    <span>[B{idx + 1}] ID: {id}</span>
                    <span className="font-bold">{obs?.yValue}</span>
                    <button onClick={() => toggleBad(id)} className="text-[#FB7185] hover:text-white cursor-pointer ml-1">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}

              {selectedBadIds.length < 5 && (
                <div className="text-[11px] text-[#F43F5E]/60 italic px-2 py-0.5">
                  + Needs {5 - selectedBadIds.length} more BAD
                </div>
              )}

              <div className="border-t border-[#334155] my-2"></div>

              {/* GOOD group items */}
              {selectedGoodIds.map((id, idx) => {
                const obs = parsedObservations.find((o) => o.id === id);
                return (
                  <div key={id} className="flex justify-between items-center text-[#10B981] bg-[#10B981]/10 px-2 py-1 rounded border border-[#10B981]/30">
                    <span>[G{idx + 1}] ID: {id}</span>
                    <span className="font-bold">{obs?.yValue}</span>
                    <button onClick={() => toggleGood(id)} className="text-[#34D399] hover:text-white cursor-pointer ml-1">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}

              {selectedGoodIds.length < 5 && (
                <div className="text-[11px] text-[#10B981]/60 italic px-2 py-0.5">
                  + Needs {5 - selectedGoodIds.length} more GOOD
                </div>
              )}
            </div>
          </div>

          {/* Diagnostic Rules Active Card (Matching Design HTML) */}
          <div className="tech-subcard p-3 space-y-1">
            <div className="text-[10px] font-mono font-bold text-[#38BDF8] uppercase">
              Diagnostic Rules Active
            </div>
            <div className="text-[11px] font-mono text-[#94A3B8] leading-relaxed">
              Welch t-test (Independent) / Mann-Whitney U (Average Ranks for Ties) / AUC 0.5-Tie Correction / No Min(p) Rule Enforcement. DataLock Pro Engine v1.13.
            </div>
          </div>
        </div>
      </div>

      {/* Observation Table Selector */}
      <div className="tech-grid-card p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
          <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
            Observation Selection Matrix
          </h3>
          <span className="text-[11px] font-mono text-[#94A3B8]">
            Click + BAD or + GOOD to toggle
          </span>
        </div>

        <div className="overflow-x-auto border border-[#334155] rounded max-h-64 overflow-y-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0F172A] text-[#94A3B8] sticky top-0 border-b border-[#334155]">
              <tr>
                <th className="px-3 py-2">ID</th>
                <th className="px-3 py-2">{selectedY} (Y Value)</th>
                <th className="px-3 py-2">Current Designation</th>
                <th className="px-3 py-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
              {orderedData.map((obs) => {
                const isBad = selectedBadIds.includes(obs.id);
                const isGood = selectedGoodIds.includes(obs.id);
                return (
                  <tr
                    key={obs.id}
                    className={`transition ${
                      isBad
                        ? "bg-[#F43F5E]/15"
                        : isGood
                        ? "bg-[#10B981]/15"
                        : "hover:bg-[#0F172A]"
                    }`}
                  >
                    <td className="px-3 py-2 font-bold text-[#F1F5F9]">{obs.id}</td>
                    <td className="px-3 py-2 font-bold text-[#38BDF8]">{obs.yValue}</td>
                    <td className="px-3 py-2">
                      {isBad ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#F43F5E] text-white">
                          BAD [{obs.code}]
                        </span>
                      ) : isGood ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#10B981] text-[#020617]">
                          GOOD [{obs.code}]
                        </span>
                      ) : (
                        <span className="text-[#64748B] text-[11px]">Unselected</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-right space-x-2">
                      <button
                        onClick={() => toggleBad(obs.id)}
                        className={`px-2 py-1 rounded text-[11px] font-mono font-bold transition cursor-pointer ${
                          isBad
                            ? "bg-[#F43F5E] text-white"
                            : "bg-[#0F172A] text-[#FB7185] border border-[#F43F5E]/40 hover:bg-[#F43F5E]/20"
                        }`}
                      >
                        {isBad ? "Remove BAD" : "+ BAD"}
                      </button>
                      <button
                        onClick={() => toggleGood(obs.id)}
                        className={`px-2 py-1 rounded text-[11px] font-mono font-bold transition cursor-pointer ${
                          isGood
                            ? "bg-[#10B981] text-[#020617]"
                            : "bg-[#0F172A] text-[#34D399] border border-[#10B981]/40 hover:bg-[#10B981]/20"
                        }`}
                      >
                        {isGood ? "Remove GOOD" : "+ GOOD"}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
