import React, { useState } from "react";
import { 
  AlertCircle,
  CheckCircle2, 
  ChevronRight, 
  Clock,
  Code2,
  Cpu,
  FlaskConical, 
  Play, 
  RotateCcw, 
  ShieldAlert,
  ShieldCheck, 
  Terminal,
  X, 
  XCircle 
} from "lucide-react";

interface TestItem {
  id: string;
  name: string;
  category: string;
  description: string;
  status: "pending" | "running" | "passed" | "failed";
  durationMs?: number;
  output?: string;
  error?: string;
}

interface SuiteExecutionSummary {
  total: number;
  passed: number;
  failed: number;
  allPassed: boolean;
  overallStatus: "PASS" | "FAIL" | "PENDING";
  durationMs: number;
  engine: string;
  executionType: string;
  executedAt?: string;
}

interface TestVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const INITIAL_TESTS: TestItem[] = [
  {
    id: "T1",
    name: "Zero-Variance Deterministic Separation",
    category: "Parametric / Robustness",
    description: "BAD=[10]*5, GOOD=[20]*5: Verifies no fabricated t/p/d values, reports deterministic separation note.",
    status: "pending",
  },
  {
    id: "T2",
    name: "False Range Separation Resistance",
    category: "Evidence & Range",
    description: "BAD=[0,50,50,50,100], GOOD=[45,48,50,52,55]: Verifies range span does not artificially inflate evidence.",
    status: "pending",
  },
  {
    id: "T3",
    name: "Outlier Resistance & Tied AUC",
    category: "Non-Parametric / Ties",
    description: "BAD=[10,11,12,13,100], GOOD=[10,11,12,13,14]: Verifies non-parametric stability against isolated outlier.",
    status: "pending",
  },
  {
    id: "T4",
    name: "Independent Welch & Mann-Whitney Calculation",
    category: "Hypothesis Testing",
    description: "Ensures Welch and Mann-Whitney p-values are never conflated via min(p_welch, p_mw).",
    status: "pending",
  },
  {
    id: "T5",
    name: "Automated Data Validation & Hygiene",
    category: "Data Hygiene",
    description: "Detects missing values, duplicate row IDs, numeric/categorical typing.",
    status: "pending",
  },
  {
    id: "T6",
    name: "Pearson & Spearman Correlation",
    category: "Correlation",
    description: "Verifies linear and rank correlation coefficients with exact t-distribution p-values.",
    status: "pending",
  },
  {
    id: "T7",
    name: "OLS Linear Regression",
    category: "Regression",
    description: "Verifies regression slope, intercept, R², ANOVA F-test, and residual computation.",
    status: "pending",
  },
  {
    id: "T8",
    name: "Process Capability Analysis (SPC)",
    category: "SPC & Capability",
    description: "Calculates Cp, Cpk, Pp, Ppk, short/long-term standard deviations with explicit tolerance limits.",
    status: "pending",
  },
  {
    id: "T9",
    name: "Transparent Anomaly & Western Electric Rules",
    category: "Anomalies & Patterns",
    description: "Detects Tukey fences, Modified Z-score (MAD), and Western Electric shift/trend rules without asserting root cause.",
    status: "pending",
  },
  {
    id: "T10",
    name: "Full Factorial DOE Engine",
    category: "DOE",
    description: "Generates 2^k design matrices and computes main effects, interactions, and Pareto rankings.",
    status: "pending",
  },
  {
    id: "T11",
    name: "Response Surface Optimization (RSM)",
    category: "RSM Optimization",
    description: "Fits full quadratic response surface, identifies stationary points and generates 2D/3D contour predictions.",
    status: "pending",
  },
  {
    id: "T12",
    name: "5 BAD vs 5 GOOD Comparative Prioritization",
    category: "5 BAD vs 5 GOOD Workflow",
    description: "Enforces 5 BAD / 5 GOOD selection, conservative evidence labeling, and confirmation planning.",
    status: "pending",
  },
  {
    id: "T13",
    name: "Missing Value Preservation (No Zero Conversion)",
    category: "Data Hygiene & Ingestion",
    description: "X=[10, 20, NaN, 40, 50]: Verifies missing values remain missing, effective_n=4, and mean is 30.0 (NOT 24.0).",
    status: "pending",
  },
  {
    id: "T14",
    name: "Missing Value Handling Across Analytics",
    category: "Statistical Integrity",
    description: "Verifies correlation, capability, and 5 BAD/5 GOOD exclude missing observations from calculations without 0-imputation.",
    status: "pending",
  },
  {
    id: "T15",
    name: "Evidence Ranking Test A — False Range Resistance",
    category: "Evidence Prioritisation",
    description: "BAD=[0,50,50,50,100], GOOD=[45,48,50,52,55]: Verifies mean diff=0, AUC=0.50, Tier=NO / VERY WEAK, ranked below true factors.",
    status: "pending",
  },
  {
    id: "T16",
    name: "Evidence Ranking Test B — Strong True Separation",
    category: "Evidence Prioritisation",
    description: "BAD=[100..108], GOOD=[10..18]: Verifies large effect size, AUC=1.0, CONCORDANT label, VERY STRONG tier.",
    status: "pending",
  },
  {
    id: "T17",
    name: "Evidence Ranking Test C — Identical Distributions",
    category: "Evidence Prioritisation",
    description: "BAD=[10,20,30,40,50], GOOD=[10,20,30,40,50]: Verifies mean diff=0, AUC=0.50, Cohen's d=0, Tier=NO / VERY WEAK.",
    status: "pending",
  },
  {
    id: "T18",
    name: "Evidence Ranking Test D — Effect Magnitude Prioritisation",
    category: "Evidence Prioritisation",
    description: "Verifies ranking prioritises effect magnitude and separation over p-values alone without arbitrary composite scores.",
    status: "pending",
  },
  {
    id: "T19",
    name: "Evidence Ranking Test E — Zero Variance Handling",
    category: "Evidence Prioritisation",
    description: "BAD=[10]*5, GOOD=[20]*5: Verifies complete deterministic separation note, no fabricated t/p/d, and clean top tiering.",
    status: "pending",
  },
  {
    id: "T20",
    name: "Mann-Whitney U Exact Permutation & Tie Correction",
    category: "Non-Parametric / Ties",
    description: "Verifies exact permutation p=2/252 for no-tie small sample, accurate average ranks and tie labeling for tied cases.",
    status: "pending",
  },
  {
    id: "T21",
    name: "Welch t-Test Asymmetric Zero Variance Handling",
    category: "Parametric / Robustness",
    description: "BAD=[10]*5, GOOD=[15,20,25,30,35]: Verifies df=4, standard error from variable group, t=-4.24, and valid p-value.",
    status: "pending",
  },
  {
    id: "T22",
    name: "Effect Sizes (Cohen's d & Hedges' g) Exact Bias Correction",
    category: "Effect Sizes",
    description: "Verifies pooled standard deviation, exact small-sample correction factor J(df)=1 - 3/(4df-1), and Hedges' g.",
    status: "pending",
  },
  {
    id: "T23",
    name: "Constant X Variable Across All Observations",
    category: "Evidence Prioritisation",
    description: "Verifies that an X column with identical values across all 10 rows is reported as 'Constant variable' with zero variation.",
    status: "pending",
  },
  {
    id: "T24",
    name: "Small Sample Protection & Undefined Edge States",
    category: "Robustness & Edge Cases",
    description: "Verifies explicit undefined states for n=1 Welch, N<3 Correlation, Constant-X Correlation, Zero-SD Capability, and Invalid Specs.",
    status: "pending",
  },
  {
    id: "T25",
    name: "Numerical Stability Across Extreme Scales & Negatives",
    category: "Numerical Invariants",
    description: "Tests numerical stability on negative sub-zero numbers, micro-scale (10^-8), and macro-scale (10^8) without loss of precision.",
    status: "pending",
  },
  {
    id: "T26",
    name: "Test A — Stable Observation IDs Across Sorting/Filtering",
    category: "Workflow & Integrity",
    description: "Verifies selected BAD/GOOD observations remain attached to original observation IDs regardless of sorting.",
    status: "pending",
  },
  {
    id: "T27",
    name: "Test B — Duplicate Measurements Preserved as Distinct Observations",
    category: "Workflow & Integrity",
    description: "Verifies identical measurements are never collapsed or merged, preserving sample weight and N.",
    status: "pending",
  },
  {
    id: "T28",
    name: "Test C — Identical Y Values Individually Selectable",
    category: "Workflow & Integrity",
    description: "Verifies observations sharing identical Y values are addressed individually without multi-select side effects.",
    status: "pending",
  },
  {
    id: "T29",
    name: "Test D — Duplicate Source IDs Detection & Preservation",
    category: "Workflow & Integrity",
    description: "Verifies duplicate source IDs are flagged as warnings while preserving all rows via stable unique internal IDs.",
    status: "pending",
  },
  {
    id: "T30",
    name: "Test E — Numeric Negative and Zero Values Preservation",
    category: "Workflow & Integrity",
    description: "Verifies legitimate zeros and negative numbers are accurately distinguished from missing values.",
    status: "pending",
  },
  {
    id: "T31",
    name: "Test F — Categorical Discrete Variable Association",
    category: "Workflow & Integrity",
    description: "Verifies discrete shift/code categories (e.g. 1, 2, 3) are analyzed via Chi-square/Cramér's V.",
    status: "pending",
  },
  {
    id: "T32",
    name: "Test G — Missing Y Values Strict Selection Protection",
    category: "Workflow & Integrity",
    description: "Verifies that selecting an observation with a missing/invalid Y value halts comparison with clear error.",
    status: "pending",
  },
  {
    id: "T33",
    name: "Test H — Missing X Values Isolation Per-Variable",
    category: "Workflow & Integrity",
    description: "Verifies missing X values in an observation are omitted only for that variable without affecting others or imputing 0.",
    status: "pending",
  },
  {
    id: "T34",
    name: "Test I — Y Direction Sensitivity (Higher vs Lower Y = Worse)",
    category: "Workflow & Integrity",
    description: "Verifies orientation consistency check and direction reporting react correctly to Y orientation definitions.",
    status: "pending",
  },
  {
    id: "T35",
    name: "Test J — Dataset Replacement & Hygiene State Invalidation",
    category: "Workflow & Integrity",
    description: "Verifies that uploading or switching to a new dataset fully resets column schemas, counts, and observation IDs.",
    status: "pending",
  },
  {
    id: "T36",
    name: "Test K — Exactly 5 BAD + 5 GOOD Strict Enforcement",
    category: "Workflow & Integrity",
    description: "Verifies exact 5+5 sample size and strict mutual exclusivity (no overlapping observations).",
    status: "pending",
  },
  {
    id: "T37",
    name: "Test A — Current Dataset Association & Metadata Integrity",
    category: "Workflow & Integrity",
    description: "Verifies that analysis results are explicitly tagged with dataset ID, request token, Y variable, and observation IDs.",
    status: "pending",
  },
  {
    id: "T38",
    name: "Test B — Dataset Replacement Invalidation",
    category: "Workflow & Integrity",
    description: "Verifies that replacing the active dataset strictly invalidates and discards all previous statistical comparison results.",
    status: "pending",
  },
  {
    id: "T39",
    name: "Test C — Y Variable Selection Change Invalidation",
    category: "Workflow & Integrity",
    description: "Verifies that modifying the target Y variable automatically invalidates previously calculated comparison results.",
    status: "pending",
  },
  {
    id: "T40",
    name: "Test D — BAD Direction Sensitivity & Invalidation",
    category: "Workflow & Integrity",
    description: "Verifies that changing BAD direction orientation updates consistency diagnosis and invalidates stale state.",
    status: "pending",
  },
  {
    id: "T41",
    name: "Test E — Observation Selection Change Invalidation",
    category: "Workflow & Integrity",
    description: "Verifies that altering any individual BAD or GOOD observation selection invalidates prior analysis results.",
    status: "pending",
  },
  {
    id: "T42",
    name: "Test F — Invalid Observation ID Rejection",
    category: "Workflow & Integrity",
    description: "Verifies that observation IDs not present in the current active dataset are strictly rejected by the Python engine.",
    status: "pending",
  },
  {
    id: "T43",
    name: "Test G — Overlapping BAD/GOOD Observation IDs Rejection",
    category: "Workflow & Integrity",
    description: "Verifies that selecting the same observation ID in both BAD and GOOD groups is strictly rejected.",
    status: "pending",
  },
  {
    id: "T44",
    name: "Test H — Incorrect Number of Observations Strict Rejection",
    category: "Workflow & Integrity",
    description: "Verifies that selections with other than exactly 5 BAD and 5 GOOD observations are rejected immediately.",
    status: "pending",
  },
  {
    id: "T45",
    name: "Test I — Stale Response & Request Identity Token Protection",
    category: "Workflow & Integrity",
    description: "Verifies that responses with mismatched or outdated analysis request tokens are safely discarded to prevent race conditions.",
    status: "pending",
  },
  {
    id: "T46",
    name: "Test J — API Engine Unavailable Protection",
    category: "Workflow & Integrity",
    description: "Verifies that API/Python failures explicitly communicate engine unavailability and never display fabricated or fallback stats.",
    status: "pending",
  },
  {
    id: "T47",
    name: "Test K — Undefined Statistics Explicit Representation",
    category: "Workflow & Integrity",
    description: "Verifies that zero variance and mathematically undefined statistics return explicit null/None instead of arbitrary zero.",
    status: "pending",
  },
  {
    id: "T48",
    name: "Test L — Real Python Statistical Test Runner Authenticity",
    category: "Workflow & Integrity",
    description: "Verifies that the analytical engine executes real, deterministic Python statistical algorithms without simulation or fabrication.",
    status: "pending",
  },
];

export const TestVerificationModal: React.FC<TestVerificationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [tests, setTests] = useState<TestItem[]>(INITIAL_TESTS);
  const [isRunningAll, setIsRunningAll] = useState(false);
  const [summary, setSummary] = useState<SuiteExecutionSummary | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const runAllTests = async () => {
    setIsRunningAll(true);
    setErrorMessage(null);

    // Set all to running state
    setTests((prev) =>
      prev.map((t) => ({ ...t, status: "running", output: undefined, error: undefined }))
    );

    try {
      const res = await fetch("/api/run-tests");
      if (!res.ok) {
        throw new Error(`HTTP error ${res.status}: ${res.statusText}`);
      }

      const data = await res.json();
      
      const realTests: any[] = Array.isArray(data.tests) ? data.tests : [];
      
      // Update tests state based on real python test engine output
      setTests((prev) =>
        prev.map((initTest, idx) => {
          const match = realTests.find(
            (rt: any) =>
              rt.id === initTest.id ||
              rt.name?.toLowerCase() === initTest.name?.toLowerCase() ||
              realTests[idx]?.id === initTest.id
          ) || realTests[idx];

          if (match) {
            const isPass = match.status === "PASS";
            return {
              ...initTest,
              name: match.name || initTest.name,
              category: match.category || initTest.category,
              description: match.description || initTest.description,
              status: isPass ? "passed" : "failed",
              durationMs: match.duration_ms !== undefined ? match.duration_ms : undefined,
              output: match.details || match.output || (isPass ? "PASS" : "FAIL"),
              error: match.error || (!isPass ? match.details : undefined),
            };
          }

          // Fallback if test array wasn't itemized
          const globalPass = data.all_passed ?? (data.exit_code === 0);
          return {
            ...initTest,
            status: globalPass ? "passed" : "failed",
            output: globalPass ? "PASS: Verified via test_engine.py" : "FAIL",
          };
        })
      );

      const passedCount = Number(data.passed ?? (data.all_passed ? 19 : 0));
      const totalCount = Number(data.total ?? 19);
      const failedCount = Number(data.failed ?? (totalCount - passedCount));
      const allPassed = Boolean(data.all_passed ?? (failedCount === 0 && passedCount === totalCount));

      setSummary({
        total: totalCount,
        passed: passedCount,
        failed: failedCount,
        allPassed: allPassed,
        overallStatus: allPassed ? "PASS" : "FAIL",
        durationMs: Number(data.duration_ms || data.server_duration_ms || 0),
        engine: data.engine || "Python (test_engine.py)",
        executionType: data.execution_type || "Real Python Statistical Suite Execution",
        executedAt: new Date().toLocaleTimeString(),
      });

      if (data.error_output) {
        setErrorMessage(data.error_output);
      }
    } catch (err: any) {
      console.error("Test execution failed:", err);
      setErrorMessage(`Failed to execute Python test suite: ${err.message}`);
      setTests((prev) =>
        prev.map((t) => ({
          ...t,
          status: "failed",
          output: `Execution error: ${err.message}`,
        }))
      );
      setSummary({
        total: 19,
        passed: 0,
        failed: 19,
        allPassed: false,
        overallStatus: "FAIL",
        durationMs: 0,
        engine: "Python (test_engine.py)",
        executionType: "Execution Failed",
        executedAt: new Date().toLocaleTimeString(),
      });
    } finally {
      setIsRunningAll(false);
    }
  };

  const passedCount = tests.filter((t) => t.status === "passed").length;
  const failedCount = tests.filter((t) => t.status === "failed").length;
  const isExecuted = summary !== null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1E293B] border border-[#334155] rounded max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl font-mono">
        {/* Header */}
        <div className="p-4 border-b border-[#334155] flex items-center justify-between bg-[#0F172A]">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#10B981]" />
            <div>
              <h3 className="text-sm font-bold text-[#F1F5F9] uppercase tracking-wider">
                Statistical Engine Automated Verification ({tests.length} Benchmark Invariant Tests)
              </h3>
              <div className="flex items-center gap-2 text-[10px] text-[#38BDF8] mt-0.5">
                <Terminal className="w-3 h-3 text-[#38BDF8]" />
                <span>Backend Execution: <code className="text-[#F1F5F9] font-bold">python3 test_engine.py --json</code></span>
              </div>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer p-1 rounded hover:bg-[#334155]"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status Bar */}
        <div className="p-3 bg-[#0F172A] border-b border-[#334155] flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-3">
            <span className="text-[#94A3B8]">
              Suite Result:{" "}
              {isExecuted ? (
                <strong
                  className={
                    summary.allPassed
                      ? "text-[#10B981] bg-[#10B981]/10 px-2 py-0.5 rounded border border-[#10B981]/30 font-bold"
                      : "text-[#EF4444] bg-[#EF4444]/10 px-2 py-0.5 rounded border border-[#EF4444]/30 font-bold"
                  }
                >
                  {summary.overallStatus} ({summary.passed}/{summary.total} Passed)
                </strong>
              ) : (
                <strong className="text-[#64748B]">Ready to execute</strong>
              )}
            </span>

            {summary && (
              <span className="text-[11px] text-[#94A3B8] flex items-center gap-1">
                <Clock className="w-3 h-3 text-[#64748B]" />
                <span>{summary.durationMs.toFixed(2)}ms</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={runAllTests}
              disabled={isRunningAll}
              className="tech-btn-run px-3.5 py-1.5 rounded flex items-center gap-1.5 text-xs font-bold cursor-pointer disabled:opacity-50"
            >
              <Play className={`w-3.5 h-3.5 ${isRunningAll ? "animate-spin" : ""}`} />
              <span>{isRunningAll ? "EXECUTING PYTHON SUITE..." : "RUN FULL TEST SUITE"}</span>
            </button>
          </div>
        </div>

        {/* Real Python Engine Verification Banner */}
        <div className="px-4 py-2 bg-[#0A0F1D] border-b border-[#334155] flex items-center justify-between text-[11px] text-[#94A3B8]">
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-[#10B981]" />
            <span>Execution Source:</span>
            <span className="text-[#10B981] font-bold">Real Python Test Engine (`test_engine.py`)</span>
          </div>
          {summary?.executedAt && (
            <span className="text-[#64748B] text-[10px]">
              Executed at {summary.executedAt}
            </span>
          )}
        </div>

        {/* Error message if any */}
        {errorMessage && (
          <div className="m-3 p-3 bg-[#EF4444]/10 border border-[#EF4444]/30 rounded flex items-start gap-2 text-xs text-[#FCA5A5]">
            <ShieldAlert className="w-4 h-4 shrink-0 text-[#EF4444] mt-0.5" />
            <div className="overflow-x-auto font-mono text-[11px]">
              {errorMessage}
            </div>
          </div>
        )}

        {/* Tests List */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1 text-xs">
          {tests.map((test) => (
            <div
              key={test.id}
              className={`p-3 rounded border transition flex flex-col sm:flex-row sm:items-start justify-between gap-3 ${
                test.status === "passed"
                  ? "bg-[#10B981]/10 border-[#10B981]/30 text-[#F1F5F9]"
                  : test.status === "failed"
                  ? "bg-[#EF4444]/10 border-[#EF4444]/40 text-[#F1F5F9]"
                  : test.status === "running"
                  ? "bg-[#38BDF8]/10 border-[#38BDF8] text-[#F1F5F9]"
                  : "bg-[#0F172A] border-[#334155] text-[#94A3B8]"
              }`}
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-bold text-[#38BDF8]">[{test.id}]</span>
                  <span className="font-bold text-[#F1F5F9]">{test.name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 bg-[#1E293B] text-[#94A3B8] rounded border border-[#334155]">
                    {test.category}
                  </span>
                </div>
                <p className="text-[11px] text-[#94A3B8] leading-relaxed">{test.description}</p>
                {test.output && (
                  <div
                    className={`text-[10px] font-mono p-1.5 rounded mt-1 border ${
                      test.status === "passed"
                        ? "text-[#10B981] bg-[#10B981]/5 border-[#10B981]/20"
                        : "text-[#F87171] bg-[#EF4444]/10 border-[#EF4444]/30"
                    }`}
                  >
                    <span className="font-bold">{test.status === "passed" ? "Result: " : "Error/Result: "}</span>
                    {test.output}
                  </div>
                )}
                {test.error && test.status === "failed" && (
                  <div className="text-[10px] font-mono text-[#FCA5A5] bg-[#EF4444]/20 p-1.5 rounded border border-[#EF4444]/40 mt-1 whitespace-pre-wrap">
                    {test.error}
                  </div>
                )}
              </div>

              <div className="shrink-0 flex items-center gap-2 self-start sm:self-center">
                {test.durationMs !== undefined && (
                  <span className="text-[10px] text-[#64748B] font-mono">{test.durationMs}ms</span>
                )}
                {test.status === "passed" ? (
                  <span className="flex items-center gap-1 text-[#10B981] bg-[#10B981]/20 px-2 py-0.5 rounded border border-[#10B981]/40 font-bold text-xs">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>PASS</span>
                  </span>
                ) : test.status === "failed" ? (
                  <span className="flex items-center gap-1 text-[#EF4444] bg-[#EF4444]/20 px-2 py-0.5 rounded border border-[#EF4444]/40 font-bold text-xs">
                    <XCircle className="w-3.5 h-3.5" />
                    <span>FAIL</span>
                  </span>
                ) : test.status === "running" ? (
                  <span className="text-[#38BDF8] font-bold animate-pulse text-xs bg-[#38BDF8]/20 px-2 py-0.5 rounded border border-[#38BDF8]/40">
                    EXECUTING...
                  </span>
                ) : (
                  <span className="text-[#64748B] text-xs bg-[#1E293B] px-2 py-0.5 rounded border border-[#334155]">
                    PENDING
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#334155] bg-[#0F172A] flex items-center justify-between text-xs">
          <div className="text-[11px] text-[#94A3B8]">
            {isExecuted ? (
              <span>
                Total: <strong className="text-[#F1F5F9]">{summary.total}</strong> | Passed:{" "}
                <strong className="text-[#10B981]">{summary.passed}</strong> | Failed:{" "}
                <strong className={summary.failed > 0 ? "text-[#EF4444]" : "text-[#94A3B8]"}>
                  {summary.failed}
                </strong>
              </span>
            ) : (
              <span>Press &quot;RUN FULL TEST SUITE&quot; to execute real Python invariants check.</span>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#1E293B] hover:bg-[#334155] text-[#F1F5F9] rounded text-xs font-bold cursor-pointer transition"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
