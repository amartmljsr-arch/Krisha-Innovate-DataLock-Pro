import React, { useState, useMemo } from "react";
import { 
  BarChart2, 
  ChevronRight, 
  HelpCircle, 
  Layers, 
  PieChart, 
  Sliders 
} from "lucide-react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell 
} from "recharts";
import { ValidationResult } from "../types";

interface StratificationViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  selectedY: string;
}

export const StratificationView: React.FC<StratificationViewProps> = ({
  rawData,
  validation,
  selectedY,
}) => {
  const categoricalCols = validation?.categorical_columns || [];
  const [selectedFactor, setSelectedFactor] = useState<string>(
    categoricalCols[0] || ""
  );

  // Group stats
  const groupStats = useMemo(() => {
    if (!selectedFactor || !selectedY || rawData.length === 0) return [];

    const groups: Record<string, number[]> = {};
    rawData.forEach((row) => {
      const cat = String(row[selectedFactor] ?? "Unknown");
      const yVal = parseFloat(row[selectedY]);
      if (!isNaN(yVal)) {
        if (!groups[cat]) groups[cat] = [];
        groups[cat].push(yVal);
      }
    });

    return Object.entries(groups).map(([cat, vals]) => {
      const n = vals.length;
      const mean = vals.reduce((a, b) => a + b, 0) / n;
      const sorted = [...vals].sort((a, b) => a - b);
      const min = sorted[0];
      const max = sorted[n - 1];
      const variance =
        n > 1
          ? vals.reduce((acc, v) => acc + (v - mean) ** 2, 0) / (n - 1)
          : 0;
      const stdev = Math.sqrt(variance);

      return {
        category: cat,
        count: n,
        mean: parseFloat(mean.toFixed(2)),
        stdev: parseFloat(stdev.toFixed(2)),
        min: parseFloat(min.toFixed(2)),
        max: parseFloat(max.toFixed(2)),
      };
    });
  }, [rawData, selectedFactor, selectedY]);

  if (categoricalCols.length === 0) {
    return (
      <div className="tech-grid-card p-12 text-center space-y-3">
        <Layers className="w-12 h-12 text-[#64748B] mx-auto" />
        <h3 className="text-sm font-bold text-[#F1F5F9] font-mono uppercase tracking-wider">
          No Categorical Factors Detected
        </h3>
        <p className="text-xs text-[#94A3B8] max-w-md mx-auto font-mono">
          Stratification requires discrete categorical factors (e.g. Shift, Machine, Operator, Lot ID, Tool Cavity).
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Top Diagnostic Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">04. STRATIFICATION ENGINE</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              TARGET: {selectedY}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Categorical Factor Stratification & Sub-Group Variance
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Slice and disaggregate the target manufacturing response (Y) across operational discrete factors (Shifts, Operators, Batches, Machines) to identify process clustering.
          </p>
        </div>

        {/* Factor Selector */}
        <div className="flex items-center gap-2 bg-[#0F172A] px-3 py-2 rounded border border-[#334155]">
          <span className="text-[10px] font-mono uppercase text-[#94A3B8]">
            Factor:
          </span>
          <select
            value={selectedFactor}
            onChange={(e) => setSelectedFactor(e.target.value)}
            className="font-mono font-bold text-xs bg-transparent text-[#38BDF8] focus:outline-none cursor-pointer"
          >
            {categoricalCols.map((col) => (
              <option key={col} value={col} className="bg-[#1E293B] text-[#F1F5F9]">
                {col}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Grid: Bar Chart on Left, Data Grid on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Sub-Group Mean Comparison Chart */}
        <div className="tech-viz-container p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
            <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
              Sub-Group Mean Response ({selectedY} by {selectedFactor})
            </span>
            <span className="text-[10px] font-mono text-[#38BDF8]">
              {groupStats.length} GROUPS
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={groupStats} margin={{ top: 15, right: 20, bottom: 20, left: 10 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.6} />
                <XAxis dataKey="category" fontSize={10} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                <YAxis fontSize={10} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                <Tooltip
                  content={({ payload }) => {
                    if (!payload || payload.length === 0) return null;
                    const d = payload[0].payload;
                    return (
                      <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2 rounded text-xs font-mono space-y-1">
                        <p className="font-bold text-[#38BDF8]">Group: {d.category}</p>
                        <p>Count (n): {d.count}</p>
                        <p>Mean: <strong className="text-white">{d.mean}</strong></p>
                        <p>Std Dev: {d.stdev}</p>
                        <p>Range: [{d.min}, {d.max}]</p>
                      </div>
                    );
                  }}
                />
                <Bar dataKey="mean" radius={[3, 3, 0, 0]}>
                  {groupStats.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={index % 2 === 0 ? "#38BDF8" : "#818CF8"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Stratification Breakdown Data Grid */}
        <div className="tech-grid-card p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
            <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
              Sub-Group Summary Statistics
            </span>
          </div>

          <div className="overflow-x-auto border border-[#334155] rounded">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0F172A] text-[#94A3B8] border-b border-[#334155]">
                <tr>
                  <th className="px-3 py-2">{selectedFactor} Category</th>
                  <th className="px-3 py-2">Count (n)</th>
                  <th className="px-3 py-2">Mean Y</th>
                  <th className="px-3 py-2">Std Dev (s)</th>
                  <th className="px-3 py-2">Min - Max</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
                {groupStats.map((grp) => (
                  <tr key={grp.category} className="hover:bg-[#0F172A]">
                    <td className="px-3 py-2 font-bold text-[#38BDF8]">{grp.category}</td>
                    <td className="px-3 py-2">{grp.count}</td>
                    <td className="px-3 py-2 font-bold text-[#F1F5F9]">{grp.mean}</td>
                    <td className="px-3 py-2 text-[#94A3B8]">{grp.stdev}</td>
                    <td className="px-3 py-2 text-[#64748B]">
                      {grp.min} - {grp.max}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
