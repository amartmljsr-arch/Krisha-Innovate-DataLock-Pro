import React, { useState, useEffect, useMemo } from "react";
import { 
  CheckCircle2, 
  HelpCircle, 
  Layers, 
  ScatterChart as ScatterIcon, 
  Sparkles,
  RefreshCw
} from "lucide-react";
import { 
  ResponsiveContainer, 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell 
} from "recharts";
import { ValidationResult } from "../types";

interface CorrelationViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  selectedY: string;
}

export const CorrelationView: React.FC<CorrelationViewProps> = ({
  rawData,
  validation,
  selectedY,
}) => {
  const numericCols = validation?.numeric_columns || [];
  const [selectedX1, setSelectedX1] = useState<string>(numericCols[0] || "");
  const [selectedX2, setSelectedX2] = useState<string>(selectedY || numericCols[1] || "");
  const [correlationData, setCorrelationData] = useState<{
    pearson: Record<string, Record<string, number | null>>;
    spearman: Record<string, Record<string, number | null>>;
  } | null>(null);
  const [method, setMethod] = useState<"pearson" | "spearman">("pearson");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (numericCols.length === 0 || rawData.length === 0) return;
    
    let isMounted = true;
    setIsLoading(true);
    setErrorMessage(null);

    fetch("/api/correlation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        data: rawData,
        columns: numericCols,
      }),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Analysis engine unavailable. No statistical result was generated.");
        return res.json();
      })
      .then((data) => {
        if (isMounted) {
          if (data.error) {
            setErrorMessage(data.error);
          } else {
            setCorrelationData(data);
          }
        }
      })
      .catch((err) => {
        if (isMounted) {
          setErrorMessage(err.message || "Analysis engine unavailable. No statistical result was generated.");
        }
      })
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [rawData, numericCols]);

  const activeMatrix = correlationData ? correlationData[method] : null;

  // Scatter plot data between selected pair
  const scatterData = useMemo(() => {
    if (!selectedX1 || !selectedX2 || rawData.length === 0) return [];
    return rawData
      .map((r, i) => ({
        id: String(r._dl_id ?? r.id ?? `Obs_${i + 1}`),
        x: parseFloat(r[selectedX1]),
        y: parseFloat(r[selectedX2]),
      }))
      .filter((d) => !isNaN(d.x) && !isNaN(d.y));
  }, [rawData, selectedX1, selectedX2]);

  const getHeatmapColor = (val: number | null | undefined) => {
    if (val === null || val === undefined || isNaN(val)) return "bg-[#0F172A] text-[#64748B]";
    if (val >= 0.999) return "bg-[#38BDF8] text-[#020617] font-bold";
    if (val > 0.7) return "bg-[#38BDF8]/40 text-[#38BDF8] font-bold";
    if (val > 0.4) return "bg-[#38BDF8]/20 text-[#7DD3FC]";
    if (val < -0.7) return "bg-[#F43F5E]/40 text-[#FB7185] font-bold";
    if (val < -0.4) return "bg-[#F43F5E]/20 text-[#FDA4AF]";
    return "bg-[#0F172A] text-[#94A3B8]";
  };

  return (
    <div className="space-y-5">
      {/* Top Diagnostic Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">07. MULTIVARIATE CORRELATION MATRIX</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              PYTHON AUTHORITATIVE ENGINE
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Multivariate Cross-Correlation Heatmap & Pairwise Scatter Matrix
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Inspect collinearity between candidate parameters and the target output Y. 
            Identify strong positive (cyan) and negative (rose) associations calculated by the Python statistical engine.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-[#0F172A] p-1 border border-[#334155] rounded shrink-0">
          <button
            onClick={() => setMethod("pearson")}
            className={`px-3 py-1 text-xs font-mono font-bold rounded transition cursor-pointer ${
              method === "pearson"
                ? "bg-[#38BDF8] text-[#020617]"
                : "text-[#94A3B8] hover:text-[#F1F5F9]"
            }`}
          >
            PEARSON (r)
          </button>
          <button
            onClick={() => setMethod("spearman")}
            className={`px-3 py-1 text-xs font-mono font-bold rounded transition cursor-pointer ${
              method === "spearman"
                ? "bg-[#38BDF8] text-[#020617]"
                : "text-[#94A3B8] hover:text-[#F1F5F9]"
            }`}
          >
            SPEARMAN (ρ)
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="p-3 bg-[#F43F5E]/10 border border-[#F43F5E]/30 rounded text-xs font-mono text-[#FB7185]">
          {errorMessage}
        </div>
      )}

      {/* Main Grid: Heatmap on Left, Interactive Scatter on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Heatmap Grid */}
        <div className="lg:col-span-2 tech-grid-card p-4 space-y-3 overflow-x-auto">
          <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
            <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
              {method === "pearson" ? "Pearson Correlation Matrix (r)" : "Spearman Rank Correlation Matrix (ρ)"}
            </span>
            <span className="text-[10px] font-mono text-[#38BDF8]">
              {isLoading ? "CALCULATING (PYTHON)..." : `${numericCols.length} NUMERIC VARIABLES`}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center text-xs font-mono border-collapse">
              <thead>
                <tr>
                  <th className="p-2 text-left text-[#94A3B8] border-b border-[#334155]"></th>
                  {numericCols.map((col) => (
                    <th
                      key={col}
                      className={`p-2 font-bold truncate max-w-[90px] border-b border-[#334155] ${
                        col === selectedY ? "text-[#38BDF8]" : "text-[#CBD5E1]"
                      }`}
                      title={col}
                    >
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {numericCols.map((rCol) => (
                  <tr key={rCol}>
                    <td
                      className={`p-2 text-left font-bold border-r border-[#334155] truncate max-w-[120px] ${
                        rCol === selectedY ? "text-[#38BDF8]" : "text-[#CBD5E1]"
                      }`}
                      title={rCol}
                    >
                      {rCol}
                    </td>
                    {numericCols.map((cCol) => {
                      const rVal = activeMatrix ? activeMatrix[rCol]?.[cCol] : null;
                      return (
                        <td
                          key={cCol}
                          onClick={() => {
                            setSelectedX1(rCol);
                            setSelectedX2(cCol);
                          }}
                          className={`p-2 border border-[#334155]/40 transition cursor-pointer hover:ring-1 hover:ring-[#38BDF8] ${getHeatmapColor(
                            rVal
                          )}`}
                          title={`${rCol} vs ${cCol}: ${method === "pearson" ? "r" : "ρ"} = ${rVal !== null && rVal !== undefined ? rVal : "N/A"}`}
                        >
                          {rVal !== null && rVal !== undefined ? rVal.toFixed(2) : "N/A"}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pairwise Scatter Inspector */}
        <div className="tech-viz-container p-4 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
              <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
                Pairwise Scatter Plot
              </span>
              <span className="text-[10px] font-mono text-[#38BDF8]">
                {method === "pearson" ? "r" : "ρ"} = {activeMatrix?.[selectedX1]?.[selectedX2] !== undefined && activeMatrix?.[selectedX1]?.[selectedX2] !== null ? activeMatrix[selectedX1][selectedX2]?.toFixed(3) : "N/A"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 my-2 font-mono text-xs">
              <div>
                <label className="text-[10px] text-[#94A3B8] block uppercase">X-Axis</label>
                <select
                  value={selectedX1}
                  onChange={(e) => setSelectedX1(e.target.value)}
                  className="w-full p-1 bg-[#0F172A] border border-[#334155] rounded text-[#38BDF8] font-bold"
                >
                  {numericCols.map((c) => (
                    <option key={c} value={c} className="bg-[#1E293B] text-[#F1F5F9]">
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] text-[#94A3B8] block uppercase">Y-Axis</label>
                <select
                  value={selectedX2}
                  onChange={(e) => setSelectedX2(e.target.value)}
                  className="w-full p-1 bg-[#0F172A] border border-[#334155] rounded text-[#38BDF8] font-bold"
                >
                  {numericCols.map((c) => (
                    <option key={c} value={c} className="bg-[#1E293B] text-[#F1F5F9]">
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="h-56 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 10, right: 15, bottom: 20, left: 0 }}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.6} />
                  <XAxis
                    type="number"
                    dataKey="x"
                    name={selectedX1}
                    tick={{ fill: "#94A3B8", fontSize: 10 }}
                    stroke="#334155"
                  />
                  <YAxis
                    type="number"
                    dataKey="y"
                    name={selectedX2}
                    tick={{ fill: "#94A3B8", fontSize: 10 }}
                    stroke="#334155"
                  />
                  <Tooltip
                    content={({ payload }) => {
                      if (!payload || payload.length === 0) return null;
                      const d = payload[0].payload;
                      return (
                        <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2 rounded text-xs font-mono space-y-1">
                          <p className="font-bold text-[#38BDF8]">{d.id}</p>
                          <p>{selectedX1}: {d.x}</p>
                          <p>{selectedX2}: {d.y}</p>
                        </div>
                      );
                    }}
                  />
                  <Scatter data={scatterData} fill="#38BDF8" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
