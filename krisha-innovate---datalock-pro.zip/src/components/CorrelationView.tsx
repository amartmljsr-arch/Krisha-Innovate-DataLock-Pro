import React, { useState, useMemo } from "react";
import { 
  CheckCircle2, 
  HelpCircle, 
  Layers, 
  ScatterChart as ScatterIcon, 
  Sparkles 
} from "lucide-react";
import { 
  ResponsiveContainer, 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell 
} from "recharts";
import { ValidationResult } from "../types";

interface CorrelationViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  selectedY: string;
}

export const CorrelationView: React.FC<CorrelationViewProps> = ({
  rawData,
  validation,
  selectedY,
}) => {
  const numericCols = validation?.numeric_columns || [];
  const [selectedX1, setSelectedX1] = useState<string>(numericCols[0] || "");
  const [selectedX2, setSelectedX2] = useState<string>(selectedY || numericCols[1] || "");

  // Compute pairwise Pearson correlation matrix
  const correlationMatrix = useMemo(() => {
    if (numericCols.length === 0 || rawData.length === 0) return [];

    const matrix: Record<string, Record<string, number>> = {};
    numericCols.forEach((c1) => {
      matrix[c1] = {};
      const vals1 = rawData.map((r) => parseFloat(r[c1])).filter((v) => !isNaN(v));
      const n = vals1.length;
      const mean1 = vals1.reduce((a, b) => a + b, 0) / n;

      numericCols.forEach((c2) => {
        if (c1 === c2) {
          matrix[c1][c2] = 1.0;
        } else {
          const pairs = rawData
            .map((r) => [parseFloat(r[c1]), parseFloat(r[c2])])
            .filter(([v1, v2]) => !isNaN(v1) && !isNaN(v2));

          const m = pairs.length;
          if (m < 2) {
            matrix[c1][c2] = 0;
            return;
          }

          const m1 = pairs.reduce((a, p) => a + p[0], 0) / m;
          const m2 = pairs.reduce((a, p) => a + p[1], 0) / m;

          let num = 0;
          let d1 = 0;
          let d2 = 0;

          pairs.forEach(([p1, p2]) => {
            const diff1 = p1 - m1;
            const diff2 = p2 - m2;
            num += diff1 * diff2;
            d1 += diff1 * diff1;
            d2 += diff2 * diff2;
          });

          const den = Math.sqrt(d1 * d2);
          matrix[c1][c2] = den === 0 ? 0 : parseFloat((num / den).toFixed(3));
        }
      });
    });

    return matrix;
  }, [numericCols, rawData]);

  // Scatter plot data between selected pair
  const scatterData = useMemo(() => {
    if (!selectedX1 || !selectedX2 || rawData.length === 0) return [];
    return rawData
      .map((r, i) => ({
        id: String(r.id ?? `Obs_${i + 1}`),
        x: parseFloat(r[selectedX1]),
        y: parseFloat(r[selectedX2]),
      }))
      .filter((d) => !isNaN(d.x) && !isNaN(d.y));
  }, [rawData, selectedX1, selectedX2]);

  const getHeatmapColor = (val: number) => {
    if (val === 1) return "bg-[#38BDF8] text-[#020617] font-bold";
    if (val > 0.7) return "bg-[#38BDF8]/40 text-[#38BDF8] font-bold";
    if (val > 0.4) return "bg-[#38BDF8]/20 text-[#7DD3FC]";
    if (val < -0.7) return "bg-[#F43F5E]/40 text-[#FB7185] font-bold";
    if (val < -0.4) return "bg-[#F43F5E]/20 text-[#FDA4AF]";
    return "bg-[#0F172A] text-[#94A3B8]";
  };

  return (
    <div className="space-y-5">
      {/* Top Diagnostic Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">07. MULTIVARIATE CORRELATION MATRIX</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              PEARSON R ENGINE
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Multivariate Cross-Correlation Heatmap & Pairwise Scatter Matrix
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Inspect collinearity between candidate parameters and the target output Y. 
            Identify strong positive (cyan) and negative (rose) associations across all continuous production metrics.
          </p>
        </div>
      </div>

      {/* Main Grid: Heatmap on Left, Interactive Scatter on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Heatmap Grid */}
        <div className="lg:col-span-2 tech-grid-card p-4 space-y-3 overflow-x-auto">
          <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
            <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
              Pearson Correlation Matrix (r)
            </span>
            <span className="text-[10px] font-mono text-[#38BDF8]">
              {numericCols.length} NUMERIC VARIABLES
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center text-xs font-mono border-collapse">
              <thead>
                <tr>
                  <th className="p-2 text-left text-[#94A3B8] border-b border-[#334155]"></th>
                  {numericCols.map((col) => (
                    <th
                      key={col}
                      className={`p-2 font-bold truncate max-w-[90px] border-b border-[#334155] ${
                        col === selectedY ? "text-[#38BDF8]" : "text-[#CBD5E1]"
                      }`}
                      title={col}
                    >
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {numericCols.map((rCol) => (
                  <tr key={rCol}>
                    <td
                      className={`p-2 text-left font-bold border-r border-[#334155] truncate max-w-[120px] ${
                        rCol === selectedY ? "text-[#38BDF8]" : "text-[#CBD5E1]"
                      }`}
                      title={rCol}
                    >
                      {rCol}
                    </td>
                    {numericCols.map((cCol) => {
                      const rVal = correlationMatrix[rCol]?.[cCol] ?? 0;
                      return (
                        <td
                          key={cCol}
                          onClick={() => {
                            setSelectedX1(rCol);
                            setSelectedX2(cCol);
                          }}
                          className={`p-2 border border-[#334155]/40 transition cursor-pointer hover:ring-1 hover:ring-[#38BDF8] ${getHeatmapColor(
                            rVal
                          )}`}
                          title={`${rCol} vs ${cCol}: r = ${rVal}`}
                        >
                          {rVal.toFixed(2)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pairwise Scatter Inspector */}
        <div className="tech-viz-container p-4 space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
              <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
                Pairwise Scatter Plot
              </span>
              <span className="text-[10px] font-mono text-[#38BDF8]">
                r = {correlationMatrix[selectedX1]?.[selectedX2]?.toFixed(3) ?? "N/A"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 my-2 font-mono text-xs">
              <div>
                <label className="text-[10px] text-[#94A3B8] block uppercase">X-Axis</label>
                <select
                  value={selectedX1}
                  onChange={(e) => setSelectedX1(e.target.value)}
                  className="w-full p-1 bg-[#0F172A] border border-[#334155] rounded text-[#38BDF8] font-bold"
                >
                  {numericCols.map((c) => (
                    <option key={c} value={c} className="bg-[#1E293B] text-[#F1F5F9]">
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] text-[#94A3B8] block uppercase">Y-Axis</label>
                <select
                  value={selectedX2}
                  onChange={(e) => setSelectedX2(e.target.value)}
                  className="w-full p-1 bg-[#0F172A] border border-[#334155] rounded text-[#38BDF8] font-bold"
                >
                  {numericCols.map((c) => (
                    <option key={c} value={c} className="bg-[#1E293B] text-[#F1F5F9]">
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="h-56 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 10, right: 15, bottom: 20, left: 0 }}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.6} />
                  <XAxis
                    type="number"
                    dataKey="x"
                    name={selectedX1}
                    tick={{ fill: "#94A3B8", fontSize: 10 }}
                    stroke="#334155"
                  />
                  <YAxis
                    type="number"
                    dataKey="y"
                    name={selectedX2}
                    tick={{ fill: "#94A3B8", fontSize: 10 }}
                    stroke="#334155"
                  />
                  <Tooltip
                    content={({ payload }) => {
                      if (!payload || payload.length === 0) return null;
                      const d = payload[0].payload;
                      return (
                        <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2 rounded text-xs font-mono space-y-1">
                          <p className="font-bold text-[#38BDF8]">{d.id}</p>
                          <p>{selectedX1}: {d.x}</p>
                          <p>{selectedX2}: {d.y}</p>
                        </div>
                      );
                    }}
                  />
                  <Scatter data={scatterData} fill="#38BDF8" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
