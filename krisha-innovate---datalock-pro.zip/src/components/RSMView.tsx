import React, { useState } from "react";
import { 
  ArrowRight, 
  CheckCircle2, 
  HelpCircle, 
  Maximize2, 
  Minimize2, 
  Play, 
  Plus, 
  RotateCcw, 
  Sparkles, 
  Target, 
  Trash2 
} from "lucide-react";
import { 
  ResponsiveContainer, 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  Cell 
} from "recharts";
import { DOEPlanFactor, DOERunRow, RSMOptimizationResult, RSMPlanResult } from "../types";

export const RSMView: React.FC = () => {
  const [factors, setFactors] = useState<DOEPlanFactor[]>([
    { name: "Spindle_Speed", low: 1800, high: 2600, unit: "RPM" },
    { name: "Feed_Rate", low: 450, high: 750, unit: "mm/min" },
  ]);

  const [designType, setDesignType] = useState<"ccd" | "bbd">("ccd");
  const [alpha, setAlpha] = useState<number>(1.414);
  const [centerPoints, setCenterPoints] = useState<number>(4);
  const [rsmPlan, setRsmPlan] = useState<RSMPlanResult | null>(null);
  const [isPlanning, setIsPlanning] = useState(false);

  const [responses, setResponses] = useState<Record<number, number>>({});
  const [goal, setGoal] = useState<"minimize" | "maximize" | "target">("minimize");
  const [targetY, setTargetY] = useState<number>(95);
  const [optimization, setOptimization] = useState<RSMOptimizationResult | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);

  // Generate RSM Plan
  const handleGeneratePlan = async () => {
    setIsPlanning(true);
    try {
      const res = await fetch("/api/rsm/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          factors,
          design_type: designType,
          alpha,
          center_points: centerPoints,
        }),
      });
      const data = await res.json();
      setRsmPlan(data);

      // Pre-populate with realistic quadratic response surface data
      const initial: Record<number, number> = {};
      data.design_matrix.forEach((row: DOERunRow) => {
        const x1 = row.coded[factors[0]?.name] ?? 0;
        const x2 = row.coded[factors[1]?.name] ?? 0;
        // Simulated true response surface: Y = 95.0 + 8.5*x1 - 6.2*x2 + 12.0*x1^2 + 14.5*x2^2 - 7.0*x1*x2 + noise
        const simulated =
          95.0 +
          8.5 * x1 -
          6.2 * x2 +
          12.0 * x1 * x1 +
          14.5 * x2 * x2 -
          7.0 * x1 * x2 +
          (Math.random() * 1.5 - 0.75);
        initial[row.std_order] = parseFloat(simulated.toFixed(2));
      });
      setResponses(initial);
    } catch (err: any) {
      alert(`RSM Planning error: ${err.message}`);
    } finally {
      setIsPlanning(false);
    }
  };

  // Optimize RSM
  const handleOptimizeRSM = async () => {
    if (!rsmPlan) return;
    setIsOptimizing(true);
    try {
      const missingRuns = rsmPlan.design_matrix.filter(
        (row) => responses[row.std_order] === undefined || isNaN(responses[row.std_order])
      );
      if (missingRuns.length > 0) {
        alert(`Please enter valid numerical response measurements for all ${rsmPlan.design_matrix.length} RSM design runs before optimization. Missing values must not default to 0.`);
        setIsOptimizing(false);
        return;
      }

      const populated = rsmPlan.design_matrix.map((row) => ({
        ...row,
        response_y: responses[row.std_order],
      }));

      const res = await fetch("/api/rsm/optimize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          design_matrix: populated,
          factor_names: factors.map((f) => f.name),
          goal,
          target_value: goal === "target" ? targetY : null,
        }),
      });
      const data = await res.json();
      setOptimization(data);
    } catch (err: any) {
      alert(`RSM Optimization error: ${err.message}`);
    } finally {
      setIsOptimizing(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Diagnostic Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">11. RESPONSE SURFACE METHODOLOGY (RSM)</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              DESIGN: {designType.toUpperCase()}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Response Surface Optimization & Quadratic Contour Engine
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Construct Central Composite Designs (CCD) and Box-Behnken matrices to fit second-order polynomial surfaces. 
            Solve for stationary points, evaluate curvature eigenvalues, and locate optimal operating parameters.
          </p>
        </div>

        <button
          onClick={handleGeneratePlan}
          disabled={isPlanning}
          className="tech-btn-run px-5 py-2.5 rounded flex items-center gap-2 cursor-pointer shrink-0 shadow-md"
        >
          <Sparkles className="w-4 h-4" />
          <span>{rsmPlan ? "REGENERATE RSM MATRIX" : "GENERATE CCD MATRIX"}</span>
        </button>
      </div>

      {/* Experimental Design Configuration */}
      <div className="tech-grid-card p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
          <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
            Design Configuration (k = {factors.length} Continuous Factors)
          </h3>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setDesignType("ccd")}
              className={`px-2.5 py-1 rounded text-xs font-mono font-bold transition cursor-pointer ${
                designType === "ccd"
                  ? "bg-[#38BDF8]/20 text-[#38BDF8] border border-[#38BDF8]"
                  : "bg-[#0F172A] text-[#94A3B8] border border-[#334155]"
              }`}
            >
              Central Composite (CCD)
            </button>
            <button
              onClick={() => setDesignType("bbd")}
              className={`px-2.5 py-1 rounded text-xs font-mono font-bold transition cursor-pointer ${
                designType === "bbd"
                  ? "bg-[#38BDF8]/20 text-[#38BDF8] border border-[#38BDF8]"
                  : "bg-[#0F172A] text-[#94A3B8] border border-[#334155]"
              }`}
            >
              Box-Behnken (BBD)
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {factors.map((factor, idx) => (
            <div key={idx} className="p-3 bg-[#0F172A] border border-[#334155] rounded space-y-2 font-mono">
              <span className="text-xs font-bold text-[#38BDF8]">
                Factor {idx + 1}: {factor.name}
              </span>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-[#94A3B8] block uppercase">Low (-1)</label>
                  <input
                    type="number"
                    value={factor.low}
                    onChange={(e) => {
                      const next = [...factors];
                      next[idx].low = parseFloat(e.target.value) || 0;
                      setFactors(next);
                    }}
                    className="w-full px-2 py-1 text-xs bg-[#1E293B] border border-[#334155] rounded text-[#F1F5F9]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#94A3B8] block uppercase">High (+1)</label>
                  <input
                    type="number"
                    value={factor.high}
                    onChange={(e) => {
                      const next = [...factors];
                      next[idx].high = parseFloat(e.target.value) || 0;
                      setFactors(next);
                    }}
                    className="w-full px-2 py-1 text-xs bg-[#1E293B] border border-[#334155] rounded text-[#F1F5F9]"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* RSM Design Matrix & Response Inputs */}
      {rsmPlan && (
        <div className="tech-grid-card p-4 sm:p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-[#334155]">
            <div>
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                RSM Experimental Design Matrix ({rsmPlan.total_runs} Total Runs)
              </h3>
              <p className="text-[11px] text-[#94A3B8] font-mono">
                Enter measured target response Y for each factorial, axial (star), and replicated center run.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-[#0F172A] px-2 py-1 rounded border border-[#334155] text-xs font-mono">
                <span className="text-[#94A3B8]">Goal:</span>
                <select
                  value={goal}
                  onChange={(e) => setGoal(e.target.value as any)}
                  className="bg-transparent text-[#38BDF8] font-bold focus:outline-none cursor-pointer"
                >
                  <option value="minimize" className="bg-[#1E293B] text-[#F1F5F9]">Minimize Y</option>
                  <option value="maximize" className="bg-[#1E293B] text-[#F1F5F9]">Maximize Y</option>
                  <option value="target" className="bg-[#1E293B] text-[#F1F5F9]">Target Value</option>
                </select>
              </div>

              <button
                onClick={handleOptimizeRSM}
                disabled={isOptimizing}
                className="tech-btn-run px-4 py-2 rounded flex items-center gap-1.5 cursor-pointer text-xs shadow-md"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{isOptimizing ? "SOLVING..." : "SOLVE SURFACE OPTIMA"}</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto border border-[#334155] rounded max-h-72 overflow-y-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0F172A] text-[#94A3B8] sticky top-0 border-b border-[#334155]">
                <tr>
                  <th className="px-3 py-2">Std Order</th>
                  <th className="px-3 py-2">Run Type</th>
                  {factors.map((f) => (
                    <th key={f.name} className="px-3 py-2 text-[#CBD5E1]">
                      {f.name} (Actual)
                    </th>
                  ))}
                  {factors.map((f) => (
                    <th key={`c-${f.name}`} className="px-3 py-2 text-[#64748B]">
                      {f.name} (Coded)
                    </th>
                  ))}
                  <th className="px-3 py-2 bg-[#38BDF8]/10 text-[#38BDF8]">
                    Measured Response (Y)
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
                {rsmPlan.design_matrix.map((row) => (
                  <tr key={row.std_order} className="hover:bg-[#0F172A]">
                    <td className="px-3 py-2 font-bold text-[#38BDF8]">{row.std_order}</td>
                    <td className="px-3 py-2">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#334155]/40 text-[#94A3B8]">
                        {row.type}
                      </span>
                    </td>
                    {factors.map((f) => (
                      <td key={f.name} className="px-3 py-2 font-bold">
                        {row.actual[f.name]}
                      </td>
                    ))}
                    {factors.map((f) => (
                      <td key={`c-${f.name}`} className="px-3 py-2 text-[#64748B]">
                        {row.coded[f.name]?.toFixed(2)}
                      </td>
                    ))}
                    <td className="px-3 py-2 bg-[#38BDF8]/5">
                      <input
                        type="number"
                        step="any"
                        value={responses[row.std_order] ?? ""}
                        onChange={(e) => {
                          setResponses({
                            ...responses,
                            [row.std_order]: parseFloat(e.target.value) || 0,
                          });
                        }}
                        className="w-24 px-2 py-1 text-xs bg-[#0F172A] border border-[#38BDF8]/40 rounded font-bold text-[#38BDF8]"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Optimization Results */}
      {optimization && (
        <div className="tech-grid-card p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#334155]">
            <div>
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                Response Surface Solution & Stationary Characterization
              </h3>
              <p className="text-[11px] font-mono text-[#94A3B8]">
                Surface Nature: <strong className="text-[#38BDF8]">{optimization.nature_of_surface}</strong> • Model R²: {(optimization.model_summary.r_squared * 100).toFixed(2)}%
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Optimum Parameters */}
            <div className="p-4 bg-[#0F172A] border border-[#10B981]/40 rounded space-y-2 font-mono">
              <div className="flex items-center gap-2 text-[#10B981] font-bold text-xs">
                <CheckCircle2 className="w-4 h-4" />
                <span>SOLVED OPTIMAL OPERATING SETTINGS</span>
              </div>
              <div className="text-sm font-bold text-[#F1F5F9] pt-1">
                Predicted Y: <strong className="text-[#10B981]">{optimization.optimal_solution.predicted_optimal_y.toFixed(2)}</strong>
              </div>
              <div className="space-y-1 text-xs text-[#CBD5E1] pt-1">
                {Object.entries(optimization.optimal_solution.optimal_coded).map(([k, v]) => (
                  <div key={k} className="flex justify-between py-0.5 border-b border-[#334155]">
                    <span className="text-[#94A3B8]">{k}:</span>
                    <span className="font-bold text-[#38BDF8]">{Number(v).toFixed(3)} (coded)</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Stationary Point */}
            <div className="p-4 bg-[#0F172A] border border-[#334155] rounded space-y-2 font-mono">
              <div className="flex items-center gap-2 text-[#38BDF8] font-bold text-xs">
                <Target className="w-4 h-4" />
                <span>STATIONARY POINT (∂Y/∂X = 0)</span>
              </div>
              <div className="text-sm font-bold text-[#F1F5F9] pt-1">
                Nature: <strong className="text-[#38BDF8]">{optimization.nature_of_surface}</strong>
              </div>
              <div className="space-y-1 text-xs text-[#CBD5E1] pt-1">
                {Object.entries(optimization.stationary_point_coded).map(([k, v]) => (
                  <div key={k} className="flex justify-between py-0.5 border-b border-[#334155]">
                    <span className="text-[#94A3B8]">{k}:</span>
                    <span className="font-bold">{Number(v).toFixed(3)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
