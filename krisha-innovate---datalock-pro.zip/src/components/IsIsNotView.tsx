import React, { useState } from "react";
import { 
  CheckCircle2, 
  Download, 
  HelpCircle, 
  Plus, 
  RotateCcw, 
  ShieldAlert, 
  Sparkles, 
  Trash2 
} from "lucide-react";

interface IsIsNotRow {
  id: string;
  dimension: string;
  is: string;
  isNot: string;
  distinction: string;
  probableCause: string;
}

export const IsIsNotView: React.FC = () => {
  const [rows, setRows] = useState<IsIsNotRow[]>([
    {
      id: "what",
      dimension: "WHAT: Defect / Deviation",
      is: "Excessive Cycle Time (> 135s) & surface roughness Ra > 3.2µm",
      isNot: "Dimensional tolerance breach on outside diameter (OD)",
      distinction: "High tool wear & thermal chatter vibration on finish pass",
      probableCause: "Spindle speed exceeding 2400 RPM with improper feed rate",
    },
    {
      id: "where",
      dimension: "WHERE: Machine / Tool Cavity",
      is: "VMC-04 & VMC-07 (Spindle Unit #2)",
      isNot: "VMC-01, VMC-02, VMC-03 (Standard line)",
      distinction: "Ceramic spindle bearing retrofit installed last week",
      probableCause: "High thermal drift on retrofit ceramic bearing spindle",
    },
    {
      id: "when",
      dimension: "WHEN: Time / Shift / Sequence",
      is: "During Shift C (Night) and 45 mins after startup",
      isNot: "Shift A (Day) or steady-state warm operations",
      distinction: "Ambient shop floor temperature drops to 14°C at night",
      probableCause: "Coolant viscosity spike at low ambient temperature",
    },
    {
      id: "extent",
      dimension: "EXTENT: Magnitude & Trend",
      is: "Occurs on 18% of roughing passes on Batch #B42",
      isNot: "100% defective parts or uniform failure across all lots",
      distinction: "Only occurs when Depth of Cut > 1.8mm with Feed > 650 mm/min",
      probableCause: "Interaction effect between heavy depth of cut and high feed",
    },
  ]);

  const addRow = () => {
    const id = `custom_${Date.now()}`;
    setRows([
      ...rows,
      {
        id,
        dimension: "CUSTOM: Parameter",
        is: "",
        isNot: "",
        distinction: "",
        probableCause: "",
      },
    ]);
  };

  const removeRow = (id: string) => {
    setRows(rows.filter((r) => r.id !== id));
  };

  const updateRow = (id: string, field: keyof IsIsNotRow, val: string) => {
    setRows(
      rows.map((r) => {
        if (r.id === id) {
          return { ...r, [field]: val };
        }
        return r;
      })
    );
  };

  return (
    <div className="space-y-5">
      {/* Top Diagnostic Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">05. IS / IS NOT PROBLEM FORMULATION</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              METHOD: KEPNER-TREGOE PROBLEM ISOLATION
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            IS / IS NOT Comparative Problem Matrix
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Bound and isolate manufacturing problems by documenting what the defect <strong>IS</strong> versus what it could reasonably be but <strong>IS NOT</strong>. 
            Isolate physical distinctions to test candidate root causes.
          </p>
        </div>

        <button
          onClick={addRow}
          className="tech-btn-run px-4 py-2 rounded flex items-center gap-1.5 cursor-pointer shrink-0 text-xs shadow-md"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Custom Dimension</span>
        </button>
      </div>

      {/* IS / IS NOT Matrix Data Grid */}
      <div className="tech-grid-card p-4 sm:p-5 space-y-4">
        <div className="overflow-x-auto border border-[#334155] rounded">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0F172A] text-[#94A3B8] border-b border-[#334155]">
              <tr>
                <th className="px-3 py-2.5 w-48 text-[#CBD5E1]">Dimension</th>
                <th className="px-3 py-2.5 bg-[#F43F5E]/10 text-[#FB7185] border-x border-[#334155]">
                  IS (Observed Defect)
                </th>
                <th className="px-3 py-2.5 bg-[#10B981]/10 text-[#34D399] border-r border-[#334155]">
                  IS NOT (Could Be But Isn't)
                </th>
                <th className="px-3 py-2.5 bg-[#38BDF8]/10 text-[#38BDF8] border-r border-[#334155]">
                  What is the Distinction?
                </th>
                <th className="px-3 py-2.5 bg-[#C084FC]/10 text-[#C084FC]">
                  Probable Physical Cause
                </th>
                <th className="px-2 py-2.5 w-10 text-center"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
              {rows.map((row) => (
                <tr key={row.id} className="hover:bg-[#0F172A]/50">
                  <td className="px-3 py-2">
                    <input
                      type="text"
                      value={row.dimension}
                      onChange={(e) => updateRow(row.id, "dimension", e.target.value)}
                      className="w-full bg-transparent font-bold text-[#F1F5F9] focus:outline-none focus:border-b focus:border-[#38BDF8]"
                    />
                  </td>
                  <td className="px-3 py-2 bg-[#F43F5E]/5 border-x border-[#334155]">
                    <textarea
                      rows={2}
                      value={row.is}
                      onChange={(e) => updateRow(row.id, "is", e.target.value)}
                      placeholder="What is happening..."
                      className="w-full bg-[#0F172A] p-1.5 border border-[#F43F5E]/30 rounded text-xs text-[#F1F5F9] resize-none focus:outline-none focus:border-[#F43F5E]"
                    />
                  </td>
                  <td className="px-3 py-2 bg-[#10B981]/5 border-r border-[#334155]">
                    <textarea
                      rows={2}
                      value={row.isNot}
                      onChange={(e) => updateRow(row.id, "isNot", e.target.value)}
                      placeholder="What is NOT happening..."
                      className="w-full bg-[#0F172A] p-1.5 border border-[#10B981]/30 rounded text-xs text-[#F1F5F9] resize-none focus:outline-none focus:border-[#10B981]"
                    />
                  </td>
                  <td className="px-3 py-2 bg-[#38BDF8]/5 border-r border-[#334155]">
                    <textarea
                      rows={2}
                      value={row.distinction}
                      onChange={(e) => updateRow(row.id, "distinction", e.target.value)}
                      placeholder="What makes IS distinct from IS NOT..."
                      className="w-full bg-[#0F172A] p-1.5 border border-[#38BDF8]/30 rounded text-xs text-[#F1F5F9] resize-none focus:outline-none focus:border-[#38BDF8]"
                    />
                  </td>
                  <td className="px-3 py-2 bg-[#C084FC]/5">
                    <textarea
                      rows={2}
                      value={row.probableCause}
                      onChange={(e) => updateRow(row.id, "probableCause", e.target.value)}
                      placeholder="Hypothesized cause..."
                      className="w-full bg-[#0F172A] p-1.5 border border-[#C084FC]/30 rounded text-xs text-[#F1F5F9] resize-none focus:outline-none focus:border-[#C084FC]"
                    />
                  </td>
                  <td className="px-2 py-2 text-center">
                    <button
                      onClick={() => removeRow(row.id)}
                      className="text-[#64748B] hover:text-[#F43F5E] cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
