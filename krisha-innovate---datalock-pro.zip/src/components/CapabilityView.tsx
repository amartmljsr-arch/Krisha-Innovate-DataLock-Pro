import React, { useState, useEffect } from "react";
import { 
  Activity, 
  AlertTriangle, 
  ArrowRight, 
  CheckCircle2, 
  HelpCircle, 
  ShieldCheck, 
  Target 
} from "lucide-react";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  ReferenceLine 
} from "recharts";
import { CapabilityResult, ValidationResult } from "../types";

interface CapabilityViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  selectedY: string;
}

export const CapabilityView: React.FC<CapabilityViewProps> = ({
  rawData,
  validation,
  selectedY,
}) => {
  const [lsl, setLsl] = useState<string>("");
  const [usl, setUsl] = useState<string>("");
  const [target, setTarget] = useState<string>("");
  const [capability, setCapability] = useState<CapabilityResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  // Auto-initialize suggested spec limits based on Y data
  useEffect(() => {
    if (!selectedY || rawData.length === 0) return;
    const vals = rawData.map((r) => parseFloat(r[selectedY])).filter((v) => !isNaN(v));
    if (vals.length > 0) {
      const min = Math.min(...vals);
      const max = Math.max(...vals);
      const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
      const range = max - min;

      const suggestedLsl = parseFloat((min - range * 0.15).toFixed(2));
      const suggestedUsl = parseFloat((max + range * 0.15).toFixed(2));
      const suggestedTarget = parseFloat(mean.toFixed(2));

      setLsl(String(suggestedLsl));
      setUsl(String(suggestedUsl));
      setTarget(String(suggestedTarget));
    }
  }, [selectedY, rawData]);

  const handleComputeCapability = async () => {
    if (!selectedY || rawData.length === 0) return;
    setIsCalculating(true);
    try {
      const yValues = rawData.map((r) => parseFloat(r[selectedY])).filter((v) => !isNaN(v));
      const res = await fetch("/api/capability", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          data: yValues,
          lsl: lsl ? parseFloat(lsl) : null,
          usl: usl ? parseFloat(usl) : null,
          target: target ? parseFloat(target) : null,
        }),
      });
      const data = await res.json();
      setCapability(data);
    } catch (err: any) {
      alert(`Capability calculation error: ${err.message}`);
    } finally {
      setIsCalculating(false);
    }
  };

  useEffect(() => {
    if (lsl || usl) {
      handleComputeCapability();
    }
  }, [lsl, usl]);

  return (
    <div className="space-y-5">
      {/* Top Diagnostic Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">06. STATISTICAL PROCESS CAPABILITY</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              TARGET Y: {selectedY}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Process Capability Indices (Cp, Cpk, Pp, Ppk) & PPM Defect Rates
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Evaluate short-term and long-term capability metrics against customer specification limits. 
            Identify process centering bias, variance spread, and expected parts-per-million (PPM) fallout.
          </p>
        </div>

        <button
          onClick={handleComputeCapability}
          disabled={isCalculating}
          className="tech-btn-run px-5 py-2.5 rounded flex items-center gap-2 cursor-pointer shrink-0 shadow-md"
        >
          <Activity className="w-4 h-4" />
          <span>{isCalculating ? "COMPUTING..." : "RECOMPUTE CAPABILITY"}</span>
        </button>
      </div>

      {/* Specification Limits Input Bar */}
      <div className="tech-grid-card p-4 sm:p-5 space-y-3">
        <div className="text-xs font-bold font-mono text-[#F1F5F9] uppercase tracking-wider">
          Engineering Specification Limits
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono">
          <div>
            <label className="text-[10px] text-[#FB7185] block font-bold uppercase mb-1">
              Lower Specification Limit (LSL)
            </label>
            <input
              type="number"
              step="any"
              value={lsl}
              onChange={(e) => setLsl(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-[#0F172A] border border-[#F43F5E]/40 rounded font-bold text-[#F43F5E] focus:outline-none focus:border-[#F43F5E]"
            />
          </div>

          <div>
            <label className="text-[10px] text-[#38BDF8] block font-bold uppercase mb-1">
              Nominal Target (T)
            </label>
            <input
              type="number"
              step="any"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-[#0F172A] border border-[#38BDF8]/40 rounded font-bold text-[#38BDF8] focus:outline-none focus:border-[#38BDF8]"
            />
          </div>

          <div>
            <label className="text-[10px] text-[#34D399] block font-bold uppercase mb-1">
              Upper Specification Limit (USL)
            </label>
            <input
              type="number"
              step="any"
              value={usl}
              onChange={(e) => setUsl(e.target.value)}
              className="w-full px-3 py-1.5 text-xs bg-[#0F172A] border border-[#10B981]/40 rounded font-bold text-[#10B981] focus:outline-none focus:border-[#10B981]"
            />
          </div>
        </div>
      </div>

      {/* Capability Stat Boxes */}
      {capability && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">
              Potential Capability (Cp)
            </div>
            <div className="font-mono text-xl font-bold text-[#38BDF8]">
              {capability.cp !== null ? capability.cp.toFixed(3) : "N/A"}
            </div>
            <div className="text-[10px] font-mono text-[#64748B] mt-1">
              Spread / Spec Width
            </div>
          </div>

          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">
              Actual Capability (Cpk)
            </div>
            <div
              className={`font-mono text-xl font-bold ${
                capability.cpk !== null && capability.cpk !== undefined
                  ? capability.cpk >= 1.33
                    ? "text-[#10B981]"
                    : capability.cpk >= 1.0
                    ? "text-[#F59E0B]"
                    : "text-[#F43F5E]"
                  : "text-[#64748B]"
              }`}
            >
              {capability.cpk !== null && capability.cpk !== undefined ? capability.cpk.toFixed(3) : "N/A"}
            </div>
            <div className="text-[10px] font-mono text-[#64748B] mt-1">
              {capability.cpk !== null && capability.cpk !== undefined
                ? capability.cpk >= 1.33
                  ? "Capable (≥ 1.33)"
                  : capability.cpk >= 1.0
                  ? "Marginal (1.00 - 1.33)"
                  : "Incapable (< 1.00)"
                : "Spec limit required"}
            </div>
          </div>

          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">
              Performance Index (Ppk)
            </div>
            <div className="font-mono text-xl font-bold text-[#C084FC]">
              {capability.ppk !== null && capability.ppk !== undefined ? capability.ppk.toFixed(3) : "N/A"}
            </div>
            <div className="text-[10px] font-mono text-[#64748B] mt-1">
              Overall Variation
            </div>
          </div>

          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">
              Total Defect PPM
            </div>
            <div
              className={`font-mono text-xl font-bold ${
                capability.ppm_total !== null && capability.ppm_total !== undefined
                  ? capability.ppm_total > 1000
                    ? "text-[#F43F5E]"
                    : "text-[#10B981]"
                  : "text-[#64748B]"
              }`}
            >
              {capability.ppm_total !== null && capability.ppm_total !== undefined ? capability.ppm_total.toLocaleString() : "N/A"}
            </div>
            <div className="text-[10px] font-mono text-[#64748B] mt-1">
              Parts Per Million Out of Spec
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
