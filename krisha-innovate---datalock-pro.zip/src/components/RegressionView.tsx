import React, { useState, useEffect } from "react";
import { 
  ArrowRight, 
  CheckCircle2, 
  HelpCircle, 
  Play, 
  PlayCircle, 
  Sliders, 
  Sparkles 
} from "lucide-react";
import { 
  ResponsiveContainer, 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  ReferenceLine 
} from "recharts";
import { RegressionResult, ValidationResult } from "../types";

interface RegressionViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  selectedY: string;
}

export const RegressionView: React.FC<RegressionViewProps> = ({
  rawData,
  validation,
  selectedY,
}) => {
  const numericCols = validation?.numeric_columns || [];
  const candidateXCols = numericCols.filter((c) => c !== selectedY);

  const [selectedFeatures, setSelectedFeatures] = useState<string[]>(
    candidateXCols.slice(0, 4)
  );
  const [regression, setRegression] = useState<RegressionResult | null>(null);
  const [isComputing, setIsComputing] = useState(false);

  const toggleFeature = (col: string) => {
    if (selectedFeatures.includes(col)) {
      setSelectedFeatures(selectedFeatures.filter((f) => f !== col));
    } else {
      setSelectedFeatures([...selectedFeatures, col]);
    }
  };

  const handleRunRegression = async () => {
    if (!selectedY || selectedFeatures.length === 0 || rawData.length === 0) return;
    setIsComputing(true);
    try {
      const res = await fetch("/api/regression", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          data: rawData,
          y_col: selectedY,
          x_cols: selectedFeatures,
        }),
      });
      const data = await res.json();
      setRegression(data);
    } catch (err: any) {
      alert(`Regression calculation error: ${err.message}`);
    } finally {
      setIsComputing(false);
    }
  };

  useEffect(() => {
    if (selectedFeatures.length > 0) {
      handleRunRegression();
    }
  }, [selectedY]);

  // Residual plot data
  const residualPlotData = regression?.residuals?.map((r, i) => ({
    index: i + 1,
    fitted: regression.fitted_values[i] ?? 0,
    residual: r,
  })) || [];

  return (
    <div className="space-y-5">
      {/* Top Diagnostic Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">08. ORDINARY LEAST SQUARES (OLS) REGRESSION</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              TARGET Y: {selectedY}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Multivariate OLS Regression & Residual Diagnostics
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Model linear dependencies, calculate variance explained (R² & Adjusted R²), evaluate coefficient significance (t-stat & p-values), and inspect residual homoscedasticity.
          </p>
        </div>

        <button
          onClick={handleRunRegression}
          disabled={isComputing || selectedFeatures.length === 0}
          className="tech-btn-run px-5 py-2.5 rounded flex items-center gap-2 cursor-pointer shrink-0 shadow-md"
        >
          <Play className="w-4 h-4" />
          <span>{isComputing ? "COMPUTING OLS..." : "RUN OLS REGRESSION"}</span>
        </button>
      </div>

      {/* Feature Selector Chips */}
      <div className="tech-grid-card p-4 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
            Select Predictor Variables (X)
          </span>
          <span className="text-[11px] font-mono text-[#38BDF8]">
            {selectedFeatures.length} of {candidateXCols.length} SELECTED
          </span>
        </div>

        <div className="flex flex-wrap gap-2 pt-1">
          {candidateXCols.map((col) => {
            const isSelected = selectedFeatures.includes(col);
            return (
              <button
                key={col}
                onClick={() => toggleFeature(col)}
                className={`px-3 py-1 rounded text-xs font-mono font-bold transition cursor-pointer ${
                  isSelected
                    ? "bg-[#38BDF8]/20 text-[#38BDF8] border border-[#38BDF8]"
                    : "bg-[#0F172A] text-[#94A3B8] border border-[#334155] hover:text-[#F1F5F9]"
                }`}
              >
                {isSelected ? "✓ " : "+ "}
                {col}
              </button>
            );
          })}
        </div>
      </div>

      {/* Regression Summary Stats */}
      {regression && !regression.error && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">
              R-Squared (R²)
            </div>
            <div className="font-mono text-xl font-bold text-[#38BDF8]">
              {(regression.r_squared * 100).toFixed(2)}%
            </div>
            <div className="text-[10px] font-mono text-[#64748B] mt-1">
              Total Variance Explained
            </div>
          </div>

          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">
              Adjusted R²
            </div>
            <div className="font-mono text-xl font-bold text-[#10B981]">
              {(regression.adj_r_squared * 100).toFixed(2)}%
            </div>
            <div className="text-[10px] font-mono text-[#64748B] mt-1">
              Degrees of Freedom Penalized
            </div>
          </div>

          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">
              F-Statistic (Model Significance)
            </div>
            <div className="font-mono text-xl font-bold text-[#C084FC]">
              {regression.f_stat?.toFixed(2) ?? "N/A"}{" "}
              <span className="text-xs text-[#94A3B8]">
                (p: {regression.f_p_value?.toFixed(4)})
              </span>
            </div>
            <div className="text-[10px] font-mono text-[#64748B] mt-1">
              Overall Model ANOVA Test
            </div>
          </div>

          <div className="tech-grid-card p-3">
            <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">
              Residual Std Error (RMSE)
            </div>
            <div className="font-mono text-xl font-bold text-[#F59E0B]">
              {regression.rmse?.toFixed(3) ?? "N/A"}
            </div>
            <div className="text-[10px] font-mono text-[#64748B] mt-1">
              Model Prediction Error
            </div>
          </div>
        </div>
      )}

      {/* Parameter Estimates Table & Residual Scatter */}
      {regression && !regression.error && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Coefficients Grid */}
          <div className="tech-grid-card p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
              <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
                Model Parameter Estimates & Significance
              </span>
            </div>

            <div className="overflow-x-auto border border-[#334155] rounded">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#0F172A] text-[#94A3B8] border-b border-[#334155]">
                  <tr>
                    <th className="px-3 py-2">Term</th>
                    <th className="px-3 py-2">Coef (β)</th>
                    <th className="px-3 py-2">Std Error</th>
                    <th className="px-3 py-2">t-statistic</th>
                    <th className="px-3 py-2">p-value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
                  {regression.coefficients.map((coef) => (
                    <tr key={coef.term} className="hover:bg-[#0F172A]">
                      <td className="px-3 py-2 font-bold text-[#F1F5F9]">{coef.term}</td>
                      <td className="px-3 py-2 font-bold text-[#38BDF8]">{coef.coef.toFixed(4)}</td>
                      <td className="px-3 py-2 text-[#94A3B8]">{coef.se.toFixed(4)}</td>
                      <td className="px-3 py-2">{coef.t_stat.toFixed(3)}</td>
                      <td className="px-3 py-2">
                        <span
                          className={`font-bold ${
                            coef.p_value <= 0.05 ? "text-[#10B981]" : "text-[#94A3B8]"
                          }`}
                        >
                          {coef.p_value.toFixed(4)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Residual vs Fitted Plot on #020617 */}
          <div className="tech-viz-container p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
              <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
                Residual vs. Fitted Diagnostics (Homoscedasticity)
              </span>
              <span className="text-[10px] font-mono text-[#38BDF8]">
                {residualPlotData.length} OBS
              </span>
            </div>

            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 15, right: 20, bottom: 20, left: 10 }}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.6} />
                  <XAxis
                    type="number"
                    dataKey="fitted"
                    name="Fitted Y"
                    label={{ value: "Fitted Values", position: "bottom", offset: 0, fontSize: 10, fill: "#94A3B8" }}
                    tick={{ fill: "#94A3B8", fontSize: 10 }}
                    stroke="#334155"
                  />
                  <YAxis
                    type="number"
                    dataKey="residual"
                    name="Residual (e)"
                    tick={{ fill: "#94A3B8", fontSize: 10 }}
                    stroke="#334155"
                  />
                  <Tooltip
                    content={({ payload }) => {
                      if (!payload || payload.length === 0) return null;
                      const d = payload[0].payload;
                      return (
                        <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2 rounded text-xs font-mono space-y-1">
                          <p className="font-bold text-[#38BDF8]">Obs #{d.index}</p>
                          <p>Fitted: {d.fitted.toFixed(2)}</p>
                          <p>Residual: <strong className={d.residual >= 0 ? "text-[#34D399]" : "text-[#FB7185]"}>{d.residual.toFixed(3)}</strong></p>
                        </div>
                      );
                    }}
                  />
                  <ReferenceLine y={0} stroke="#F43F5E" strokeDasharray="3 3" />
                  <Scatter data={residualPlotData} fill="#38BDF8" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
