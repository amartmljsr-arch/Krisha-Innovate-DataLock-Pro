import React, { useState } from "react";
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  CheckCircle2,
  FileCheck,
  HelpCircle,
  Info,
  Layers,
  ShieldAlert,
  Sparkles,
  Target,
  Wrench,
  X,
} from "lucide-react";
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  BarChart,
  Bar,
} from "recharts";
import { CandidateResult, ComparisonResult, EvidenceTier } from "../types";

interface ComparativeAnalysisViewProps {
  comparison: ComparisonResult | null;
  selectedBadIds: string[];
  selectedGoodIds: string[];
  rawData: any[];
  onNavigateToDOE?: () => void;
  onNavigateToRSM?: () => void;
}

export const ComparativeAnalysisView: React.FC<ComparativeAnalysisViewProps> = ({
  comparison,
  selectedBadIds,
  selectedGoodIds,
  rawData,
  onNavigateToDOE,
  onNavigateToRSM,
}) => {
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateResult | null>(null);

  if (!comparison) {
    return (
      <div className="tech-grid-card p-12 text-center space-y-3">
        <Layers className="w-12 h-12 text-[#64748B] mx-auto" />
        <h3 className="text-sm font-bold text-[#F1F5F9] font-mono uppercase tracking-wider">
          No Diagnostic Comparison Available Yet
        </h3>
        <p className="text-xs text-[#94A3B8] max-w-md mx-auto font-mono">
          Navigate to 02. Y-Analysis, select 5 BAD and 5 GOOD observations, and click "RUN X-CANDIDATE ANALYSIS".
        </p>
      </div>
    );
  }

  const getTierBadge = (tier: EvidenceTier) => {
    switch (tier) {
      case "VERY STRONG OBSERVED SEPARATION":
      case "Very Strong":
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#A855F7]/15 text-[#C084FC] border border-[#A855F7]/40 whitespace-nowrap">
            VERY STRONG
          </span>
        );
      case "STRONG OBSERVED SEPARATION":
      case "Strong":
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/40 whitespace-nowrap">
            STRONG
          </span>
        );
      case "MODERATE OBSERVED SEPARATION":
      case "Moderate":
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/40 whitespace-nowrap">
            MODERATE
          </span>
        );
      case "WEAK OBSERVED SEPARATION":
      case "Weak":
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#F59E0B]/15 text-[#FBBF24] border border-[#F59E0B]/40 whitespace-nowrap">
            WEAK
          </span>
        );
      case "NO / VERY WEAK OBSERVED SEPARATION":
      case "No / Very Weak Observed Separation":
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#334155]/40 text-[#94A3B8] border border-[#334155] whitespace-nowrap">
            NO SEPARATION
          </span>
        );
    }
  };

  const getConsistencyBadge = (consistency?: string) => {
    switch (consistency) {
      case "CONCORDANT":
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#10B981]/15 text-[#34D399] border border-[#10B981]/30 whitespace-nowrap">
            CONCORDANT
          </span>
        );
      case "PARTIALLY CONCORDANT":
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/30 whitespace-nowrap">
            PARTIALLY CONCORDANT
          </span>
        );
      case "DISCORDANT":
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#F43F5E]/15 text-[#FB7185] border border-[#F43F5E]/30 whitespace-nowrap">
            DISCORDANT
          </span>
        );
      case "INCONCLUSIVE":
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#64748B]/20 text-[#94A3B8] border border-[#64748B]/30 whitespace-nowrap">
            {consistency || "INCONCLUSIVE"}
          </span>
        );
    }
  };

  // Extract raw points for the selected candidate in BAD and GOOD groups
  const getStripPlotData = (varName: string) => {
    const badPoints = rawData
      .filter((r, i) => selectedBadIds.includes(String(r.id ?? `Obs_${i + 1}`)))
      .map((r, i) => ({
        group: "BAD (n=5)",
        xPos: 1,
        val: parseFloat(r[varName]),
        id: String(r.id ?? `BAD_${i + 1}`),
      }));

    const goodPoints = rawData
      .filter((r, i) => selectedGoodIds.includes(String(r.id ?? `Obs_${i + 1}`)))
      .map((r, i) => ({
        group: "GOOD (n=5)",
        xPos: 2,
        val: parseFloat(r[varName]),
        id: String(r.id ?? `GOOD_${i + 1}`),
      }));

    return [...badPoints, ...goodPoints];
  };

  return (
    <div className="space-y-5">
      {/* Top Banner & Diagnostic Summary */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">03. X-CANDIDATE PRIORITIZATION</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              TARGET Y: {comparison.y_variable}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            5 BAD vs 5 GOOD Statistical Evidence & Prioritisation
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Multi-test invariant evaluation (Welch t-test, Mann-Whitney U, AUC separation, Cohen's d) ranking root cause candidate factors.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {onNavigateToDOE && (
            <button
              onClick={onNavigateToDOE}
              className="px-3 py-2 rounded bg-[#0F172A] hover:bg-[#334155] text-[#38BDF8] border border-[#38BDF8]/40 text-xs font-mono font-bold transition cursor-pointer"
            >
              PLAN 2^k DOE →
            </button>
          )}
          {onNavigateToRSM && (
            <button
              onClick={onNavigateToRSM}
              className="px-3 py-2 rounded bg-[#0F172A] hover:bg-[#334155] text-[#F59E0B] border border-[#F59E0B]/40 text-xs font-mono font-bold transition cursor-pointer"
            >
              PLAN RSM →
            </button>
          )}
        </div>
      </div>

      {/* Scientific Integrity Rule Banner */}
      <div className="p-3 bg-[#0F172A] border border-[#334155] rounded flex items-start gap-2.5 text-xs text-[#94A3B8] font-mono">
        <ShieldAlert className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
        <div>
          <strong className="text-[#F1F5F9]">Scientific Integrity Mandate:</strong> Statistical association identified by DataLock Pro does <strong>NOT</strong> constitute physical proof of causation. 
          Prioritised candidate factors must be physically confirmed via structured trial plans, single-piece validation, or Design of Experiments (DOE).
        </div>
      </div>

      {/* Authoritative Python Engine Metadata Strip */}
      <div className="bg-[#0B132B]/80 border border-[#1E293B] rounded p-3 text-xs font-mono grid grid-cols-2 md:grid-cols-4 gap-3 text-[#94A3B8]">
        <div>
          <span className="text-[10px] text-[#64748B] block uppercase">Calculation Engine</span>
          <span className="text-[#38BDF8] font-bold">Python Authoritative IPC</span>
        </div>
        <div>
          <span className="text-[10px] text-[#64748B] block uppercase">Analysis Request ID</span>
          <span className="text-[#CBD5E1] truncate block" title={comparison.request_id || "N/A"}>
            {comparison.request_id || "N/A"}
          </span>
        </div>
        <div>
          <span className="text-[10px] text-[#64748B] block uppercase">Active Dataset Signature</span>
          <span className="text-[#CBD5E1] truncate block" title={comparison.dataset_id || "CURRENT_SESSION"}>
            {comparison.dataset_id || "CURRENT_SESSION"}
          </span>
        </div>
        <div>
          <span className="text-[10px] text-[#64748B] block uppercase">Separation Model</span>
          <span className="text-[#34D399] font-bold">
            5 BAD (n=5) vs 5 GOOD (n=5)
          </span>
        </div>
      </div>

      {/* Y Contrast Summary Card */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="tech-grid-card p-3 border-[#F43F5E]/40">
          <div className="text-[10px] font-mono uppercase text-[#FB7185] font-bold mb-1">
            BAD Group Mean (n=5)
          </div>
          <div className="font-mono text-base font-bold text-[#F43F5E]">
            {comparison.y_summary.mean_bad.toFixed(2)}{" "}
            <span className="text-xs text-[#FB7185] font-normal">(SD: {comparison.y_summary.sd_bad.toFixed(2)})</span>
          </div>
        </div>

        <div className="tech-grid-card p-3 border-[#10B981]/40">
          <div className="text-[10px] font-mono uppercase text-[#34D399] font-bold mb-1">
            GOOD Group Mean (n=5)
          </div>
          <div className="font-mono text-base font-bold text-[#10B981]">
            {comparison.y_summary.mean_good.toFixed(2)}{" "}
            <span className="text-xs text-[#34D399] font-normal">(SD: {comparison.y_summary.sd_good.toFixed(2)})</span>
          </div>
        </div>

        <div className="tech-grid-card p-3">
          <div className="text-[10px] font-mono uppercase text-[#94A3B8] mb-1">BAD Group Median</div>
          <div className="font-mono text-base font-bold text-[#F1F5F9]">
            {comparison.y_summary.median_bad.toFixed(2)}
          </div>
        </div>

        <div className="tech-grid-card p-3">
          <div className="text-[10px] font-mono uppercase text-[#94A3B8] mb-1">GOOD Group Median</div>
          <div className="font-mono text-base font-bold text-[#F1F5F9]">
            {comparison.y_summary.median_good.toFixed(2)}
          </div>
        </div>
      </div>

      {/* Candidate Prioritisation Master Data Grid */}
      <div className="tech-grid-card p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
          <div>
            <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
              Candidate X Factor Prioritization Grid
            </h3>
            <p className="text-[11px] text-[#94A3B8] font-mono">
              Ranked by statistical evidence invariants (Welch p, Mann-Whitney U, AUC, Cohen's d).
            </p>
          </div>
          <span className="tech-tag">
            {comparison.candidates.length} CANDIDATES EVALUATED
          </span>
        </div>

        <div className="overflow-x-auto border border-[#334155] rounded">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0F172A] text-[#94A3B8] sticky top-0 border-b border-[#334155]">
              <tr>
                <th className="px-3 py-2.5 w-8 text-[#64748B]">#</th>
                <th className="px-3 py-2.5">Candidate Variable</th>
                <th className="px-3 py-2.5">Evidence Tier</th>
                <th className="px-3 py-2.5">Consistency</th>
                <th className="px-3 py-2.5">Direction / Shift</th>
                <th className="px-3 py-2.5">Effective N</th>
                <th className="px-3 py-2.5">Welch p</th>
                <th className="px-3 py-2.5">Mann-Whitney p</th>
                <th className="px-3 py-2.5">AUC</th>
                <th className="px-3 py-2.5">Effect (d/V)</th>
                <th className="px-3 py-2.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
              {comparison.candidates.map((cand, idx) => (
                <tr
                  key={cand.variable}
                  className={`hover:bg-[#0F172A] transition cursor-pointer ${
                    selectedCandidate?.variable === cand.variable
                      ? "bg-[#38BDF8]/10 border-l-2 border-[#38BDF8]"
                      : ""
                  }`}
                  onClick={() => setSelectedCandidate(cand)}
                >
                  <td className="px-3 py-2 text-[#64748B] font-bold">{idx + 1}</td>
                  <td className="px-3 py-2">
                    <span className="font-bold text-[#F1F5F9]">{cand.variable}</span>
                    <span className="text-[10px] text-[#64748B] block font-mono">
                      {cand.type}
                    </span>
                  </td>
                  <td className="px-3 py-2">{getTierBadge(cand.evidence_strength)}</td>
                  <td className="px-3 py-2">{getConsistencyBadge(cand.consistency)}</td>
                  <td className="px-3 py-2">
                    {cand.type === "Numeric" ? (
                      <span className="flex items-center gap-1 font-bold">
                        {cand.direction === "Higher in BAD" ? (
                          <>
                            <ArrowUpRight className="w-3.5 h-3.5 text-[#F43F5E]" />
                            <span className="text-[#FB7185]">Higher in BAD</span>
                          </>
                        ) : cand.direction === "Lower in BAD" ? (
                          <>
                            <ArrowDownRight className="w-3.5 h-3.5 text-[#38BDF8]" />
                            <span className="text-[#38BDF8]">Lower in BAD</span>
                          </>
                        ) : (
                          <span className="text-[#64748B]">Identical</span>
                        )}
                      </span>
                    ) : (
                      <span className="text-[#C084FC] font-bold">Category Shift</span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <span className="font-mono text-[#94A3B8]">
                      {cand.effective_n !== undefined ? `${cand.effective_n} (${cand.n_bad_used || 5}B / ${cand.n_good_used || 5}G)` : "10"}
                    </span>
                  </td>
                  <td className="px-3 py-2">
                    {cand.welch_p !== null && cand.welch_p !== undefined ? (
                      <span
                        className={
                          cand.welch_p <= 0.05
                            ? "font-bold text-[#10B981]"
                            : "text-[#94A3B8]"
                        }
                      >
                        {cand.welch_p.toFixed(4)}
                      </span>
                    ) : (
                      <span className="text-[#64748B]" title={cand.welch_note}>
                        N/A (0 Var)
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    {cand.mann_whitney_p !== null && cand.mann_whitney_p !== undefined ? (
                      <span
                        className={
                          cand.mann_whitney_p <= 0.05
                            ? "font-bold text-[#10B981]"
                            : "text-[#94A3B8]"
                        }
                      >
                        {cand.mann_whitney_p.toFixed(4)}
                      </span>
                    ) : (
                      <span className="text-[#64748B]">N/A</span>
                    )}
                  </td>
                  <td className="px-3 py-2 font-bold">
                    {cand.auc !== undefined && cand.auc !== null ? (
                      <span
                        className={
                          Math.abs(cand.auc - 0.5) >= 0.3
                            ? "text-[#10B981]"
                            : "text-[#94A3B8]"
                        }
                      >
                        {cand.auc.toFixed(2)}
                      </span>
                    ) : (
                      "N/A"
                    )}
                  </td>
                  <td className="px-3 py-2">
                    {cand.cohens_d !== null && cand.cohens_d !== undefined ? (
                      <span>{cand.cohens_d.toFixed(2)}</span>
                    ) : cand.cramers_v !== null && cand.cramers_v !== undefined ? (
                      <span>{cand.cramers_v.toFixed(2)} (V)</span>
                    ) : (
                      <span className="text-[#64748B]">N/A</span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedCandidate(cand);
                      }}
                      className="px-2.5 py-1 rounded bg-[#0F172A] border border-[#334155] text-[#38BDF8] hover:bg-[#38BDF8] hover:text-[#020617] transition text-[11px] font-bold cursor-pointer"
                    >
                      Inspect →
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Candidate Worksheet & Deep Dive */}
      {selectedCandidate && (
        <div className="tech-grid-card border border-[#38BDF8]/60 p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#334155]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded bg-[#0F172A] border border-[#38BDF8]/40 flex items-center justify-center text-[#38BDF8] font-bold">
                <FileCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#F1F5F9] font-mono">
                  Candidate Deep-Dive & Action Plan: {selectedCandidate.variable}
                </h3>
                <p className="text-[11px] font-mono text-[#94A3B8]">
                  Classification: {selectedCandidate.type} • Strength:{" "}
                  <strong className="text-[#38BDF8]">{selectedCandidate.evidence_strength}</strong>
                </p>
              </div>
            </div>
            <button
              onClick={() => setSelectedCandidate(null)}
              className="p-1 rounded text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Strip Plot on #020617 Canvas */}
            <div className="tech-viz-container p-3 space-y-2">
              <div className="text-[10px] uppercase font-mono font-bold text-[#94A3B8]">
                Observation Distribution Spread (BAD n=5 vs GOOD n=5)
              </div>

              {selectedCandidate.type === "Numeric" ? (
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart margin={{ top: 15, right: 20, bottom: 20, left: 10 }}>
                      <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.6} />
                      <XAxis
                        type="number"
                        dataKey="xPos"
                        domain={[0.5, 2.5]}
                        ticks={[1, 2]}
                        tickFormatter={(val) => (val === 1 ? "BAD Group" : "GOOD Group")}
                        tick={{ fill: "#94A3B8", fontSize: 10 }}
                        stroke="#334155"
                      />
                      <YAxis
                        type="number"
                        dataKey="val"
                        name={selectedCandidate.variable}
                        tick={{ fill: "#94A3B8", fontSize: 10 }}
                        stroke="#334155"
                      />
                      <Tooltip
                        content={({ payload }) => {
                          if (!payload || payload.length === 0) return null;
                          const d = payload[0].payload;
                          return (
                            <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2 rounded text-xs font-mono">
                              <p className="font-bold text-[#38BDF8]">{d.id}</p>
                              <p>{d.group}: <strong className="text-white">{d.val}</strong></p>
                            </div>
                          );
                        }}
                      />
                      <Scatter data={getStripPlotData(selectedCandidate.variable)}>
                        {getStripPlotData(selectedCandidate.variable).map((entry, i) => (
                          <Cell
                            key={`dot-${i}`}
                            fill={entry.xPos === 1 ? "#F43F5E" : "#10B981"}
                            r={6}
                            stroke="#FFFFFF"
                            strokeWidth={1}
                          />
                        ))}
                      </Scatter>
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={selectedCandidate.distribution || []}>
                      <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.5} />
                      <XAxis dataKey="category" fontSize={10} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                      <YAxis fontSize={10} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                      <Tooltip />
                      <Bar dataKey="bad_count" name="BAD Count" fill="#F43F5E" />
                      <Bar dataKey="good_count" name="GOOD Count" fill="#10B981" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* Statistical Invariants & Group Separation Summary */}
            <div className="tech-subcard p-3 space-y-3">
              <div className="flex items-center justify-between pb-1 border-b border-[#334155]">
                <div className="text-[10px] uppercase font-mono font-bold text-[#38BDF8]">
                  Statistical Evidence & Separation Proofs
                </div>
                <div className="flex items-center gap-1.5">
                  {getConsistencyBadge(selectedCandidate.consistency)}
                </div>
              </div>

              {/* Group Comparison Summary */}
              {selectedCandidate.type === "Numeric" && (
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-2 bg-[#0F172A] border border-[#F43F5E]/30 rounded space-y-0.5">
                    <span className="text-[10px] font-bold uppercase text-[#FB7185] block">BAD Group Summary</span>
                    <p className="text-[#F1F5F9]">Mean: <strong>{selectedCandidate.mean_bad !== undefined ? selectedCandidate.mean_bad.toFixed(2) : "N/A"}</strong></p>
                    <p className="text-[#94A3B8]">Median: {selectedCandidate.median_bad !== undefined ? selectedCandidate.median_bad.toFixed(2) : "N/A"}</p>
                    <p className="text-[#94A3B8]">SD: {selectedCandidate.sd_bad !== undefined ? selectedCandidate.sd_bad.toFixed(2) : "N/A"}</p>
                    <p className="text-[10px] text-[#64748B]">Valid N: {selectedCandidate.n_bad_used || 5} (Excl: {selectedCandidate.n_bad_excluded || 0})</p>
                  </div>
                  <div className="p-2 bg-[#0F172A] border border-[#10B981]/30 rounded space-y-0.5">
                    <span className="text-[10px] font-bold uppercase text-[#34D399] block">GOOD Group Summary</span>
                    <p className="text-[#F1F5F9]">Mean: <strong>{selectedCandidate.mean_good !== undefined ? selectedCandidate.mean_good.toFixed(2) : "N/A"}</strong></p>
                    <p className="text-[#94A3B8]">Median: {selectedCandidate.median_good !== undefined ? selectedCandidate.median_good.toFixed(2) : "N/A"}</p>
                    <p className="text-[#94A3B8]">SD: {selectedCandidate.sd_good !== undefined ? selectedCandidate.sd_good.toFixed(2) : "N/A"}</p>
                    <p className="text-[10px] text-[#64748B]">Valid N: {selectedCandidate.n_good_used || 5} (Excl: {selectedCandidate.n_good_excluded || 0})</p>
                  </div>
                </div>
              )}

              <div className="space-y-1.5 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-[#334155]">
                  <span className="text-[#94A3B8]">Welch t-test (t, df, p):</span>
                  <span className="font-bold text-[#F1F5F9]">
                    {selectedCandidate.welch_p !== null && selectedCandidate.welch_p !== undefined
                      ? `t=${selectedCandidate.welch_t?.toFixed(3) ?? "N/A"}, df=${selectedCandidate.welch_df?.toFixed(1) ?? "N/A"}, p=${selectedCandidate.welch_p.toFixed(5)}`
                      : (selectedCandidate.welch_note || "Undefined (Zero Variance)")}
                  </span>
                </div>

                <div className="flex justify-between py-1 border-b border-[#334155]">
                  <span className="text-[#94A3B8]">Mann-Whitney U (U, p):</span>
                  <span className="font-bold text-[#F1F5F9]">
                    {selectedCandidate.mann_whitney_p !== null && selectedCandidate.mann_whitney_p !== undefined
                      ? `U=${selectedCandidate.mann_whitney_u ?? "N/A"}, p=${selectedCandidate.mann_whitney_p.toFixed(5)} (${selectedCandidate.mw_calc_type || "Exact"})`
                      : "N/A"}
                  </span>
                </div>

                <div className="flex justify-between py-1 border-b border-[#334155]">
                  <span className="text-[#94A3B8]">Area Under Curve (AUC):</span>
                  <span className="font-bold text-[#38BDF8]">
                    {selectedCandidate.auc?.toFixed(3) ?? "N/A"}
                  </span>
                </div>

                <div className="flex justify-between py-1 border-b border-[#334155]">
                  <span className="text-[#94A3B8]">Standardized Effect (Cohen's d / Hedges' g):</span>
                  <span className="font-bold text-[#F1F5F9]">
                    {selectedCandidate.cohens_d !== null && selectedCandidate.cohens_d !== undefined
                      ? `d=${selectedCandidate.cohens_d.toFixed(3)} | g=${selectedCandidate.hedges_g?.toFixed(3) ?? "N/A"}`
                      : selectedCandidate.cramers_v !== null && selectedCandidate.cramers_v !== undefined
                      ? `Cramér's V = ${selectedCandidate.cramers_v.toFixed(3)}`
                      : "N/A"}
                  </span>
                </div>

                <div className="p-2 bg-[#0F172A] border border-[#334155] rounded text-[11px] text-[#94A3B8]">
                  <span className="text-[#38BDF8] font-bold block mb-0.5">Evidence Justification:</span>
                  <p className="text-[#CBD5E1] leading-relaxed">{selectedCandidate.justification}</p>
                </div>

                {selectedCandidate.range_info && (
                  <div className="p-2 bg-[#020617] border border-[#334155] rounded text-[10px] text-[#94A3B8] space-y-1">
                    <span className="font-bold text-[#F1F5F9] block">
                      Range Span: BAD [{selectedCandidate.range_info.bad_range[0]}, {selectedCandidate.range_info.bad_range[1]}] | GOOD [{selectedCandidate.range_info.good_range[0]}, {selectedCandidate.range_info.good_range[1]}]
                    </span>
                    <span className="text-[#64748B] block">Overlap: {selectedCandidate.range_info.overlap}</span>
                    <span className="text-[#FBBF24] block italic">{selectedCandidate.range_info.disclaimer}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Structured Confirmation Action Plan */}
          <div className="tech-subcard p-3.5 space-y-2 border-[#38BDF8]/40">
            <div className="flex items-center gap-2">
              <Wrench className="w-4 h-4 text-[#38BDF8]" />
              <h4 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                Industrial Confirmation Action Plan
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-2.5 bg-[#0F172A] border border-[#334155] rounded space-y-1">
                <span className="font-bold text-[#38BDF8] block">
                  Physical Trial Recommendation:
                </span>
                <p className="text-[#CBD5E1]">
                  {selectedCandidate.confirmation_plan.suggested_action}
                </p>
              </div>

              <div className="p-2.5 bg-[#0F172A] border border-[#334155] rounded space-y-1">
                <span className="font-bold text-[#38BDF8] block">
                  Assumptions & Confounders:
                </span>
                <p className="text-[#CBD5E1]">
                  {selectedCandidate.confirmation_plan.assumptions_limitations}
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-[#334155] text-[11px] font-mono text-[#FBBF24] flex items-center gap-2">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>{selectedCandidate.confirmation_plan.caution_note}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
