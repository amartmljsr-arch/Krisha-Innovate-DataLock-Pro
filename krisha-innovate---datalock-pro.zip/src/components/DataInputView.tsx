import React, { useState, useRef } from "react";
import * as XLSX from "xlsx";
import Papa from "papaparse";
import { 
  ArrowRight, 
  CheckCircle2, 
  Database, 
  FileSpreadsheet, 
  FileText, 
  Search, 
  ShieldAlert, 
  Sparkles, 
  Table, 
  Upload 
} from "lucide-react";
import { ValidationResult } from "../types";

interface DataInputViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  isValidating: boolean;
  onDataLoaded: (rows: any[], filename?: string) => void;
  onProceedToY: () => void;
  onLoadDemo: (name: string) => void;
}

export const DataInputView: React.FC<DataInputViewProps> = ({
  rawData,
  validation,
  isValidating,
  onDataLoaded,
  onProceedToY,
  onLoadDemo,
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 12;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFileUpload = (file: File) => {
    const fileName = file.name;
    const extension = fileName.split(".").pop()?.toLowerCase();

    if (extension === "csv" || extension === "txt") {
      Papa.parse(file, {
        header: true,
        dynamicTyping: false,
        skipEmptyLines: true,
        complete: (results) => {
          if (results.data && results.data.length > 0) {
            onDataLoaded(results.data as any[], fileName);
          }
        },
        error: (err) => {
          alert(`Failed to parse CSV: ${err.message}`);
        },
      });
    } else if (extension === "xlsx" || extension === "xls") {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const buffer = e.target?.result;
          const workbook = XLSX.read(buffer, { type: "binary" });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
          if (jsonData && jsonData.length > 0) {
            onDataLoaded(jsonData as any[], fileName);
          }
        } catch (err: any) {
          alert(`Failed to parse Excel file: ${err.message}`);
        }
      };
      reader.readAsBinaryString(file);
    } else {
      alert("Please upload a .csv, .xlsx, or .xls file.");
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  // Filtered rows for table preview
  const columns = rawData.length > 0 ? Object.keys(rawData[0]) : [];
  const filteredRows = rawData.filter((r) => {
    if (!searchTerm) return true;
    return Object.values(r).some((val) =>
      String(val).toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const totalPages = Math.ceil(filteredRows.length / pageSize);
  const displayedRows = filteredRows.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="space-y-5">
      {/* Top Banner / Technical Diagnostic Header */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">
              01. DATA INGESTION & STATISTICAL HYGIENE
            </span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              ENGINE: V1.0.4-DIAGNOSTIC
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Load Manufacturing Process Dataset
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Import production CSV / Excel runs or load pre-calibrated engineering benchmark datasets. 
            DataLock Pro validates observation identifiers, missing values, column data types, and constant parameters.
          </p>
        </div>

        {rawData.length > 0 && validation?.is_valid && (
          <button
            onClick={onProceedToY}
            className="tech-btn-run px-5 py-2.5 rounded flex items-center gap-2 cursor-pointer shrink-0 shadow-md"
          >
            <span>Proceed to 02. Y-Analysis</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Upload Zone & Quick Pre-loaded Demos */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Upload Drop Card */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`lg:col-span-1 border border-dashed rounded p-6 flex flex-col items-center justify-center text-center cursor-pointer transition ${
            dragOver
              ? "border-[#38BDF8] bg-[#38BDF8]/10"
              : "border-[#334155] bg-[#1E293B] hover:border-[#38BDF8]/60 hover:bg-[#1E293B]/80"
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv, .xlsx, .xls, .txt"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files.length > 0) {
                handleFileUpload(e.target.files[0]);
              }
            }}
          />
          <div className="w-11 h-11 rounded bg-[#0F172A] border border-[#334155] flex items-center justify-center text-[#38BDF8] mb-3">
            <Upload className="w-5 h-5" />
          </div>
          <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
            Drop CSV or Excel Dataset
          </h3>
          <p className="text-[11px] text-[#94A3B8] mt-1 font-mono">
            Supports .csv, .xlsx, .xls with stable Observation IDs
          </p>
          <span className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-[#0F172A] border border-[#334155] text-[#38BDF8] rounded text-xs font-mono">
            <FileSpreadsheet className="w-3.5 h-3.5" />
            Select Local File
          </span>
        </div>

        {/* Benchmark Cases Grid */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Demo 1: VMC */}
          <div
            onClick={() => onLoadDemo("vmc")}
            className="tech-grid-card p-3.5 hover:border-[#38BDF8] cursor-pointer transition flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between text-[10px] font-mono font-bold text-[#38BDF8] mb-1">
                <span>MILLING / RSM</span>
                <Sparkles className="w-3 h-3" />
              </div>
              <h4 className="text-xs font-bold text-[#F1F5F9] font-mono group-hover:text-[#38BDF8] transition">
                VMC Cycle Time (RSM)
              </h4>
              <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-2">
                Spindle speed, feed rate, depth of cut with Response Surface modeling.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-[#334155] text-[10px] font-mono text-[#94A3B8] flex justify-between items-center">
              <span>30 Runs • 8 X Vars</span>
              <span className="text-[#38BDF8] font-bold group-hover:underline">Load Case →</span>
            </div>
          </div>

          {/* Demo 2: Pump Leakage */}
          <div
            onClick={() => onLoadDemo("pump")}
            className="tech-grid-card p-3.5 hover:border-[#10B981] cursor-pointer transition flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between text-[10px] font-mono font-bold text-[#10B981] mb-1">
                <span>HEAVY INDUSTRY</span>
                <Database className="w-3 h-3" />
              </div>
              <h4 className="text-xs font-bold text-[#F1F5F9] font-mono group-hover:text-[#10B981] transition">
                Pump Leakage (100k Obs)
              </h4>
              <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-2">
                Centrifugal seal leakage diagnostic benchmark with 100,000 production records.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-[#334155] text-[10px] font-mono text-[#94A3B8] flex justify-between items-center">
              <span>100,000 Obs • 7 Vars</span>
              <span className="text-[#10B981] font-bold group-hover:underline">Load Case →</span>
            </div>
          </div>

          {/* Demo 3: Gear Profile */}
          <div
            onClick={() => onLoadDemo("gear")}
            className="tech-grid-card p-3.5 hover:border-[#F59E0B] cursor-pointer transition flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between text-[10px] font-mono font-bold text-[#F59E0B] mb-1">
                <span>GEAR FINISHING</span>
                <Table className="w-3 h-3" />
              </div>
              <h4 className="text-xs font-bold text-[#F1F5F9] font-mono group-hover:text-[#F59E0B] transition">
                Gear Profile Grinding
              </h4>
              <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-2">
                Tooth profile angle deviation (fα in µm) across wheel dressing & infeed.
              </p>
            </div>
            <div className="mt-3 pt-2 border-t border-[#334155] text-[10px] font-mono text-[#94A3B8] flex justify-between items-center">
              <span>40 Parts • 8 Vars</span>
              <span className="text-[#F59E0B] font-bold group-hover:underline">Load Case →</span>
            </div>
          </div>
        </div>
      </div>

      {/* Automated Validation & Hygiene Summary */}
      {validation && (
        <div className="tech-grid-card p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#334155]">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                Automated Data Validation & Hygiene Inspection
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="tech-tag text-[#10B981] border-[#10B981]/40 bg-[#10B981]/10">
                STATUS: HYGIENE VERIFIED
              </span>
            </div>
          </div>

          {/* Validation Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Total Rows (N)</div>
              <div className="font-mono text-base font-bold text-[#F1F5F9]">
                {validation.row_count?.toLocaleString?.() ?? (rawData?.length ? rawData.length.toLocaleString() : 0)}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Total Columns</div>
              <div className="font-mono text-base font-bold text-[#F1F5F9]">
                {validation.col_count ?? (validation.columns ? validation.columns.length : 0)}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Numeric Variables</div>
              <div className="font-mono text-base font-bold text-[#38BDF8]">
                {validation.numeric_columns?.length ?? 0}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Categorical X</div>
              <div className="font-mono text-base font-bold text-[#A855F7]">
                {validation.categorical_columns?.length ?? 0}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Identified ID Col</div>
              <div className="font-mono text-xs font-bold text-[#F1F5F9] truncate mt-1">
                {validation.id_column || "id"}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Duplicate IDs</div>
              <div
                className={`font-mono text-base font-bold ${
                  validation.has_duplicate_ids
                    ? "text-[#F59E0B]"
                    : "text-[#10B981]"
                }`}
              >
                {validation.has_duplicate_ids ? `Yes (${validation.duplicate_id_count || 0})` : "0 (Stable)"}
              </div>
            </div>
          </div>

          {/* Warnings / Constant Columns */}
          {Boolean(validation.constant_columns && validation.constant_columns.length > 0) && (
            <div className="p-3 bg-[#F59E0B]/10 border border-[#F59E0B]/30 rounded flex items-center gap-2 text-xs text-[#FBBF24] font-mono">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>
                <strong>Constant Columns Flagged:</strong>{" "}
                {validation.constant_columns?.join(", ")}. Exhibiting zero overall variance; automatically excluded from discriminatory ranking.
              </span>
            </div>
          )}

          {/* Column Profile Table */}
          <div className="border border-[#334155] rounded overflow-hidden">
            <div className="bg-[#0F172A] px-3.5 py-2 text-xs font-mono font-bold text-[#94A3B8] border-b border-[#334155] flex justify-between items-center">
              <span>VARIABLE CLASSIFICATION & DISTRIBUTION PROFILE</span>
              <span className="text-[10px] text-[#38BDF8]">{validation.columns?.length ?? 0} COLUMNS</span>
            </div>
            <div className="max-h-60 overflow-y-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#1E293B] text-[#94A3B8] sticky top-0 border-b border-[#334155]">
                  <tr>
                    <th className="px-3 py-2">Column Name</th>
                    <th className="px-3 py-2">Type</th>
                    <th className="px-3 py-2">Missing Values</th>
                    <th className="px-3 py-2">Descriptive Distribution Profile</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
                  {(validation.columns || []).map((col) => (
                    <tr key={col.name} className="hover:bg-[#0F172A]/70">
                      <td className="px-3 py-2 font-bold text-[#F1F5F9]">
                        {col.name}
                      </td>
                      <td className="px-3 py-2">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            col.type === "Numeric"
                              ? "bg-[#38BDF8]/10 text-[#38BDF8] border border-[#38BDF8]/30"
                              : "bg-[#A855F7]/10 text-[#C084FC] border border-[#A855F7]/30"
                          }`}
                        >
                          {col.type}
                        </span>
                      </td>
                      <td className="px-3 py-2">
                        {col.missing_count === 0 ? (
                          <span className="text-[#10B981]">0 (0%)</span>
                        ) : (
                          <span className="text-[#F43F5E]">
                            {col.missing_count} ({col.missing_pct.toFixed(1)}%)
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-2 text-[11px] text-[#94A3B8]">
                        {col.type === "Numeric" && col.summary ? (
                          <span>
                            Min: <strong className="text-[#F1F5F9]">{col.summary.min?.toFixed(2)}</strong> | Mean: <strong className="text-[#F1F5F9]">{col.summary.mean?.toFixed(2)}</strong> | Max: <strong className="text-[#F1F5F9]">{col.summary.max?.toFixed(2)}</strong> | SD: <strong className="text-[#F1F5F9]">{col.summary.stdev?.toFixed(2)}</strong>
                          </span>
                        ) : (
                          <span>
                            {col.summary?.distinct_count} distinct categories ({col.summary?.top_categories?.slice(0, 3).join(", ")})
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Raw Data Observation Explorer */}
      {rawData.length > 0 && (
        <div className="tech-grid-card p-4 sm:p-5 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-[#334155]">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#38BDF8]" />
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                DATASET OBSERVATION EXPLORER ({filteredRows.length} ROWS)
              </h3>
            </div>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#94A3B8] absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Filter values..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setPage(1);
                }}
                className="pl-8 pr-3 py-1 text-xs bg-[#0F172A] border border-[#334155] rounded focus:outline-none focus:border-[#38BDF8] text-[#F1F5F9] font-mono"
              />
            </div>
          </div>

          <div className="overflow-x-auto border border-[#334155] rounded">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0F172A] text-[#94A3B8] font-bold border-b border-[#334155]">
                <tr>
                  <th className="px-3 py-2 w-12 text-[#64748B]">#</th>
                  {columns.map((c) => (
                    <th key={c} className="px-3 py-2 whitespace-nowrap text-[#CBD5E1]">
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
                {displayedRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-[#0F172A]/70">
                    <td className="px-3 py-2 text-[#64748B]">
                      {(page - 1) * pageSize + idx + 1}
                    </td>
                    {columns.map((col) => (
                      <td key={col} className="px-3 py-2 whitespace-nowrap">
                        {String(row[col] ?? "")}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <div className="flex items-center justify-between text-xs text-[#94A3B8] font-mono pt-2">
            <span>
              Showing {(page - 1) * pageSize + 1} to{" "}
              {Math.min(page * pageSize, filteredRows.length)} of {filteredRows.length}
            </span>
            <div className="flex items-center gap-2">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="px-2.5 py-1 border border-[#334155] rounded bg-[#0F172A] text-[#F1F5F9] hover:bg-[#334155] disabled:opacity-30 cursor-pointer"
              >
                Previous
              </button>
              <span>
                Page {page} / {totalPages || 1}
              </span>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="px-2.5 py-1 border border-[#334155] rounded bg-[#0F172A] text-[#F1F5F9] hover:bg-[#334155] disabled:opacity-30 cursor-pointer"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
