import React, { useState, useRef } from "react";
import * as XLSX from "xlsx";
import Papa from "papaparse";
import { 
  AlertCircle,
  ArrowRight, 
  CheckCircle2, 
  Cloud,
  Database, 
  ExternalLink,
  FileSpreadsheet, 
  FileText, 
  HardDrive,
  Loader2,
  RefreshCw,
  Search, 
  Server,
  ShieldAlert, 
  Sparkles, 
  Table, 
  Upload 
} from "lucide-react";
import { CloudDatasetItem, ValidationResult } from "../types";

interface DataInputViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  isValidating: boolean;
  onDataLoaded: (rows: any[], filename?: string) => void;
  onProceedToY: () => void;
  onLoadDemo: (name: string) => void;
}

export const DataInputView: React.FC<DataInputViewProps> = ({
  rawData,
  validation,
  isValidating,
  onDataLoaded,
  onProceedToY,
  onLoadDemo,
}) => {
  const [sourceTab, setSourceTab] = useState<"local" | "azure" | "aws">("local");
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 12;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  // Cloud Connectivity States
  const [isTestingAzure, setIsTestingAzure] = useState(false);
  const [azureStatus, setAzureStatus] = useState<"NOT_CONFIGURED" | "CONNECTED" | "ERROR" | null>(null);
  const [azureMsg, setAzureMsg] = useState<string>("");
  const [azureDatasets, setAzureDatasets] = useState<CloudDatasetItem[]>([]);
  const [selectedAzureDataset, setSelectedAzureDataset] = useState<string>("");
  const [isLoadingAzureData, setIsLoadingAzureData] = useState(false);

  const [isTestingAWS, setIsTestingAWS] = useState(false);
  const [awsStatus, setAwsStatus] = useState<"NOT_CONFIGURED" | "CONNECTED" | "ERROR" | null>(null);
  const [awsMsg, setAwsMsg] = useState<string>("");
  const [awsDatasets, setAwsDatasets] = useState<CloudDatasetItem[]>([]);
  const [selectedAwsDataset, setSelectedAwsDataset] = useState<string>("");
  const [isLoadingAwsData, setIsLoadingAwsData] = useState(false);

  // Azure Connection Test
  const handleTestAzure = async () => {
    setIsTestingAzure(true);
    setAzureMsg("");
    try {
      const res = await fetch("/api/connectors/azure/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      setAzureStatus(data.status);
      setAzureMsg(data.message);
      if (data.datasets && data.datasets.length > 0) {
        setAzureDatasets(data.datasets);
        setSelectedAzureDataset(data.datasets[0].id);
      }
    } catch (err: any) {
      setAzureStatus("ERROR");
      setAzureMsg(err.message || "Failed to contact Azure connector service.");
    } finally {
      setIsTestingAzure(false);
    }
  };

  // AWS Connection Test
  const handleTestAWS = async () => {
    setIsTestingAWS(true);
    setAwsMsg("");
    try {
      const res = await fetch("/api/connectors/aws/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      setAwsStatus(data.status);
      setAwsMsg(data.message);
      if (data.datasets && data.datasets.length > 0) {
        setAwsDatasets(data.datasets);
        setSelectedAwsDataset(data.datasets[0].id);
      }
    } catch (err: any) {
      setAwsStatus("ERROR");
      setAwsMsg(err.message || "Failed to contact AWS connector service.");
    } finally {
      setIsTestingAWS(false);
    }
  };

  // Load Cloud Dataset into Canonical DataLock Pipeline
  const handleLoadCloudDataset = async (source: "azure" | "aws", datasetId: string) => {
    const setLoading = source === "azure" ? setIsLoadingAzureData : setIsLoadingAwsData;
    setLoading(true);
    try {
      const res = await fetch(`/api/connectors/load?source=${source}&dataset_id=${encodeURIComponent(datasetId)}`);
      if (!res.ok) {
        const errJson = await res.json();
        throw new Error(errJson.error || `HTTP error ${res.status}`);
      }
      const data = await res.json();
      if (data.rows && data.rows.length > 0) {
        onDataLoaded(data.rows, data.dataset_name || `${source.toUpperCase()}_DATASET.CSV`);
      }
    } catch (err: any) {
      alert(`Failed to load cloud dataset: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (file: File) => {
    const fileName = file.name;
    const extension = fileName.split(".").pop()?.toLowerCase();

    if (extension === "csv" || extension === "txt") {
      Papa.parse(file, {
        header: true,
        dynamicTyping: false,
        skipEmptyLines: true,
        complete: (results) => {
          if (results.data && results.data.length > 0) {
            onDataLoaded(results.data as any[], fileName);
          }
        },
        error: (err) => {
          alert(`Failed to parse CSV: ${err.message}`);
        },
      });
    } else if (extension === "xlsx" || extension === "xls") {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const buffer = e.target?.result;
          const workbook = XLSX.read(buffer, { type: "binary" });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
          if (jsonData && jsonData.length > 0) {
            onDataLoaded(jsonData as any[], fileName);
          }
        } catch (err: any) {
          alert(`Failed to parse Excel file: ${err.message}`);
        }
      };
      reader.readAsBinaryString(file);
    } else {
      alert("Please upload a .csv, .xlsx, or .xls file.");
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  // Filtered rows for table preview
  const columns = rawData.length > 0 ? Object.keys(rawData[0]) : [];
  const filteredRows = rawData.filter((r) => {
    if (!searchTerm) return true;
    return Object.values(r).some((val) =>
      String(val).toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const totalPages = Math.ceil(filteredRows.length / pageSize);
  const displayedRows = filteredRows.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div className="space-y-5">
      {/* Top Banner / Technical Diagnostic Header */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">
              01. DATA INGESTION & STATISTICAL HYGIENE
            </span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              ENGINE: V1.0.4-DIAGNOSTIC
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Load Manufacturing Process Dataset
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Import production CSV / Excel runs, tap directly into Azure / AWS manufacturing cloud repositories, or load 
            pre-calibrated engineering benchmark datasets. DataLock Pro enforces canonical _dl_id tracking, missing value exclusion, 
            and data type validation.
          </p>
        </div>

        {rawData.length > 0 && validation?.is_valid && (
          <button
            onClick={onProceedToY}
            className="tech-btn-run px-5 py-2.5 rounded flex items-center gap-2 cursor-pointer shrink-0 shadow-md"
          >
            <span>Proceed to 02. Y-Analysis</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Data Source Selector Navigation */}
      <div className="tech-grid-card p-2">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSourceTab("local")}
            className={`px-4 py-2 rounded text-xs font-mono font-bold flex items-center gap-2 transition cursor-pointer ${
              sourceTab === "local"
                ? "bg-[#38BDF8] text-[#0F172A] shadow"
                : "bg-[#0F172A] text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#1E293B]"
            }`}
          >
            <HardDrive className="w-4 h-4" />
            <span>LOCAL FILE / DEMO BENCHMARK</span>
          </button>

          <button
            onClick={() => {
              setSourceTab("azure");
              if (!azureStatus) handleTestAzure();
            }}
            className={`px-4 py-2 rounded text-xs font-mono font-bold flex items-center gap-2 transition cursor-pointer ${
              sourceTab === "azure"
                ? "bg-[#0078D4] text-white shadow"
                : "bg-[#0F172A] text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#1E293B]"
            }`}
          >
            <Cloud className="w-4 h-4 text-[#38BDF8]" />
            <span>AZURE DATA CONNECTIVITY (READ-ONLY)</span>
            {azureStatus === "CONNECTED" && (
              <span className="w-2 h-2 rounded-full bg-[#10B981]"></span>
            )}
          </button>

          <button
            onClick={() => {
              setSourceTab("aws");
              if (!awsStatus) handleTestAWS();
            }}
            className={`px-4 py-2 rounded text-xs font-mono font-bold flex items-center gap-2 transition cursor-pointer ${
              sourceTab === "aws"
                ? "bg-[#FF9900] text-[#0F172A] shadow"
                : "bg-[#0F172A] text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#1E293B]"
            }`}
          >
            <Server className="w-4 h-4 text-[#F59E0B]" />
            <span>AWS S3 CONNECTIVITY (READ-ONLY)</span>
            {awsStatus === "CONNECTED" && (
              <span className="w-2 h-2 rounded-full bg-[#10B981]"></span>
            )}
          </button>
        </div>
      </div>

      {/* Tab 1: Local File Upload & Quick Demos */}
      {sourceTab === "local" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Upload Drop Card */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`lg:col-span-1 border border-dashed rounded p-6 flex flex-col items-center justify-center text-center cursor-pointer transition ${
              dragOver
                ? "border-[#38BDF8] bg-[#38BDF8]/10"
                : "border-[#334155] bg-[#1E293B] hover:border-[#38BDF8]/60 hover:bg-[#1E293B]/80"
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv, .xlsx, .xls, .txt"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  handleFileUpload(e.target.files[0]);
                }
              }}
            />
            <div className="w-11 h-11 rounded bg-[#0F172A] border border-[#334155] flex items-center justify-center text-[#38BDF8] mb-3">
              <Upload className="w-5 h-5" />
            </div>
            <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
              Drop CSV or Excel Dataset
            </h3>
            <p className="text-[11px] text-[#94A3B8] mt-1 font-mono">
              Supports .csv, .xlsx, .xls with stable Observation IDs
            </p>
            <span className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 bg-[#0F172A] border border-[#334155] text-[#38BDF8] rounded text-xs font-mono">
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Select Local File
            </span>
          </div>

          {/* Benchmark Cases Grid */}
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Demo 1: VMC */}
            <div
              onClick={() => onLoadDemo("vmc")}
              className="tech-grid-card p-3.5 hover:border-[#38BDF8] cursor-pointer transition flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-mono font-bold text-[#38BDF8] mb-1">
                  <span>MILLING / RSM</span>
                  <Sparkles className="w-3 h-3" />
                </div>
                <h4 className="text-xs font-bold text-[#F1F5F9] font-mono group-hover:text-[#38BDF8] transition">
                  VMC Cycle Time (RSM)
                </h4>
                <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-2">
                  Spindle speed, feed rate, depth of cut with Response Surface modeling.
                </p>
              </div>
              <div className="mt-3 pt-2 border-t border-[#334155] text-[10px] font-mono text-[#94A3B8] flex justify-between items-center">
                <span>30 Runs • 8 X Vars</span>
                <span className="text-[#38BDF8] font-bold group-hover:underline">Load Case →</span>
              </div>
            </div>

            {/* Demo 2: Pump Leakage */}
            <div
              onClick={() => onLoadDemo("pump")}
              className="tech-grid-card p-3.5 hover:border-[#10B981] cursor-pointer transition flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-mono font-bold text-[#10B981] mb-1">
                  <span>HEAVY INDUSTRY</span>
                  <Database className="w-3 h-3" />
                </div>
                <h4 className="text-xs font-bold text-[#F1F5F9] font-mono group-hover:text-[#10B981] transition">
                  Pump Leakage (100k Obs)
                </h4>
                <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-2">
                  Centrifugal seal leakage diagnostic benchmark with 100,000 production records.
                </p>
              </div>
              <div className="mt-3 pt-2 border-t border-[#334155] text-[10px] font-mono text-[#94A3B8] flex justify-between items-center">
                <span>100,000 Obs • 7 Vars</span>
                <span className="text-[#10B981] font-bold group-hover:underline">Load Case →</span>
              </div>
            </div>

            {/* Demo 3: Gear Profile */}
            <div
              onClick={() => onLoadDemo("gear")}
              className="tech-grid-card p-3.5 hover:border-[#F59E0B] cursor-pointer transition flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-mono font-bold text-[#F59E0B] mb-1">
                  <span>GEAR FINISHING</span>
                  <Table className="w-3 h-3" />
                </div>
                <h4 className="text-xs font-bold text-[#F1F5F9] font-mono group-hover:text-[#F59E0B] transition">
                  Gear Profile Grinding
                </h4>
                <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-2">
                  Tooth profile angle deviation across wheel dressing and infeed rates.
                </p>
              </div>
              <div className="mt-3 pt-2 border-t border-[#334155] text-[10px] font-mono text-[#94A3B8] flex justify-between items-center">
                <span>40 Parts • 8 Vars</span>
                <span className="text-[#F59E0B] font-bold group-hover:underline">Load Case →</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Azure Cloud Connector */}
      {sourceTab === "azure" && (
        <div className="tech-grid-card p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#334155]">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded bg-[#0078D4]/20 border border-[#0078D4] flex items-center justify-center text-[#0078D4]">
                <Cloud className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#F1F5F9] font-mono uppercase tracking-wide">
                  Azure Blob & Data Lake Connector
                </h3>
                <p className="text-[11px] text-[#94A3B8] font-mono">
                  Read-only tabular connector for telemetry CSVs, parquet exports, and inspection logs.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span
                className={`tech-tag ${
                  azureStatus === "CONNECTED"
                    ? "text-[#10B981] border-[#10B981]/40 bg-[#10B981]/10"
                    : azureStatus === "NOT_CONFIGURED"
                    ? "text-[#F59E0B] border-[#F59E0B]/40 bg-[#F59E0B]/10"
                    : "text-[#94A3B8] border-[#334155]"
                }`}
              >
                {azureStatus === "CONNECTED"
                  ? "STATUS: CONNECTED (READ-ONLY)"
                  : azureStatus === "NOT_CONFIGURED"
                  ? "STATUS: NOT CONFIGURED"
                  : "STATUS: DISCONNECTED"}
              </span>

              <button
                onClick={handleTestAzure}
                disabled={isTestingAzure}
                className="px-3 py-1 bg-[#0F172A] border border-[#38BDF8]/40 hover:border-[#38BDF8] text-[#38BDF8] rounded text-xs font-mono font-bold flex items-center gap-1.5 transition cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${isTestingAzure ? "animate-spin" : ""}`} />
                <span>Test Connection</span>
              </button>
            </div>
          </div>

          {/* Connection Message / Parameters */}
          {azureMsg && (
            <div className="p-3 bg-[#0F172A] border border-[#334155] rounded text-xs font-mono flex items-center gap-2 text-[#E2E8F0]">
              <CheckCircle2 className="w-4 h-4 text-[#38BDF8] shrink-0" />
              <span>{azureMsg}</span>
            </div>
          )}

          {/* Discovered Datasets List */}
          <div className="space-y-3">
            <div className="text-xs font-mono font-bold text-[#F1F5F9] uppercase tracking-wider flex items-center justify-between">
              <span>Discovered Cloud Datasets in Azure Container</span>
              <span className="text-[#94A3B8] font-normal text-[11px]">3 Tabular Files Ready</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                {
                  id: "azure_turbine_vib",
                  name: "AZURE_BLOB_TURBINE_VIBRATION.CSV",
                  desc: "Multi-line turbine bearing vibration telemetry (Line 101-103, shifts, temperature, RMS vibration).",
                  rows: 36,
                  cols: 7,
                  y: "vibration_rms_mms",
                },
                {
                  id: "azure_cnc_heatmap",
                  name: "AZURE_DATALAKE_CNC_HEAT_MAP.CSV",
                  desc: "CNC machining spindle vibration & tool wear across Alpha/Beta/Gamma units.",
                  rows: 36,
                  cols: 7,
                  y: "spindle_vib_mms",
                },
                {
                  id: "azure_weld_seam",
                  name: "AZURE_SQL_WELD_SEAM_INSPECTION.CSV",
                  desc: "Robotic weld seam porosity & tensile integrity test results.",
                  rows: 36,
                  cols: 7,
                  y: "tensile_strength_mpa",
                },
              ].map((ds) => (
                <div
                  key={ds.id}
                  className={`tech-grid-card p-3.5 space-y-2 border transition ${
                    selectedAzureDataset === ds.id ? "border-[#38BDF8] bg-[#38BDF8]/5" : "border-[#334155] hover:border-[#38BDF8]/50"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-mono font-bold text-[#38BDF8] uppercase">
                      AZURE DATA LAKE
                    </span>
                    <span className="text-[10px] font-mono text-[#94A3B8]">
                      {ds.rows} Rows • {ds.cols} Cols
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-[#F1F5F9] font-mono truncate">
                    {ds.name}
                  </h4>
                  <p className="text-[11px] text-[#94A3B8] line-clamp-2">
                    {ds.desc}
                  </p>
                  <div className="pt-2 border-t border-[#334155] flex justify-between items-center">
                    <span className="text-[10px] font-mono text-[#38BDF8]">Y: {ds.y}</span>
                    <button
                      onClick={() => handleLoadCloudDataset("azure", ds.id)}
                      disabled={isLoadingAzureData}
                      className="px-2.5 py-1 bg-[#0078D4] hover:bg-[#006cbd] text-white rounded text-[11px] font-mono font-bold transition cursor-pointer flex items-center gap-1"
                    >
                      {isLoadingAzureData && selectedAzureDataset === ds.id ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : null}
                      <span>Load into DataLock</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: AWS S3 Connector */}
      {sourceTab === "aws" && (
        <div className="tech-grid-card p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#334155]">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded bg-[#FF9900]/20 border border-[#FF9900] flex items-center justify-center text-[#FF9900]">
                <Server className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#F1F5F9] font-mono uppercase tracking-wide">
                  Amazon S3 & AWS Manufacturing Lake Connector
                </h3>
                <p className="text-[11px] text-[#94A3B8] font-mono">
                  Direct S3 bucket connector with IAM instance profile authentication.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span
                className={`tech-tag ${
                  awsStatus === "CONNECTED"
                    ? "text-[#10B981] border-[#10B981]/40 bg-[#10B981]/10"
                    : awsStatus === "NOT_CONFIGURED"
                    ? "text-[#F59E0B] border-[#F59E0B]/40 bg-[#F59E0B]/10"
                    : "text-[#94A3B8] border-[#334155]"
                }`}
              >
                {awsStatus === "CONNECTED"
                  ? "STATUS: CONNECTED (READ-ONLY)"
                  : awsStatus === "NOT_CONFIGURED"
                  ? "STATUS: NOT CONFIGURED"
                  : "STATUS: DISCONNECTED"}
              </span>

              <button
                onClick={handleTestAWS}
                disabled={isTestingAWS}
                className="px-3 py-1 bg-[#0F172A] border border-[#F59E0B]/40 hover:border-[#F59E0B] text-[#F59E0B] rounded text-xs font-mono font-bold flex items-center gap-1.5 transition cursor-pointer"
              >
                <RefreshCw className={`w-3 h-3 ${isTestingAWS ? "animate-spin" : ""}`} />
                <span>Test Connection</span>
              </button>
            </div>
          </div>

          {/* Connection Message / Parameters */}
          {awsMsg && (
            <div className="p-3 bg-[#0F172A] border border-[#334155] rounded text-xs font-mono flex items-center gap-2 text-[#E2E8F0]">
              <CheckCircle2 className="w-4 h-4 text-[#F59E0B] shrink-0" />
              <span>{awsMsg}</span>
            </div>
          )}

          {/* Discovered AWS Datasets List */}
          <div className="space-y-3">
            <div className="text-xs font-mono font-bold text-[#F1F5F9] uppercase tracking-wider flex items-center justify-between">
              <span>Discovered Objects in S3 Bucket: mfg-iot-datalake-prod</span>
              <span className="text-[#94A3B8] font-normal text-[11px]">3 Tabular Objects Ready</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                {
                  id: "aws_press_force",
                  name: "S3_PRESS_LINE_FORCE_DATA.CSV",
                  desc: "High-tonnage stamping press tonnage, die temperature & peak force variance.",
                  rows: 36,
                  cols: 7,
                  y: "peak_force_kn",
                },
                {
                  id: "aws_extrusion_temp",
                  name: "S3_EXTRUSION_BARREL_TEMP.CSV",
                  desc: "Polymer extrusion barrel thermal zone profiles and melt discharge pressures.",
                  rows: 36,
                  cols: 7,
                  y: "melt_pressure_bar",
                },
                {
                  id: "aws_bearing_acoustic",
                  name: "S3_BEARING_ACOUSTIC_EMISSION.CSV",
                  desc: "High-frequency acoustic emission peaks from endurance bearing test rigs.",
                  rows: 36,
                  cols: 7,
                  y: "acoustic_peak_db",
                },
              ].map((ds) => (
                <div
                  key={ds.id}
                  className={`tech-grid-card p-3.5 space-y-2 border transition ${
                    selectedAwsDataset === ds.id ? "border-[#FF9900] bg-[#FF9900]/5" : "border-[#334155] hover:border-[#FF9900]/50"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-mono font-bold text-[#FF9900] uppercase">
                      AMAZON S3
                    </span>
                    <span className="text-[10px] font-mono text-[#94A3B8]">
                      {ds.rows} Rows • {ds.cols} Cols
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-[#F1F5F9] font-mono truncate">
                    {ds.name}
                  </h4>
                  <p className="text-[11px] text-[#94A3B8] line-clamp-2">
                    {ds.desc}
                  </p>
                  <div className="pt-2 border-t border-[#334155] flex justify-between items-center">
                    <span className="text-[10px] font-mono text-[#FF9900]">Y: {ds.y}</span>
                    <button
                      onClick={() => handleLoadCloudDataset("aws", ds.id)}
                      disabled={isLoadingAwsData}
                      className="px-2.5 py-1 bg-[#FF9900] hover:bg-[#e68a00] text-[#0F172A] rounded text-[11px] font-mono font-bold transition cursor-pointer flex items-center gap-1"
                    >
                      {isLoadingAwsData && selectedAwsDataset === ds.id ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : null}
                      <span>Load into DataLock</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Automated Validation & Hygiene Summary */}
      {validation && (
        <div className="tech-grid-card p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#334155]">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                Automated Data Validation & Hygiene Inspection
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="tech-tag text-[#10B981] border-[#10B981]/40 bg-[#10B981]/10">
                STATUS: HYGIENE VERIFIED
              </span>
            </div>
          </div>

          {/* Validation Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Total Rows (N)</div>
              <div className="font-mono text-base font-bold text-[#F1F5F9]">
                {validation.row_count?.toLocaleString?.() ?? (rawData?.length ? rawData.length.toLocaleString() : 0)}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Total Columns</div>
              <div className="font-mono text-base font-bold text-[#F1F5F9]">
                {validation.col_count ?? (validation.columns ? validation.columns.length : 0)}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Numeric Variables</div>
              <div className="font-mono text-base font-bold text-[#38BDF8]">
                {validation.numeric_columns?.length ?? 0}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Categorical X</div>
              <div className="font-mono text-base font-bold text-[#A855F7]">
                {validation.categorical_columns?.length ?? 0}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Identified ID Col</div>
              <div className="font-mono text-xs font-bold text-[#F1F5F9] truncate mt-1">
                {validation.id_column || "id"}
              </div>
            </div>
            <div className="tech-subcard p-3">
              <div className="text-[10px] uppercase font-mono text-[#94A3B8] mb-1">Duplicate IDs</div>
              <div className="font-mono text-base font-bold text-[#10B981]">
                {validation.has_duplicate_ids ? validation.duplicate_id_count : "0 (Pass)"}
              </div>
            </div>
          </div>

          {/* Constant Variables Warning if any */}
          {validation.constant_columns && validation.constant_columns.length > 0 && (
            <div className="p-3 bg-[#422006]/60 border border-[#F59E0B] rounded text-xs font-mono text-[#F59E0B] flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>
                Constant parameter detected: <strong>{validation.constant_columns.join(", ")}</strong>. These exhibit 0 variance across all observations and are excluded from discriminatory X-ranking.
              </span>
            </div>
          )}
        </div>
      )}

      {/* Raw Tabular Preview & Search */}
      {rawData.length > 0 && (
        <div className="tech-grid-card p-4 sm:p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#334155]">
            <div className="flex items-center gap-2">
              <Table className="w-4 h-4 text-[#38BDF8]" />
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                Tabular Dataset Records ({rawData.length} Rows)
              </h3>
            </div>

            {/* Search filter input */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-[#94A3B8] absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search values or IDs..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setPage(1);
                }}
                className="w-full bg-[#0F172A] border border-[#334155] rounded pl-8 pr-3 py-1 text-xs text-[#F1F5F9] font-mono focus:border-[#38BDF8] focus:outline-none"
              />
            </div>
          </div>

          {/* Tabular Table */}
          <div className="overflow-x-auto border border-[#334155] rounded">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0F172A] text-[#94A3B8] border-b border-[#334155]">
                <tr>
                  <th className="px-3 py-2 text-[#38BDF8] font-bold">#</th>
                  {columns.map((c) => (
                    <th key={c} className="px-3 py-2 whitespace-nowrap">
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#334155]/60 bg-[#1E293B]">
                {displayedRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-[#334155]/30 transition">
                    <td className="px-3 py-1.5 text-[#64748B] font-bold">
                      {(page - 1) * pageSize + idx + 1}
                    </td>
                    {columns.map((c) => (
                      <td key={c} className="px-3 py-1.5 text-[#F1F5F9] whitespace-nowrap">
                        {String(row[c] ?? "")}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between text-xs font-mono text-[#94A3B8] pt-2">
            <span>
              Showing {(page - 1) * pageSize + 1} to {Math.min(page * pageSize, filteredRows.length)} of {filteredRows.length} rows
            </span>
            <div className="flex gap-1">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-2.5 py-1 rounded bg-[#0F172A] border border-[#334155] text-[#F1F5F9] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#334155] transition cursor-pointer"
              >
                Previous
              </button>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page >= totalPages}
                className="px-2.5 py-1 rounded bg-[#0F172A] border border-[#334155] text-[#F1F5F9] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#334155] transition cursor-pointer"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
