import React, { useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  FlaskConical,
  HelpCircle,
  Play,
  Plus,
  Trash2,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
  Cell,
} from "recharts";
import { DOEAnalysisResult, DOEPlanFactor, DOEPlanResult, DOERunRow } from "../types";

export const DOEView: React.FC = () => {
  // Factors configuration
  const [factors, setFactors] = useState<DOEPlanFactor[]>([
    { name: "Spindle_Speed", low: 1800, high: 2600, unit: "RPM" },
    { name: "Feed_Rate", low: 450, high: 750, unit: "mm/min" },
    { name: "Depth_of_Cut", low: 0.8, high: 2.0, unit: "mm" },
  ]);

  const [centerPoints, setCenterPoints] = useState<number>(3);
  const [replicates, setReplicates] = useState<number>(1);
  const [doePlan, setDoePlan] = useState<DOEPlanResult | null>(null);
  const [isPlanning, setIsPlanning] = useState(false);

  // Response inputs
  const [runResponses, setRunResponses] = useState<Record<number, number>>({});
  const [analysisResult, setAnalysisResult] = useState<DOEAnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Add new factor
  const addFactor = () => {
    if (factors.length >= 6) {
      alert("Full Factorial supports up to 6 factors in V1.");
      return;
    }
    const idx = factors.length + 1;
    setFactors([...factors, { name: `Factor_${idx}`, low: 10, high: 50, unit: "unit" }]);
  };

  const removeFactor = (index: number) => {
    if (factors.length <= 2) {
      alert("At least 2 factors are required for Full Factorial DOE.");
      return;
    }
    setFactors(factors.filter((_, i) => i !== index));
  };

  // Generate Plan Matrix
  const handleGeneratePlan = async () => {
    setIsPlanning(true);
    try {
      const res = await fetch("/api/doe/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          factors,
          center_points: centerPoints,
          replicates,
        }),
      });
      const data = await res.json();
      setDoePlan(data);

      const initialResponses: Record<number, number> = {};
      data.design_matrix.forEach((row: DOERunRow) => {
        const x1 = row.coded[factors[0]?.name] ?? 0;
        const x2 = row.coded[factors[1]?.name] ?? 0;
        const x3 = factors[2] ? row.coded[factors[2]?.name] ?? 0 : 0;
        const simulatedY = 120 - 15 * x1 + 10 * x2 - 5 * x3 + 8 * (x1 * x2) + (Math.random() * 2 - 1);
        initialResponses[row.std_order] = parseFloat(simulatedY.toFixed(2));
      });
      setRunResponses(initialResponses);
    } catch (err: any) {
      alert(`DOE Planning Error: ${err.message}`);
    } finally {
      setIsPlanning(false);
    }
  };

  // Analyze DOE
  const handleAnalyzeDOE = async () => {
    if (!doePlan) return;
    setIsAnalyzing(true);
    try {
      const missingRuns = doePlan.design_matrix.filter(
        (row) => runResponses[row.std_order] === undefined || isNaN(runResponses[row.std_order])
      );
      if (missingRuns.length > 0) {
        alert(`Please enter valid numerical response measurements for all ${doePlan.design_matrix.length} experimental runs before analysis. Missing values must not default to 0.`);
        setIsAnalyzing(false);
        return;
      }

      const populatedMatrix = doePlan.design_matrix.map((row) => ({
        ...row,
        response_y: runResponses[row.std_order],
      }));

      const res = await fetch("/api/doe/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          design_matrix: populatedMatrix,
          factor_names: factors.map((f) => f.name),
        }),
      });
      const data = await res.json();
      setAnalysisResult(data);
    } catch (err: any) {
      alert(`DOE Analysis Error: ${err.message}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">10. FULL FACTORIAL DOE</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              DESIGN TYPE: 2^{factors.length} WITH CENTER POINTS
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            Full Factorial DOE Planning & Pareto Interaction Analysis
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Construct orthogonal 2-level experimental matrices ($2^k$) with replicated center points. 
            Compute main effects, 2-factor interactions, ANOVA regression parameters, and Pareto significance rankings.
          </p>
        </div>

        <button
          onClick={handleGeneratePlan}
          disabled={isPlanning}
          className="tech-btn-run px-5 py-2.5 rounded flex items-center gap-2 cursor-pointer shrink-0 shadow-md"
        >
          <FlaskConical className="w-4 h-4" />
          <span>{doePlan ? "REGENERATE MATRIX" : "GENERATE 2^k MATRIX"}</span>
        </button>
      </div>

      {/* Factor Configuration Table */}
      <div className="tech-grid-card p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
          <div>
            <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
              Factor Setup (k = {factors.length} → 2^{factors.length} = {Math.pow(2, factors.length)} factorial runs)
            </h3>
            <p className="text-[11px] text-[#94A3B8] font-mono">
              Set Low (-1) and High (+1) operational levels for each candidate factor.
            </p>
          </div>
          <button
            onClick={addFactor}
            className="px-2.5 py-1 rounded bg-[#0F172A] border border-[#334155] text-[#38BDF8] hover:bg-[#334155] transition text-xs font-mono font-bold flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Factor</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {factors.map((factor, idx) => (
            <div
              key={idx}
              className="p-3 bg-[#0F172A] border border-[#334155] rounded space-y-2 relative font-mono"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#38BDF8]">
                  Factor {idx + 1}
                </span>
                {factors.length > 2 && (
                  <button
                    onClick={() => removeFactor(idx)}
                    className="text-[#64748B] hover:text-[#F43F5E] cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div>
                <label className="text-[10px] text-[#94A3B8] block uppercase">Name</label>
                <input
                  type="text"
                  value={factor.name}
                  onChange={(e) => {
                    const next = [...factors];
                    next[idx].name = e.target.value;
                    setFactors(next);
                  }}
                  className="w-full px-2 py-1 text-xs bg-[#1E293B] border border-[#334155] rounded font-bold text-[#F1F5F9]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-[#94A3B8] block uppercase">Low (-1)</label>
                  <input
                    type="number"
                    value={factor.low}
                    onChange={(e) => {
                      const next = [...factors];
                      next[idx].low = parseFloat(e.target.value) || 0;
                      setFactors(next);
                    }}
                    className="w-full px-2 py-1 text-xs bg-[#1E293B] border border-[#334155] rounded text-[#F1F5F9]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#94A3B8] block uppercase">High (+1)</label>
                  <input
                    type="number"
                    value={factor.high}
                    onChange={(e) => {
                      const next = [...factors];
                      next[idx].high = parseFloat(e.target.value) || 0;
                      setFactors(next);
                    }}
                    className="w-full px-2 py-1 text-xs bg-[#1E293B] border border-[#334155] rounded text-[#F1F5F9]"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-[#334155] text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-[#94A3B8]">Center Points (0,0):</span>
            <input
              type="number"
              min={0}
              max={10}
              value={centerPoints}
              onChange={(e) => setCenterPoints(parseInt(e.target.value) || 0)}
              className="w-16 px-2 py-1 bg-[#0F172A] border border-[#334155] rounded text-center font-bold text-[#F1F5F9]"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[#94A3B8]">Factorial Replicates:</span>
            <input
              type="number"
              min={1}
              max={5}
              value={replicates}
              onChange={(e) => setReplicates(parseInt(e.target.value) || 1)}
              className="w-16 px-2 py-1 bg-[#0F172A] border border-[#334155] rounded text-center font-bold text-[#F1F5F9]"
            />
          </div>
        </div>
      </div>

      {/* Experimental Design Matrix & Response Inputs */}
      {doePlan && (
        <div className="tech-grid-card p-4 sm:p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-[#334155]">
            <div>
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                Design Matrix & Trial Response Entry ({doePlan.total_runs} Total Runs)
              </h3>
              <p className="text-[11px] text-[#94A3B8] font-mono">
                Execute runs in randomized standard order and record measured response values.
              </p>
            </div>

            <button
              onClick={handleAnalyzeDOE}
              disabled={isAnalyzing}
              className="tech-btn-run px-4 py-2 rounded flex items-center gap-1.5 cursor-pointer text-xs shadow-md"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{isAnalyzing ? "COMPUTING..." : "COMPUTE ANOVA & PARETO"}</span>
            </button>
          </div>

          <div className="overflow-x-auto border border-[#334155] rounded max-h-80 overflow-y-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#0F172A] text-[#94A3B8] sticky top-0 border-b border-[#334155]">
                <tr>
                  <th className="px-3 py-2">Std Order</th>
                  <th className="px-3 py-2">Run Type</th>
                  {factors.map((f) => (
                    <th key={f.name} className="px-3 py-2 text-[#CBD5E1]">
                      {f.name} (Actual)
                    </th>
                  ))}
                  {factors.map((f) => (
                    <th key={`coded-${f.name}`} className="px-3 py-2 text-[#64748B]">
                      {f.name} (Coded)
                    </th>
                  ))}
                  <th className="px-3 py-2 bg-[#38BDF8]/10 text-[#38BDF8]">
                    Measured Response (Y)
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
                {doePlan.design_matrix.map((row) => (
                  <tr key={row.std_order} className="hover:bg-[#0F172A]">
                    <td className="px-3 py-2 font-bold text-[#38BDF8]">{row.std_order}</td>
                    <td className="px-3 py-2">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          row.type === "Center"
                            ? "bg-[#F59E0B]/20 text-[#FBBF24] border border-[#F59E0B]/40"
                            : "bg-[#334155]/40 text-[#94A3B8]"
                        }`}
                      >
                        {row.type}
                      </span>
                    </td>
                    {factors.map((f) => (
                      <td key={f.name} className="px-3 py-2 font-bold">
                        {row.actual[f.name]}
                      </td>
                    ))}
                    {factors.map((f) => (
                      <td key={`c-${f.name}`} className="px-3 py-2 text-[#64748B]">
                        {row.coded[f.name] > 0 ? "+1" : row.coded[f.name] < 0 ? "-1" : "0"}
                      </td>
                    ))}
                    <td className="px-3 py-2 bg-[#38BDF8]/5">
                      <input
                        type="number"
                        step="any"
                        value={runResponses[row.std_order] ?? ""}
                        onChange={(e) => {
                          setRunResponses({
                            ...runResponses,
                            [row.std_order]: parseFloat(e.target.value) || 0,
                          });
                        }}
                        className="w-24 px-2 py-1 text-xs bg-[#0F172A] border border-[#38BDF8]/40 rounded font-bold text-[#38BDF8]"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Analysis Results: Pareto Chart & ANOVA Coefficients */}
      {analysisResult && (
        <div className="tech-grid-card p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#334155]">
            <div>
              <h3 className="text-xs font-bold text-[#F1F5F9] uppercase tracking-wider font-mono">
                DOE Analysis: Pareto Chart of Standardized Effects & ANOVA Model
              </h3>
              <p className="text-[11px] font-mono text-[#94A3B8]">
                Model R²: <strong className="text-[#38BDF8]">{(analysisResult.model_summary.r_squared * 100).toFixed(2)}%</strong> (Adj R²: {(analysisResult.model_summary.adj_r_squared * 100).toFixed(2)}%) • RMSE: {analysisResult.model_summary.rmse.toFixed(3)}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Pareto Chart */}
            <div className="tech-viz-container p-3 space-y-2">
              <div className="text-[10px] uppercase font-mono font-bold text-[#94A3B8]">
                Pareto Chart of Standardized Effects (α = 0.05)
              </div>
              <div className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={analysisResult.pareto_effects}
                    margin={{ top: 10, right: 30, bottom: 10, left: 60 }}
                  >
                    <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.6} />
                    <XAxis type="number" fontSize={10} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                    <YAxis dataKey="term" type="category" fontSize={10} width={80} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                    <Tooltip
                      content={({ payload }) => {
                        if (!payload || payload.length === 0) return null;
                        const d = payload[0].payload;
                        return (
                          <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2 rounded text-xs font-mono space-y-1">
                            <p className="font-bold text-[#38BDF8]">{d.term}</p>
                            <p>Standardized Effect (t): {d.t_stat.toFixed(3)}</p>
                            <p>p-value: {d.p_value.toFixed(4)}</p>
                            <p className={d.significant ? "text-[#34D399] font-bold" : "text-[#94A3B8]"}>
                              {d.significant ? "Statistically Significant (p < 0.05)" : "Not Significant"}
                            </p>
                          </div>
                        );
                      }}
                    />
                    <ReferenceLine x={2.0} stroke="#F43F5E" strokeDasharray="3 3" label={{ value: "t = 2.0 (p = 0.05)", fill: "#F43F5E", fontSize: 10 }} />
                    <Bar dataKey="abs_effect" radius={[0, 3, 3, 0]}>
                      {analysisResult.pareto_effects.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.significant ? "#38BDF8" : "#475569"}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Regression Model Parameter Table */}
            <div className="tech-subcard p-3 space-y-2">
              <div className="text-[10px] uppercase font-mono font-bold text-[#38BDF8]">
                Estimated Model Coefficients & Significance
              </div>

              <div className="overflow-x-auto border border-[#334155] rounded">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-[#1E293B] text-[#94A3B8] border-b border-[#334155]">
                    <tr>
                      <th className="px-2.5 py-1.5">Term</th>
                      <th className="px-2.5 py-1.5">Coef</th>
                      <th className="px-2.5 py-1.5">SE</th>
                      <th className="px-2.5 py-1.5">t-stat</th>
                      <th className="px-2.5 py-1.5">p-value</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#334155] text-[#F1F5F9]">
                    {analysisResult.coefficients.map((c) => (
                      <tr key={c.term} className="hover:bg-[#1E293B]/60">
                        <td className="px-2.5 py-1.5 font-bold text-[#F1F5F9]">{c.term}</td>
                        <td className="px-2.5 py-1.5">{c.coef.toFixed(3)}</td>
                        <td className="px-2.5 py-1.5">{c.se.toFixed(3)}</td>
                        <td className="px-2.5 py-1.5">{c.t_stat.toFixed(3)}</td>
                        <td className="px-2.5 py-1.5 font-bold text-[#38BDF8]">
                          {c.p_value.toFixed(4)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
