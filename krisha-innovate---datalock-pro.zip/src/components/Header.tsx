import React from "react";
import { 
  Activity, 
  CheckCircle2, 
  Database,
  FlaskConical, 
  Layers, 
  PlayCircle, 
  RotateCcw, 
  ShieldAlert, 
  Sliders, 
  Sparkles, 
  Table2, 
  Target 
} from "lucide-react";

export type TabType = 
  | "data" 
  | "y_analysis" 
  | "comparison" 
  | "stratification" 
  | "is_is_not" 
  | "capability" 
  | "correlation" 
  | "regression" 
  | "patterns" 
  | "doe" 
  | "rsm";

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  datasetName: string;
  rowCount: number;
  selectedBadCount: number;
  selectedGoodCount: number;
  hasCompared: boolean;
  onLoadDemo: (name: string) => void;
  onReset: () => void;
  onOpenTestModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  datasetName,
  rowCount,
  selectedBadCount,
  selectedGoodCount,
  hasCompared,
  onLoadDemo,
  onReset,
  onOpenTestModal,
}) => {
  return (
    <header className="bg-[#1E293B] border-b-2 border-[#334155] text-[#F1F5F9] sticky top-0 z-40 shadow-lg">
      {/* Top Technical Header Bar */}
      <div className="max-w-[1700px] mx-auto px-4 sm:px-6 lg:px-8 h-15 flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Diagnostics Stamp */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#0F172A] border border-[#38BDF8]/40 flex items-center justify-center text-[#38BDF8] shadow-inner">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-sm text-[#F1F5F9]">
                KRISHA<span className="text-[#38BDF8]">INNOVATE</span>
              </span>
              <span className="text-[#64748B] text-xs font-mono">|</span>
              <span className="text-xs font-bold text-[#E2E8F0] tracking-wider uppercase">
                DATALOCK PRO
              </span>
              <span className="tech-tag">
                V1.0.4-DIAGNOSTIC
              </span>
            </div>
          </div>
        </div>

        {/* Dataset Status & Actions Bar */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Validation Status Badge */}
          {rowCount > 0 && (
            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-[#10B981] text-[#020617] rounded text-[10px] font-extrabold tracking-wide uppercase">
              <CheckCircle2 className="w-3 h-3 stroke-[3]" />
              <span>DATA VALIDATED</span>
            </div>
          )}

          {/* Active Dataset Filename Display */}
          <div className="hidden md:flex items-center gap-1.5 bg-[#0F172A] px-2.5 py-1 rounded border border-[#334155] text-xs font-mono text-[#94A3B8]">
            <Database className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span className="text-[#F1F5F9] font-bold truncate max-w-[200px]">
              {datasetName || "NO_DATASET_LOADED.CSV"}
            </span>
            {rowCount > 0 && (
              <span className="text-[11px] text-[#38BDF8]">
                [{rowCount?.toLocaleString?.() ?? rowCount} N]
              </span>
            )}
          </div>

          {/* Quick Demo Dataset Dropdown */}
          <div className="flex items-center gap-1.5 bg-[#0F172A] px-2.5 py-1 rounded border border-[#334155] text-xs">
            <span className="text-[#94A3B8] font-mono text-[11px] uppercase">Demo:</span>
            <select
              className="bg-transparent text-[#F1F5F9] focus:outline-none cursor-pointer pr-1 font-mono text-xs"
              onChange={(e) => {
                if (e.target.value) {
                  onLoadDemo(e.target.value);
                  e.target.value = "";
                }
              }}
              defaultValue=""
            >
              <option value="" disabled className="bg-[#1E293B] text-[#94A3B8]">
                Select Case...
              </option>
              <option value="vmc" className="bg-[#1E293B] text-[#F1F5F9]">
                ⚙️ VMC Cycle Time (RSM)
              </option>
              <option value="pump" className="bg-[#1E293B] text-[#F1F5F9]">
                🚰 Pump Leakage (100k Obs)
              </option>
              <option value="gear" className="bg-[#1E293B] text-[#F1F5F9]">
                🔩 Gear Flank Grinding (Angle Dev)
              </option>
              <option value="zero_variance" className="bg-[#1E293B] text-[#F1F5F9]">
                🧪 Test: Zero Variance
              </option>
              <option value="false_range" className="bg-[#1E293B] text-[#F1F5F9]">
                🧪 Test: False Range Separation
              </option>
            </select>
          </div>

          {/* Automated Engine Test Runner Button */}
          <button
            onClick={onOpenTestModal}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#064E3B] text-[#34D399] hover:bg-[#065F46] border border-[#059669]/60 text-xs font-mono font-bold transition cursor-pointer"
            title="Run 12 Automated Statistical Invariant Tests"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-[#34D399]" />
            <span>VERIFY (12/12)</span>
          </button>

          {/* Reset Workspace */}
          <button
            onClick={onReset}
            className="p-1.5 rounded bg-[#0F172A] text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#334155] border border-[#334155] transition cursor-pointer"
            title="Reset Workspace"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Technical Workflow Navigation Rail / Tabs */}
      <div className="bg-[#0F172A] border-t border-[#334155]">
        <div className="max-w-[1700px] mx-auto px-2 sm:px-4">
          <nav className="flex space-x-0.5 overflow-x-auto py-1 scrollbar-none text-xs font-mono">
            {/* 01. Data Validation */}
            <button
              onClick={() => setActiveTab("data")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "data"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <Table2 className="w-3.5 h-3.5" />
              <span>01. Data & Validation</span>
              {rowCount > 0 && (
                <span className="ml-1 px-1 py-0.2 bg-[#1E293B] text-[#38BDF8] rounded text-[10px]">
                  {rowCount}
                </span>
              )}
            </button>

            {/* 02. Y-Analysis & 5 vs 5 Selection */}
            <button
              onClick={() => setActiveTab("y_analysis")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "y_analysis"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <Target className="w-3.5 h-3.5" />
              <span>02. Y-Analysis & Selection</span>
              <div className="flex items-center gap-1 ml-1 text-[10px]">
                <span className={`px-1 rounded ${selectedBadCount === 5 ? "bg-[#F43F5E] text-white" : "bg-[#1E293B] text-[#FB7185]"}`}>
                  B:{selectedBadCount}/5
                </span>
                <span className={`px-1 rounded ${selectedGoodCount === 5 ? "bg-[#10B981] text-[#020617] font-bold" : "bg-[#1E293B] text-[#34D399]"}`}>
                  G:{selectedGoodCount}/5
                </span>
              </div>
            </button>

            {/* 03. Statistical Prioritization / X-Candidate Diagnostics */}
            <button
              onClick={() => setActiveTab("comparison")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "comparison"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>03. X-Candidate Diagnostics</span>
              {hasCompared && (
                <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse"></span>
              )}
            </button>

            {/* 04. Stratification */}
            <button
              onClick={() => setActiveTab("stratification")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "stratification"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>04. Stratification Engine</span>
            </button>

            {/* 05. IS / IS NOT */}
            <button
              onClick={() => setActiveTab("is_is_not")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "is_is_not"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>05. IS / IS NOT Workspace</span>
            </button>

            {/* 06. SPC Capability */}
            <button
              onClick={() => setActiveTab("capability")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "capability"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>06. Statistical Capability</span>
            </button>

            {/* 07. Correlation Matrix */}
            <button
              onClick={() => setActiveTab("correlation")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "correlation"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>07. Correlation Matrix</span>
            </button>

            {/* 08. Regression Engine */}
            <button
              onClick={() => setActiveTab("regression")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "regression"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <PlayCircle className="w-3.5 h-3.5" />
              <span>08. Regression Engine</span>
            </button>

            {/* 09. Pattern Detection */}
            <button
              onClick={() => setActiveTab("patterns")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "patterns"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>09. Pattern Detection</span>
            </button>

            {/* 10. DoE Full Factorial */}
            <button
              onClick={() => setActiveTab("doe")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "doe"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <FlaskConical className="w-3.5 h-3.5" />
              <span>10. DoE Planner (V1.2)</span>
            </button>

            {/* 11. Response Surface Opt */}
            <button
              onClick={() => setActiveTab("rsm")}
              className={`px-3 py-1.5 rounded-t text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer border-b-2 ${
                activeTab === "rsm"
                  ? "bg-[#38BDF8]/10 text-[#38BDF8] border-[#38BDF8] font-bold"
                  : "text-[#94A3B8] border-transparent hover:bg-[#1E293B] hover:text-[#F1F5F9]"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>11. Response Surface Opt</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
