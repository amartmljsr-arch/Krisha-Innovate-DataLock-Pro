import React, { useState, useEffect } from "react";
import { 
  Activity, 
  AlertOctagon, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle, 
  Layers, 
  Sparkles, 
  TrendingUp 
} from "lucide-react";
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  ReferenceLine 
} from "recharts";
import { AnomalyPatternResult, ValidationResult } from "../types";

interface PatternsViewProps {
  rawData: any[];
  validation: ValidationResult | null;
  selectedY: string;
}

export const PatternsView: React.FC<PatternsViewProps> = ({
  rawData,
  validation,
  selectedY,
}) => {
  const [results, setResults] = useState<AnomalyPatternResult | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);

  const handleDetectPatterns = async () => {
    if (!selectedY || rawData.length === 0) return;
    setIsEvaluating(true);
    try {
      const yValues = rawData.map((r) => parseFloat(r[selectedY])).filter((v) => !isNaN(v));
      const res = await fetch("/api/patterns", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data: yValues }),
      });
      const data = await res.json();
      setResults(data);
    } catch (err: any) {
      alert(`Pattern detection error: ${err.message}`);
    } finally {
      setIsEvaluating(false);
    }
  };

  useEffect(() => {
    handleDetectPatterns();
  }, [selectedY]);

  // Run sequence chart data
  const sequenceData = rawData.map((r, i) => {
    const val = parseFloat(r[selectedY]);
    const anomaly = results?.anomalies.find((a) => a.index === i);
    return {
      index: i + 1,
      yValue: isNaN(val) ? 0 : val,
      isAnomaly: !!anomaly,
      anomalyType: anomaly?.type,
    };
  });

  return (
    <div className="space-y-5">
      {/* Top Diagnostic Banner */}
      <div className="tech-grid-card p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="tech-tag">09. ANOMALIES & SPC PATTERNS</span>
            <span className="text-[11px] font-mono text-[#94A3B8]">
              TARGET Y: {selectedY}
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#F1F5F9] font-mono">
            SPC Western Electric Pattern & Outlier Diagnostics
          </h2>
          <p className="text-xs text-[#94A3B8] max-w-3xl leading-relaxed">
            Automated screening for non-random statistical patterns: consecutive runs, monotonic trends, 3-sigma excursions, and robust modified Z-score outliers.
          </p>
        </div>

        <button
          onClick={handleDetectPatterns}
          disabled={isEvaluating}
          className="tech-btn-run px-5 py-2.5 rounded flex items-center gap-2 cursor-pointer shrink-0 shadow-md"
        >
          <Activity className="w-4 h-4" />
          <span>{isEvaluating ? "EVALUATING..." : "REEVALUATE PATTERNS"}</span>
        </button>
      </div>

      {/* Main Grid: Sequence Chart on Left, Flags on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Sequence Chart */}
        <div className="lg:col-span-2 tech-viz-container p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
            <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
              Time-Ordered Run Sequence Chart ({selectedY})
            </span>
            {results && (
              <span className="text-[10px] font-mono text-[#F59E0B]">
                {results.anomaly_count} ANOMALIES DETECTED
              </span>
            )}
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={sequenceData} margin={{ top: 15, right: 20, bottom: 20, left: 10 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#334155" opacity={0.6} />
                <XAxis dataKey="index" fontSize={10} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                <YAxis fontSize={10} tick={{ fill: "#94A3B8" }} stroke="#334155" />
                <Tooltip
                  content={({ payload }) => {
                    if (!payload || payload.length === 0) return null;
                    const d = payload[0].payload;
                    return (
                      <div className="bg-[#0F172A] border border-[#334155] text-[#F1F5F9] p-2 rounded text-xs font-mono space-y-1">
                        <p className="font-bold text-[#38BDF8]">Sequence #{d.index}</p>
                        <p>{selectedY}: <strong className="text-white">{d.yValue}</strong></p>
                        {d.isAnomaly && (
                          <p className="text-[#F43F5E] font-bold">
                            ⚠️ Anomaly: {d.anomalyType}
                          </p>
                        )}
                      </div>
                    );
                  }}
                />
                {results && (
                  <ReferenceLine
                    y={results.mean}
                    stroke="#38BDF8"
                    strokeDasharray="3 3"
                    label={{ value: `Mean: ${results.mean.toFixed(2)}`, fill: "#38BDF8", fontSize: 10 }}
                  />
                )}
                <Line
                  type="monotone"
                  dataKey="yValue"
                  stroke="#38BDF8"
                  strokeWidth={1.5}
                  dot={(props: any) => {
                    const { cx, cy, payload } = props;
                    if (payload.isAnomaly) {
                      return (
                        <circle
                          key={`dot-${props.key}`}
                          cx={cx}
                          cy={cy}
                          r={5}
                          fill="#F43F5E"
                          stroke="#FFFFFF"
                          strokeWidth={1.5}
                        />
                      );
                    }
                    return (
                      <circle
                        key={`dot-${props.key}`}
                        cx={cx}
                        cy={cy}
                        r={2.5}
                        fill="#38BDF8"
                      />
                    );
                  }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pattern Summary & Flags */}
        <div className="tech-grid-card p-4 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#334155]">
            <span className="text-xs font-bold font-mono text-[#F1F5F9] uppercase">
              Western Electric Rules
            </span>
          </div>

          <div className="space-y-2 font-mono text-xs max-h-72 overflow-y-auto">
            {results?.patterns && results.patterns.length > 0 ? (
              results.patterns.map((p, idx) => (
                <div
                  key={idx}
                  className="p-2.5 bg-[#0F172A] border border-[#F59E0B]/40 rounded space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#F59E0B]">{p.pattern}</span>
                    <span className="text-[10px] text-[#94A3B8]">{p.rule}</span>
                  </div>
                  <p className="text-[11px] text-[#CBD5E1]">{p.description}</p>
                </div>
              ))
            ) : (
              <div className="p-4 bg-[#0F172A] border border-[#10B981]/30 rounded text-center space-y-1">
                <CheckCircle2 className="w-6 h-6 text-[#10B981] mx-auto" />
                <span className="font-bold text-[#10B981] block">
                  Process in Statistical Control
                </span>
                <p className="text-[11px] text-[#94A3B8]">
                  No non-random Western Electric runs or trend anomalies detected.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
