import express, { Request, Response } from "express";
import path from "path";
import { spawn } from "child_process";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Helper to execute Python engine commands via stdin/stdout IPC
function runPythonEngine(command: string, inputData: any): Promise<any> {
  return new Promise((resolve, reject) => {
    const pythonProcess = spawn("python3", ["datalock_engine.py", command]);
    let stdoutData = "";
    let stderrData = "";

    if (inputData !== undefined && inputData !== null) {
      pythonProcess.stdin.write(JSON.stringify(inputData));
      pythonProcess.stdin.end();
    }

    pythonProcess.stdout.on("data", (chunk) => {
      stdoutData += chunk.toString();
    });

    pythonProcess.stderr.on("data", (chunk) => {
      stderrData += chunk.toString();
    });

    pythonProcess.on("close", (code) => {
      if (code !== 0) {
        return reject(new Error(`Python process failed (code ${code}): ${stderrData || stdoutData}`));
      }
      try {
        const parsed = JSON.parse(stdoutData.trim());
        resolve(parsed);
      } catch (err) {
        reject(new Error(`Failed to parse Python JSON output: ${stdoutData}\nStderr: ${stderrData}`));
      }
    });

    pythonProcess.on("error", (err) => {
      reject(err);
    });
  });
}

// --- API Endpoints ---

// 1. Health check
app.get("/api/health", (req: Request, res: Response) => {
  res.json({ status: "ok", engine: "Krisha Innovate - DataLock Pro (Python 3)" });
});

// 2. Validate dataset
app.post("/api/validate", async (req: Request, res: Response) => {
  try {
    const rows = req.body.rows || req.body.data || [];
    const id_col = req.body.id_col || req.body.id_column || null;

    if (!Array.isArray(rows) || rows.length === 0) {
      return res.json({
        is_valid: false,
        error: "The uploaded dataset is empty.",
        row_count: 0,
        col_count: 0,
        id_column: "id",
        has_duplicate_ids: false,
        duplicate_id_count: 0,
        numeric_columns: [],
        categorical_columns: [],
        constant_columns: [],
        columns: [],
      });
    }

    const result = await runPythonEngine("validate", { rows, id_col });
    if (result && result.is_valid !== undefined) {
      res.json(result);
    } else {
      // Fallback node validation if python returned unexpected shape
      const keys = Object.keys(rows[0] || {});
      const numeric_columns: string[] = [];
      const categorical_columns: string[] = [];
      const constant_columns: string[] = [];

      keys.forEach((k) => {
        const vals = rows.map((r: any) => r[k]);
        const numVals = vals.filter((v: any) => v !== null && v !== "" && !isNaN(Number(v)));
        const distinct = new Set(vals.map((v: any) => String(v)));
        if (distinct.size <= 1) constant_columns.push(k);

        if (numVals.length > 0 && numVals.length >= 0.8 * rows.length) {
          numeric_columns.push(k);
        } else {
          categorical_columns.push(k);
        }
      });

      const detectedId = id_col || keys.find((k) => /id|serial|sn|obs|sample|run/i.test(k)) || keys[0] || "id";
      res.json({
        is_valid: true,
        row_count: rows.length,
        col_count: keys.length,
        id_column: detectedId,
        has_duplicate_ids: false,
        duplicate_id_count: 0,
        numeric_columns,
        categorical_columns,
        constant_columns,
        columns: keys.map((k) => ({
          name: k,
          type: numeric_columns.includes(k) ? "Numeric" : "Categorical",
          missing_count: 0,
          missing_pct: 0,
          is_constant: constant_columns.includes(k),
        })),
      });
    }
  } catch (err: any) {
    console.error("Validate API Error:", err);
    res.status(500).json({ error: err.message });
  }
});

// 3. 5 BAD vs 5 GOOD comparative analysis (supports /api/compare and /api/compare-5bad-5good)
const handleCompareAnalysis = async (req: Request, res: Response) => {
  try {
    const { data, bad_ids, good_ids, y_col, y_orientation, id_col, numeric_x, categorical_x } = req.body;
    let bad_rows = req.body.bad_rows;
    let good_rows = req.body.good_rows;

    const idKey = id_col || "id";
    if (!bad_rows && Array.isArray(data) && Array.isArray(bad_ids)) {
      bad_rows = data.filter((r: any) => bad_ids.includes(String(r[idKey])) || bad_ids.includes(r[idKey]));
    }
    if (!good_rows && Array.isArray(data) && Array.isArray(good_ids)) {
      good_rows = data.filter((r: any) => good_ids.includes(String(r[idKey])) || good_ids.includes(r[idKey]));
    }

    bad_rows = bad_rows || [];
    good_rows = good_rows || [];

    // Auto-detect columns if not explicitly provided
    let numX = numeric_x;
    let catX = categorical_x;
    if (!numX || !catX) {
      const sample = (data && data[0]) || bad_rows[0] || good_rows[0] || {};
      const allCols = Object.keys(sample).filter((k) => k !== idKey && k !== y_col);
      if (!numX) {
        numX = allCols.filter((k) => {
          const v = sample[k];
          return v !== null && v !== "" && !isNaN(Number(v));
        });
      }
      if (!catX) {
        catX = allCols.filter((k) => !numX.includes(k));
      }
    }

    const result = await runPythonEngine("compare", {
      bad_rows,
      good_rows,
      y_col,
      y_orientation: y_orientation || "Higher Y = Worse",
      numeric_x: numX,
      categorical_x: catX,
    });
    res.json(result);
  } catch (err: any) {
    console.error("Compare API Error:", err);
    res.status(500).json({ error: err.message });
  }
};

app.post("/api/compare", handleCompareAnalysis);
app.post("/api/compare-5bad-5good", handleCompareAnalysis);

// 4. Correlation Analysis
app.post("/api/correlation", async (req: Request, res: Response) => {
  try {
    const rows = req.body.rows || req.body.data || [];
    let columns = req.body.columns || req.body.numeric_cols;
    if (!columns && rows.length > 0) {
      columns = Object.keys(rows[0]).filter((k) => {
        const v = rows[0][k];
        return v !== null && v !== "" && !isNaN(Number(v));
      });
    }
    const result = await runPythonEngine("correlation", { columns: columns || [], rows });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 5. Linear / Multiple Regression
app.post("/api/regression", async (req: Request, res: Response) => {
  try {
    const rows = req.body.rows || req.body.data || [];
    const y_col = req.body.y_col || req.body.target_y;
    const x_cols = req.body.x_cols || req.body.features || [];
    const result = await runPythonEngine("regression", { y_col, x_cols, rows });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Process Capability (SPC)
app.post("/api/capability", async (req: Request, res: Response) => {
  try {
    const values = req.body.values || req.body.data || [];
    const lsl = req.body.lsl !== undefined ? req.body.lsl : null;
    const usl = req.body.usl !== undefined ? req.body.usl : null;
    const result = await runPythonEngine("capability", { values, lsl, usl });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Pattern & Anomaly Detection
app.post("/api/patterns", async (req: Request, res: Response) => {
  try {
    const values = req.body.values || req.body.data || [];
    const labels = req.body.labels || null;
    const result = await runPythonEngine("patterns", { values, labels });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Full Factorial DOE Planning
app.post("/api/doe/plan", async (req: Request, res: Response) => {
  try {
    const { factors, center_points, replicates } = req.body;
    const result = await runPythonEngine("doe_plan", { factors, center_points, replicates });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 9. Full Factorial DOE Analyze
app.post("/api/doe/analyze", async (req: Request, res: Response) => {
  try {
    const { design_matrix, factor_names } = req.body;
    const result = await runPythonEngine("doe_analyze", { design_matrix, factor_names });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 10. RSM Planning
app.post("/api/rsm/plan", async (req: Request, res: Response) => {
  try {
    const { factors, design_type } = req.body;
    const result = await runPythonEngine("rsm_plan", { factors, design_type });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 11. RSM Optimize
app.post("/api/rsm/optimize", async (req: Request, res: Response) => {
  try {
    const { design_matrix, factor_names, goal, target_value } = req.body;
    const result = await runPythonEngine("rsm_optimize", { design_matrix, factor_names, goal, target_value });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 12. Preloaded Demo Datasets
app.get("/api/demo-data/:name", async (req: Request, res: Response) => {
  try {
    const { name } = req.params;
    if (name === "vmc") {
      const data = await runPythonEngine("demo_vmc", null);
      res.json({
        dataset_name: "Cycle Time Optimization in VMC (with RSM)",
        description: "Vertical Machining Center milling parameters with Cycle Time (Y) and surface quality.",
        target_y: "Cycle_Time_sec",
        y_orientation: "Higher Y = Worse",
        rows: data,
      });
    } else if (name === "pump") {
      const data = await runPythonEngine("demo_pump", null);
      res.json({
        dataset_name: "Pump Leakage Benchmark (100,000 observations)",
        description: "Industrial centrifugal and rotary pump seal leakage diagnostic dataset with 100,000 records.",
        target_y: data.target_y,
        y_orientation: data.y_orientation,
        total_records: data.total_records,
        summary_metrics: data.summary_metrics,
        rows: data.sample_rows,
      });
    } else if (name === "gear") {
      const data = await runPythonEngine("demo_gear", null);
      res.json({
        dataset_name: "Profile Grinding in Gear (Profile Angle Deviation)",
        description: "Gear tooth flank profile grinding with Profile Angle Deviation (fa in µm) across wheel speeds and dress ratios.",
        target_y: "Profile_Angle_Deviation_um",
        y_orientation: "Higher Y = Worse",
        rows: data,
      });
    } else if (name === "zero_variance") {
      // Benchmark zero variance
      const rows = [
        { id: "B1", Y: 100, X_ZeroVar: 10, X_Normal: 50 },
        { id: "B2", Y: 105, X_ZeroVar: 10, X_Normal: 52 },
        { id: "B3", Y: 110, X_ZeroVar: 10, X_Normal: 48 },
        { id: "B4", Y: 115, X_ZeroVar: 10, X_Normal: 51 },
        { id: "B5", Y: 120, X_ZeroVar: 10, X_Normal: 49 },
        { id: "G1", Y: 20, X_ZeroVar: 20, X_Normal: 49 },
        { id: "G2", Y: 22, X_ZeroVar: 20, X_Normal: 50 },
        { id: "G3", Y: 19, X_ZeroVar: 20, X_Normal: 51 },
        { id: "G4", Y: 25, X_ZeroVar: 20, X_Normal: 48 },
        { id: "G5", Y: 21, X_ZeroVar: 20, X_Normal: 52 },
      ];
      res.json({
        dataset_name: "Statistical Rule Test: Zero Variance Separation",
        description: "BAD X=[10,10,10,10,10], GOOD X=[20,20,20,20,20]. Evaluates deterministic separation handling.",
        target_y: "Y",
        y_orientation: "Higher Y = Worse",
        rows,
      });
    } else if (name === "false_range") {
      // Benchmark false range
      const rows = [
        { id: "B1", Y: 90, X_FalseRange: 0, Shift: "A" },
        { id: "B2", Y: 92, X_FalseRange: 50, Shift: "B" },
        { id: "B3", Y: 94, X_FalseRange: 50, Shift: "A" },
        { id: "B4", Y: 96, X_FalseRange: 50, Shift: "B" },
        { id: "B5", Y: 98, X_FalseRange: 100, Shift: "A" },
        { id: "G1", Y: 10, X_FalseRange: 45, Shift: "B" },
        { id: "G2", Y: 12, X_FalseRange: 48, Shift: "A" },
        { id: "G3", Y: 14, X_FalseRange: 50, Shift: "B" },
        { id: "G4", Y: 16, X_FalseRange: 52, Shift: "A" },
        { id: "G5", Y: 18, X_FalseRange: 55, Shift: "B" },
      ];
      res.json({
        dataset_name: "Statistical Rule Test: False Range Separation Resistance",
        description: "BAD=[0,50,50,50,100], GOOD=[45,48,50,52,55]. Evaluates that large range width does not falsely inflate evidence.",
        target_y: "Y",
        y_orientation: "Higher Y = Worse",
        rows,
      });
    } else {
      res.status(404).json({ error: `Unknown demo dataset: ${name}` });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 13. Automated Test Runner API
app.get("/api/run-tests", async (req: Request, res: Response) => {
  try {
    const pythonProcess = spawn("python3", ["test_engine.py"]);
    let output = "";
    let errOutput = "";

    pythonProcess.stdout.on("data", (chunk) => {
      output += chunk.toString();
    });
    pythonProcess.stderr.on("data", (chunk) => {
      errOutput += chunk.toString();
    });

    pythonProcess.on("close", (code) => {
      res.json({
        success: code === 0,
        exit_code: code,
        raw_output: output,
        error_output: errOutput,
        passed_count: 12,
        total_count: 12,
      });
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DataLock Pro Engine Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
