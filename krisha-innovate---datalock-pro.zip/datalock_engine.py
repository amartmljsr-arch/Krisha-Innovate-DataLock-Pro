#!/usr/bin/env python3
"""
Krisha Innovate - DataLock Pro
Manufacturing Problem Diagnostic & Prediction Engine - Python Analytical Engine
"""

import sys
import json
import math
import random
import itertools
from typing import List, Dict, Any, Tuple, Optional, Union

# --- Matrix / Linear Algebra in Pure Python for OLS & RSM ---

def matrix_transpose(A: List[List[float]]) -> List[List[float]]:
    if not A or not A[0]:
        return []
    return [[A[i][j] for i in range(len(A))] for j in range(len(A[0]))]

def matrix_multiply(A: List[List[float]], B: List[List[float]]) -> List[List[float]]:
    rows_A, cols_A = len(A), len(A[0])
    rows_B, cols_B = len(B), len(B[0])
    if cols_A != rows_B:
        raise ValueError("Cannot multiply matrices: inner dimensions do not match.")
    result = [[0.0 for _ in range(cols_B)] for _ in range(rows_A)]
    for i in range(rows_A):
        for k in range(cols_A):
            aik = A[i][k]
            for j in range(cols_B):
                result[i][j] += aik * B[k][j]
    return result

def matrix_vector_multiply(A: List[List[float]], v: List[float]) -> List[float]:
    return [sum(A[i][j] * v[j] for j in range(len(v))) for i in range(len(A))]

def matrix_inverse(A: List[List[float]]) -> List[List[float]]:
    """Gauss-Jordan elimination with partial pivoting."""
    n = len(A)
    # Augment with identity
    aug = [row[:] + [1.0 if i == j else 0.0 for j in range(n)] for i, row in enumerate(A)]
    
    for i in range(n):
        # Pivot search
        max_row = i
        max_val = abs(aug[i][i])
        for r in range(i + 1, n):
            if abs(aug[r][i]) > max_val:
                max_val = abs(aug[r][i])
                max_row = r
        if max_val < 1e-12:
            raise ValueError("Singular matrix; cannot invert.")
        aug[i], aug[max_row] = aug[max_row], aug[i]
        
        pivot = aug[i][i]
        for c in range(2 * n):
            aug[i][c] /= pivot
            
        for r in range(n):
            if r != i:
                factor = aug[r][i]
                for c in range(2 * n):
                    aug[r][c] -= factor * aug[i][c]
                    
    inv = [[aug[i][j + n] for j in range(n)] for i in range(n)]
    return inv

# --- Statistical Core Calculations ---

def mean(data: List[float]) -> float:
    return sum(data) / len(data) if data else 0.0

def variance(data: List[float], ddof: int = 1) -> float:
    n = len(data)
    if n <= ddof:
        return 0.0
    m = mean(data)
    return sum((x - m) ** 2 for x in data) / (n - ddof)

def stdev(data: List[float], ddof: int = 1) -> float:
    return math.sqrt(max(0.0, variance(data, ddof)))

def median(data: List[float]) -> float:
    if not data:
        return 0.0
    s = sorted(data)
    n = len(s)
    mid = n // 2
    if n % 2 == 1:
        return float(s[mid])
    return (s[mid - 1] + s[mid]) / 2.0

def quantiles(data: List[float], n: int = 4) -> List[float]:
    if not data:
        return []
    s = sorted(data)
    sz = len(s)
    result = []
    for i in range(1, n):
        idx = (sz - 1) * (i / n)
        low = int(math.floor(idx))
        high = int(math.ceil(idx))
        weight = idx - low
        val = s[low] * (1.0 - weight) + s[high] * weight
        result.append(val)
    return result

# --- Probability Distributions ---

def normal_cdf(x: float, mu: float = 0.0, sigma: float = 1.0) -> float:
    if sigma <= 0.0:
        return 1.0 if x >= mu else 0.0
    return 0.5 * (1.0 + math.erf((x - mu) / (sigma * math.sqrt(2.0))))

def normal_ppf(p: float, mu: float = 0.0, sigma: float = 1.0) -> float:
    """Acklam's inverse normal CDF algorithm."""
    if p <= 0.0:
        return -float('inf')
    if p >= 1.0:
        return float('inf')
    
    a = [-3.969683028665376e+01,  2.209460984245205e+02, -2.759285104469687e+02,
          1.383577518672690e+02, -3.066479806614716e+01,  2.506628277459239e+00]
    b = [-5.447609879822406e+01,  1.615858368580409e+02, -1.556989798598866e+02,
          6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00,  4.374664141464968e+00,  2.938163982698783e+00]
    d = [ 7.784695709041462e-03,  3.224671290700398e-01,  2.445134137142996e+00,
          3.754408661907416e+00]

    p_low = 0.02425
    p_high = 1.0 - p_low

    if p < p_low:
        q = math.sqrt(-2.0 * math.log(p))
        z = (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) / \
            ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1.0)
    elif p <= p_high:
        q = p - 0.5
        r = q * q
        z = (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5])*q / \
            (((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1.0)
    else:
        q = math.sqrt(-2.0 * math.log(1.0 - p))
        z = -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) / \
             ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1.0)

    return mu + sigma * z

def betacf(a: float, b: float, x: float) -> float:
    MAXIT = 100
    EPS = 3.0e-12
    FPMIN = 1.0e-30
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < FPMIN: d = FPMIN
    d = 1.0 / d
    h = d
    for m in range(1, MAXIT + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN: d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN: c = FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN: d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN: c = FPMIN
        d = 1.0 / d
        del_val = d * c
        h *= del_val
        if abs(del_val - 1.0) < EPS:
            break
    return h

def betai(a: float, b: float, x: float) -> float:
    if x <= 0.0: return 0.0
    if x >= 1.0: return 1.0
    bt = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1.0 - x))
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * betacf(a, b, x) / a
    else:
        return 1.0 - bt * betacf(b, a, 1.0 - x) / b

def t_distribution_cdf(t: float, df: float) -> float:
    if df <= 0: return 0.5
    x = df / (df + t * t)
    prob = 0.5 * betai(0.5 * df, 0.5, x)
    return 1.0 - prob if t >= 0 else prob

def t_two_tailed_p_value(t: float, df: float) -> float:
    if math.isnan(t) or math.isnan(df) or df <= 0:
        return 1.0
    p = 2.0 * (1.0 - t_distribution_cdf(abs(t), df))
    return max(0.0, min(1.0, p))

def gamma_inc_lower(a: float, x: float) -> float:
    if x <= 0.0: return 0.0
    if x < a + 1.0:
        ap = a
        sum_val = 1.0 / a
        del_val = sum_val
        for _ in range(100):
            ap += 1.0
            del_val *= x / ap
            sum_val += del_val
            if abs(del_val) < abs(sum_val) * 3e-12: break
        return sum_val * math.exp(-x + a * math.log(x) - math.lgamma(a))
    else:
        b = x + 1.0 - a
        c = 1.0 / 1e-30
        d = 1.0 / b
        h = d
        for i in range(1, 101):
            an = -i * (i - a)
            b += 2.0
            d = an * d + b
            if abs(d) < 1e-30: d = 1e-30
            c = b + an / c
            if abs(c) < 1e-30: c = 1e-30
            d = 1.0 / d
            del_val = d * c
            h *= del_val
            if abs(del_val - 1.0) < 3e-12: break
        return 1.0 - math.exp(-x + a * math.log(x) - math.lgamma(a)) * h

def chi2_cdf(x: float, df: float) -> float:
    if x <= 0 or df <= 0: return 0.0
    return gamma_inc_lower(df / 2.0, x / 2.0)

def chi2_p_value(x: float, df: float) -> float:
    if x <= 0 or df <= 0: return 1.0
    return max(0.0, min(1.0, 1.0 - chi2_cdf(x, df)))

def f_cdf(f: float, df1: float, df2: float) -> float:
    if f <= 0 or df1 <= 0 or df2 <= 0: return 0.0
    x = (df1 * f) / (df1 * f + df2)
    return betai(df1 / 2.0, df2 / 2.0, x)

def f_p_value(f: float, df1: float, df2: float) -> float:
    if f <= 0 or df1 <= 0 or df2 <= 0: return 1.0
    return max(0.0, min(1.0, 1.0 - f_cdf(f, df1, df2)))

# --- Mann-Whitney U and Exact Permutations ---

def compute_ranks(combined: List[Tuple[float, str]]) -> List[Tuple[float, float, str]]:
    sorted_items = sorted(combined, key=lambda x: x[0])
    n = len(sorted_items)
    ranked = []
    i = 0
    while i < n:
        j = i
        while j < n - 1 and math.isclose(sorted_items[j][0], sorted_items[j + 1][0], rel_tol=1e-11, abs_tol=1e-11):
            j += 1
        avg_rank = sum(k + 1 for k in range(i, j + 1)) / (j - i + 1)
        for k in range(i, j + 1):
            ranked.append((sorted_items[k][0], avg_rank, sorted_items[k][1]))
        i = j + 1
    return ranked

def get_tie_groups(values: List[float]) -> List[int]:
    s = sorted(values)
    ties = []
    i = 0
    n = len(s)
    while i < n:
        j = i
        while j < n - 1 and math.isclose(s[j], s[j + 1], rel_tol=1e-11, abs_tol=1e-11):
            j += 1
        count = j - i + 1
        if count > 1:
            ties.append(count)
        i = j + 1
    return ties

def mann_whitney_u_test(bad_vals: List[float], good_vals: List[float]) -> Dict[str, Any]:
    n1 = len(bad_vals)
    n2 = len(good_vals)
    if n1 == 0 or n2 == 0:
        return {"error": "Insufficient data"}

    combined = [(x, 'BAD') for x in bad_vals] + [(y, 'GOOD') for y in good_vals]
    all_vals = [x for x, _ in combined]
    ranked = compute_ranks(combined)

    r1 = sum(r for _, r, g in ranked if g == 'BAD')
    r2 = sum(r for _, r, g in ranked if g == 'GOOD')

    u1 = r1 - (n1 * (n1 + 1)) / 2.0
    u2 = r2 - (n2 * (n2 + 1)) / 2.0
    u_min = min(u1, u2)

    tie_groups = get_tie_groups(all_vals)
    has_ties = len(tie_groups) > 0

    N = n1 + n2
    is_small_sample = (N <= 14)
    exact_p = None
    calc_type = "Exact Permutation"

    if is_small_sample:
        all_ranks = [r for _, r, _ in ranked]
        all_combos = list(itertools.combinations(all_ranks, n1))
        total_combos = len(all_combos)
        
        expected_r1 = n1 * (N + 1) / 2.0
        obs_dev = abs(r1 - expected_r1)
        
        count_extreme = 0
        for combo in all_combos:
            combo_r1 = sum(combo)
            if abs(combo_r1 - expected_r1) >= obs_dev - 1e-9:
                count_extreme += 1
        
        exact_p = count_extreme / total_combos
        if has_ties:
            calc_type = "Exact Permutation with Tied Ranks"
        else:
            calc_type = "Exact Permutation (No Ties)"

    mean_u = (n1 * n2) / 2.0
    tie_correction = sum((t**3 - t) for t in tie_groups) / (N * (N - 1)) if N > 1 else 0.0
    var_u = (n1 * n2 / 12.0) * ((N + 1) - tie_correction)
    std_u = math.sqrt(max(1e-12, var_u))

    diff = abs(u_min - mean_u)
    z = (diff - 0.5) / std_u if diff > 0.5 else 0.0
    asymptotic_p = 2.0 * (1.0 - normal_cdf(z))

    final_p = exact_p if exact_p is not None else asymptotic_p

    auc_sum = 0.0
    for b in bad_vals:
        for g in good_vals:
            if math.isclose(b, g, rel_tol=1e-11, abs_tol=1e-11):
                auc_sum += 0.5
            elif b > g:
                auc_sum += 1.0
            else:
                auc_sum += 0.0
    auc = auc_sum / (n1 * n2)

    return {
        "n_bad": n1,
        "n_good": n2,
        "U_bad": u1,
        "U_good": u2,
        "U_min": u_min,
        "rank_sum_bad": r1,
        "rank_sum_good": r2,
        "has_ties": has_ties,
        "tie_groups": tie_groups,
        "calculation_type": calc_type,
        "exact_p_value": exact_p,
        "asymptotic_p_value": asymptotic_p,
        "p_value": final_p,
        "auc": auc
    }

# --- Welch t-test ---

def welch_t_test(bad_vals: List[float], good_vals: List[float]) -> Dict[str, Any]:
    n1 = len(bad_vals)
    n2 = len(good_vals)
    if n1 <= 1 or n2 <= 1:
        return {"error": "Insufficient sample size"}

    m1 = mean(bad_vals)
    m2 = mean(good_vals)
    v1 = variance(bad_vals, ddof=1)
    v2 = variance(good_vals, ddof=1)
    s1 = math.sqrt(v1)
    s2 = math.sqrt(v2)
    mean_diff = m1 - m2

    if v1 == 0.0 and v2 == 0.0:
        if math.isclose(m1, m2, rel_tol=1e-11, abs_tol=1e-11):
            return {
                "t_stat": 0.0,
                "df": float(n1 + n2 - 2),
                "p_value": 1.0,
                "mean_bad": m1,
                "mean_good": m2,
                "sd_bad": 0.0,
                "sd_good": 0.0,
                "mean_diff": 0.0,
                "note": "Identical constant values in both groups; zero within-group variance."
            }
        else:
            return {
                "t_stat": None,
                "df": None,
                "p_value": None,
                "mean_bad": m1,
                "mean_good": m2,
                "sd_bad": 0.0,
                "sd_good": 0.0,
                "mean_diff": mean_diff,
                "note": "Complete deterministic separation; zero within-group variance."
            }

    if v1 == 0.0:
        se = math.sqrt(v2 / n2)
        df = float(n2 - 1)
        t_stat = mean_diff / se if se > 0 else 0.0
        return {
            "t_stat": t_stat,
            "df": df,
            "p_value": t_two_tailed_p_value(t_stat, df),
            "mean_bad": m1,
            "mean_good": m2,
            "sd_bad": 0.0,
            "sd_good": s2,
            "mean_diff": mean_diff,
            "note": "BAD group has zero variance."
        }

    if v2 == 0.0:
        se = math.sqrt(v1 / n1)
        df = float(n1 - 1)
        t_stat = mean_diff / se if se > 0 else 0.0
        return {
            "t_stat": t_stat,
            "df": df,
            "p_value": t_two_tailed_p_value(t_stat, df),
            "mean_bad": m1,
            "mean_good": m2,
            "sd_bad": s1,
            "sd_good": 0.0,
            "mean_diff": mean_diff,
            "note": "GOOD group has zero variance."
        }

    vn1 = v1 / n1
    vn2 = v2 / n2
    se = math.sqrt(vn1 + vn2)
    t_stat = mean_diff / se if se > 0 else 0.0
    df_num = (vn1 + vn2) ** 2
    df_den = (vn1 ** 2) / (n1 - 1) + (vn2 ** 2) / (n2 - 1)
    df = df_num / df_den if df_den > 0 else float(n1 + n2 - 2)

    return {
        "t_stat": t_stat,
        "df": df,
        "p_value": t_two_tailed_p_value(t_stat, df),
        "mean_bad": m1,
        "mean_good": m2,
        "sd_bad": s1,
        "sd_good": s2,
        "mean_diff": mean_diff,
        "note": "Standard Welch t-test (unequal variances)."
    }

# --- Effect Sizes ---

def compute_effect_sizes(bad_vals: List[float], good_vals: List[float]) -> Dict[str, Any]:
    n1 = len(bad_vals)
    n2 = len(good_vals)
    m1 = mean(bad_vals)
    m2 = mean(good_vals)
    v1 = variance(bad_vals, ddof=1)
    v2 = variance(good_vals, ddof=1)
    mean_diff = m1 - m2

    if v1 == 0.0 and v2 == 0.0:
        if math.isclose(m1, m2, rel_tol=1e-11, abs_tol=1e-11):
            return {"cohens_d": 0.0, "hedges_g": 0.0, "pooled_sd": 0.0, "note": "Zero variance, identical means."}
        else:
            return {"cohens_d": None, "hedges_g": None, "pooled_sd": 0.0, "note": "Complete deterministic separation; pooled SD is 0."}

    df = n1 + n2 - 2
    if df <= 0:
        return {"cohens_d": 0.0, "hedges_g": 0.0, "pooled_sd": 0.0}

    s_pooled_sq = ((n1 - 1) * v1 + (n2 - 1) * v2) / df
    s_pooled = math.sqrt(max(0.0, s_pooled_sq))
    if s_pooled <= 0.0:
        return {"cohens_d": 0.0, "hedges_g": 0.0, "pooled_sd": 0.0}

    cohens_d = mean_diff / s_pooled
    j_factor = 1.0 - (3.0 / (4.0 * df - 1.0)) if (4.0 * df - 1.0) > 0 else 1.0
    hedges_g = cohens_d * j_factor

    return {
        "cohens_d": cohens_d,
        "hedges_g": hedges_g,
        "pooled_sd": s_pooled,
        "correction_factor": j_factor
    }

# --- Categorical Association ---

def categorical_association_test(bad_vals: List[Any], good_vals: List[Any]) -> Dict[str, Any]:
    all_cats = sorted(list(set([str(x) for x in bad_vals + good_vals])))
    bad_counts = {c: 0 for c in all_cats}
    good_counts = {c: 0 for c in all_cats}
    
    for x in bad_vals:
        bad_counts[str(x)] += 1
    for x in good_vals:
        good_counts[str(x)] += 1
        
    n_bad = len(bad_vals)
    n_good = len(good_vals)
    total_n = n_bad + n_good
    
    chi2_stat = 0.0
    for c in all_cats:
        c_tot = bad_counts[c] + good_counts[c]
        exp_bad = (c_tot * n_bad) / total_n if total_n > 0 else 0
        exp_good = (c_tot * n_good) / total_n if total_n > 0 else 0
        if exp_bad > 0:
            chi2_stat += ((bad_counts[c] - exp_bad) ** 2) / exp_bad
        if exp_good > 0:
            chi2_stat += ((good_counts[c] - exp_good) ** 2) / exp_good
            
    df = max(1, len(all_cats) - 1)
    p_val = chi2_p_value(chi2_stat, float(df))
    
    # Cramér's V
    k = len(all_cats)
    min_dim = min(2 - 1, k - 1)
    cramers_v = math.sqrt(chi2_stat / (total_n * min_dim)) if min_dim > 0 and total_n > 0 else 0.0
    
    # Distribution table
    dist_table = []
    for c in all_cats:
        dist_table.append({
            "category": c,
            "bad_count": bad_counts[c],
            "bad_pct": (bad_counts[c] / n_bad * 100) if n_bad > 0 else 0,
            "good_count": good_counts[c],
            "good_pct": (good_counts[c] / n_good * 100) if n_good > 0 else 0
        })

    return {
        "chi2_stat": chi2_stat,
        "df": df,
        "p_value": p_val,
        "cramers_v": min(1.0, cramers_v),
        "categories": all_cats,
        "distribution": dist_table
    }

# --- Correlation Engine ---

def pearson_correlation(x: List[float], y: List[float]) -> Dict[str, Any]:
    n = len(x)
    if n < 3:
        return {"r": 0.0, "p_value": 1.0, "df": 0}
    mx, my = mean(x), mean(y)
    vx, vy = variance(x), variance(y)
    if vx == 0 or vy == 0:
        return {"r": 0.0, "p_value": 1.0, "df": n - 2, "note": "Zero variance in one or both series."}
    
    cov = sum((x[i] - mx) * (y[i] - my) for i in range(n)) / (n - 1)
    r = cov / (math.sqrt(vx) * math.sqrt(vy))
    r = max(-1.0, min(1.0, r))
    
    df = n - 2
    if abs(r) >= 1.0:
        p_val = 0.0
        t_stat = float('inf') if r > 0 else -float('inf')
    else:
        t_stat = r * math.sqrt(df / max(1e-12, 1.0 - r * r))
        p_val = t_two_tailed_p_value(t_stat, float(df))
        
    return {
        "r": r,
        "r_squared": r * r,
        "t_stat": t_stat,
        "df": df,
        "p_value": p_val
    }

def spearman_correlation(x: List[float], y: List[float]) -> Dict[str, Any]:
    n = len(x)
    if n < 3:
        return {"rho": 0.0, "p_value": 1.0}
    # Rank both arrays
    indexed_x = [(val, i) for i, val in enumerate(x)]
    indexed_y = [(val, i) for i, val in enumerate(y)]
    
    def get_ranked_array(indexed_list):
        s = sorted(indexed_list, key=lambda item: item[0])
        ranks = [0.0] * len(s)
        i = 0
        sz = len(s)
        while i < sz:
            j = i
            while j < sz - 1 and math.isclose(s[j][0], s[j+1][0], rel_tol=1e-11, abs_tol=1e-11):
                j += 1
            avg_r = sum(k + 1 for k in range(i, j + 1)) / (j - i + 1)
            for k in range(i, j + 1):
                orig_idx = s[k][1]
                ranks[orig_idx] = avg_r
            i = j + 1
        return ranks

    rank_x = get_ranked_array(indexed_x)
    rank_y = get_ranked_array(indexed_y)
    
    p_res = pearson_correlation(rank_x, rank_y)
    return {
        "rho": p_res["r"],
        "p_value": p_res["p_value"],
        "t_stat": p_res.get("t_stat"),
        "df": p_res.get("df")
    }

# --- Linear & Multiple Regression ---

def linear_regression_fit(X: List[List[float]], y: List[float], feature_names: List[str]) -> Dict[str, Any]:
    """
    Fits OLS regression y = X * beta.
    X should include a leading column of 1.0 for the intercept.
    """
    n = len(y)
    p = len(X[0]) # number of parameters including intercept
    df_resid = n - p
    if df_resid <= 0:
        return {"error": "Degrees of freedom <= 0; too many features for sample size."}

    # XT * X
    Xt = matrix_transpose(X)
    XtX = matrix_multiply(Xt, X)
    try:
        XtX_inv = matrix_inverse(XtX)
    except ValueError:
        return {"error": "Matrix (X^T * X) is singular / multicollinear. Check for redundant variables."}

    # beta = (XtX)^(-1) * Xt * y
    Xty = matrix_vector_multiply(Xt, y)
    beta = matrix_vector_multiply(XtX_inv, Xty)

    # Predictions and residuals
    y_pred = [sum(X[i][j] * beta[j] for j in range(p)) for i in range(n)]
    residuals = [y[i] - y_pred[i] for i in range(n)]

    # Sum of squares
    y_bar = mean(y)
    ss_tot = sum((yi - y_bar) ** 2 for yi in y)
    ss_res = sum(r ** 2 for r in residuals)
    ss_reg = max(0.0, ss_tot - ss_res)

    r_squared = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else 1.0
    adj_r_squared = 1.0 - ((1.0 - r_squared) * (n - 1) / df_resid) if df_resid > 0 else r_squared

    # Residual variance and SE
    sigma_sq = ss_res / df_resid if df_resid > 0 else 0.0
    se_beta = [math.sqrt(max(0.0, sigma_sq * XtX_inv[j][j])) for j in range(p)]

    # t-stats and p-values for coefficients
    coef_table = []
    for j in range(p):
        name = feature_names[j] if j < len(feature_names) else f"Beta_{j}"
        b = beta[j]
        se = se_beta[j]
        t = b / se if se > 0 else 0.0
        pval = t_two_tailed_p_value(t, float(df_resid))
        coef_table.append({
            "term": name,
            "coef": b,
            "se": se,
            "t_stat": t,
            "p_value": pval,
            "ci_95_low": b - 1.96 * se,
            "ci_95_high": b + 1.96 * se
        })

    # F-test
    df_reg = p - 1
    if df_reg > 0 and sigma_sq > 0:
        ms_reg = ss_reg / df_reg
        ms_res = ss_res / df_resid
        f_stat = ms_reg / ms_res
        f_pval = f_p_value(f_stat, float(df_reg), float(df_resid))
    else:
        f_stat = 0.0
        f_pval = 1.0

    return {
        "n": n,
        "p": p,
        "df_resid": df_resid,
        "df_reg": df_reg,
        "r_squared": max(0.0, min(1.0, r_squared)),
        "adj_r_squared": max(0.0, min(1.0, adj_r_squared)),
        "f_stat": f_stat,
        "f_p_value": f_pval,
        "rmse": math.sqrt(sigma_sq),
        "ss_total": ss_tot,
        "ss_residual": ss_res,
        "ss_regression": ss_reg,
        "coefficients": coef_table,
        "residuals": residuals[:1000], # return subset if large
        "fitted_values": y_pred[:1000]
    }

# --- Process Capability (Cp, Cpk, Pp, Ppk) ---

def process_capability_analysis(
    data: List[float],
    lsl: Optional[float] = None,
    usl: Optional[float] = None,
    subgroup_size: int = 1
) -> Dict[str, Any]:
    if not data:
        return {"error": "No data provided"}
    if lsl is None and usl is None:
        return {"error": "At least one specification limit (LSL or USL) must be provided."}
    if lsl is not None and usl is not None and lsl >= usl:
        return {"error": "LSL must be strictly less than USL."}

    n = len(data)
    m = mean(data)
    s_overall = stdev(data, ddof=1)

    # Within-subgroup standard deviation estimation (using Moving Range if subgroup=1)
    if subgroup_size == 1 and n >= 2:
        mr_sum = sum(abs(data[i] - data[i - 1]) for i in range(1, n))
        mean_mr = mr_sum / (n - 1)
        d2 = 1.128 # for n=2
        s_within = mean_mr / d2
    else:
        s_within = s_overall

    cp = None
    cpk = None
    cpu = None
    cpl = None
    pp = None
    ppk = None

    # Capability using s_within (Short-term)
    if lsl is not None and usl is not None and s_within > 0:
        cp = (usl - lsl) / (6.0 * s_within)
    if usl is not None and s_within > 0:
        cpu = (usl - m) / (3.0 * s_within)
    if lsl is not None and s_within > 0:
        cpl = (m - lsl) / (3.0 * s_within)

    if cpu is not None and cpl is not None:
        cpk = min(cpu, cpl)
    elif cpu is not None:
        cpk = cpu
    elif cpl is not None:
        cpk = cpl

    # Performance using s_overall (Long-term)
    if lsl is not None and usl is not None and s_overall > 0:
        pp = (usl - lsl) / (6.0 * s_overall)
    ppu = (usl - m) / (3.0 * s_overall) if usl is not None and s_overall > 0 else None
    ppl = (m - lsl) / (3.0 * s_overall) if lsl is not None and s_overall > 0 else None

    if ppu is not None and ppl is not None:
        ppk = min(ppu, ppl)
    elif ppu is not None:
        ppk = ppu
    elif ppl is not None:
        ppk = ppl

    # PPM defective calculation (assuming normal distribution)
    ppm_lower = 0.0
    ppm_upper = 0.0
    if lsl is not None and s_overall > 0:
        z_lower = (lsl - m) / s_overall
        ppm_lower = normal_cdf(z_lower) * 1e6
    if usl is not None and s_overall > 0:
        z_upper = (usl - m) / s_overall
        ppm_upper = (1.0 - normal_cdf(z_upper)) * 1e6
    ppm_total = ppm_lower + ppm_upper

    return {
        "n": n,
        "mean": m,
        "median": median(data),
        "stdev_overall": s_overall,
        "stdev_within": s_within,
        "lsl": lsl,
        "usl": usl,
        "cp": cp,
        "cpk": cpk,
        "cpu": cpu,
        "cpl": cpl,
        "pp": pp,
        "ppk": ppk,
        "ppm_total": ppm_total,
        "ppm_lower": ppm_lower,
        "ppm_upper": ppm_upper,
        "status": "Capable (Cpk >= 1.33)" if (cpk and cpk >= 1.33) else "Not Capable (Cpk < 1.33)"
    }

# --- Transparent Anomaly & Pattern Detection ---

def detect_anomalies_and_patterns(data: List[float], labels: Optional[List[Any]] = None) -> Dict[str, Any]:
    n = len(data)
    if n == 0:
        return {"error": "Empty dataset"}
    
    m = mean(data)
    s = stdev(data)
    med = median(data)
    q = quantiles(data, 4)
    q1, q3 = q[0], q[2]
    iqr = q3 - q1

    # 1. Tukey's Fences (1.5x IQR mild, 3.0x IQR extreme)
    lower_mild = q1 - 1.5 * iqr
    upper_mild = q3 + 1.5 * iqr
    lower_extreme = q1 - 3.0 * iqr
    upper_extreme = q3 + 3.0 * iqr

    # 2. Modified Z-Score (using Median Absolute Deviation - MAD)
    abs_devs = [abs(x - med) for x in data]
    mad = median(abs_devs)
    
    anomalies = []
    for i, x in enumerate(data):
        label = str(labels[i]) if labels and i < len(labels) else f"Row_{i+1}"
        is_iqr_mild = (x < lower_mild or x > upper_mild)
        is_iqr_extreme = (x < lower_extreme or x > upper_extreme)
        
        mod_z = (0.6745 * abs(x - med) / mad) if mad > 0 else 0.0
        z_score = (x - m) / s if s > 0 else 0.0

        if is_iqr_mild or mod_z >= 3.5:
            anomalies.append({
                "index": i,
                "label": label,
                "value": x,
                "z_score": z_score,
                "modified_z": mod_z,
                "type": "Extreme Outlier (3x IQR)" if is_iqr_extreme else ("Modified Z Anomaly" if mod_z >= 3.5 else "Mild Outlier (1.5x IQR)"),
                "note": "Candidate anomaly; does NOT prove special cause without engineering audit."
            })

    # 3. Western Electric / Run Rules Pattern Detection
    patterns_detected = []

    # Shift: 8 consecutive points on one side of center line (median)
    consec_above = 0
    consec_below = 0
    shift_indices = []
    for i, x in enumerate(data):
        if x > med:
            consec_above += 1
            consec_below = 0
        elif x < med:
            consec_below += 1
            consec_above = 0
        else:
            consec_above = 0
            consec_below = 0
        if consec_above >= 8 or consec_below >= 8:
            shift_indices.append(i)

    if shift_indices:
        patterns_detected.append({
            "pattern": "Process Level Shift",
            "description": f"Detected {len(shift_indices)} points following >= 8 consecutive observations on one side of the median.",
            "rule": "Western Electric Rule 2 (Shift)",
            "indices": shift_indices[:20]
        })

    # Trend: 6 consecutive increasing or decreasing points
    trend_inc = 0
    trend_dec = 0
    trend_indices = []
    for i in range(1, n):
        if data[i] > data[i - 1]:
            trend_inc += 1
            trend_dec = 0
        elif data[i] < data[i - 1]:
            trend_dec += 1
            trend_inc = 0
        else:
            trend_inc = 0
            trend_dec = 0
        if trend_inc >= 5 or trend_dec >= 5:
            trend_indices.append(i)

    if trend_indices:
        patterns_detected.append({
            "pattern": "Systematic Trend",
            "description": f"Detected {len(trend_indices)} points participating in >= 6 consecutive continuously increasing or decreasing steps.",
            "rule": "Western Electric Rule 3 (Trend / Tool Wear)",
            "indices": trend_indices[:20]
        })

    return {
        "n": n,
        "mean": m,
        "median": med,
        "iqr": iqr,
        "q1": q1,
        "q3": q3,
        "lower_fence_1_5": lower_mild,
        "upper_fence_1_5": upper_mild,
        "anomaly_count": len(anomalies),
        "anomalies": anomalies[:50], # first 50
        "patterns": patterns_detected
    }

# --- Full Factorial Design of Experiments (DOE) ---

def generate_full_factorial_doe(factors: List[Dict[str, Any]], center_points: int = 3, replicates: int = 1) -> Dict[str, Any]:
    """
    Generates 2^k full factorial design matrix.
    factors: [{"name": "Speed", "low": 1000, "high": 2000, "unit": "RPM"}, ...]
    """
    k = len(factors)
    if k < 2 or k > 6:
        return {"error": "Full factorial supports 2 to 6 factors."}

    # Factorial points (-1, +1)
    levels = [-1.0, 1.0]
    coded_runs = list(itertools.product(levels, repeat=k))
    
    design_matrix = []
    run_order = 1

    for rep in range(replicates):
        for run_idx, coded in enumerate(coded_runs):
            uncoded_vals = {}
            for fi, f in enumerate(factors):
                low = float(f["low"])
                high = float(f["high"])
                mid = (low + high) / 2.0
                half_range = (high - low) / 2.0
                actual_val = mid + coded[fi] * half_range
                uncoded_vals[f["name"]] = actual_val
                
            design_matrix.append({
                "std_order": run_idx + 1 + rep * len(coded_runs),
                "replicate": rep + 1,
                "type": "Factorial",
                "coded": {factors[fi]["name"]: coded[fi] for fi in range(k)},
                "actual": uncoded_vals,
                "response_y": None
            })

    # Center points (0, 0, ...)
    for cp in range(center_points):
        uncoded_vals = {}
        for fi, f in enumerate(factors):
            uncoded_vals[f["name"]] = (float(f["low"]) + float(f["high"])) / 2.0
        design_matrix.append({
            "std_order": len(design_matrix) + 1,
            "replicate": 1,
            "type": "Center",
            "coded": {factors[fi]["name"]: 0.0 for fi in range(k)},
            "actual": uncoded_vals,
            "response_y": None
        })

    # Generate randomized run order
    randomized_order = list(range(len(design_matrix)))
    random.seed(42)
    random.shuffle(randomized_order)
    for i, idx in enumerate(randomized_order):
        design_matrix[idx]["run_order"] = i + 1

    design_matrix.sort(key=lambda x: x["run_order"])

    return {
        "num_factors": k,
        "factors": factors,
        "total_runs": len(design_matrix),
        "factorial_runs": 2**k * replicates,
        "center_points": center_points,
        "design_matrix": design_matrix
    }

def analyze_full_factorial_doe(design_matrix: List[Dict[str, Any]], factor_names: List[str]) -> Dict[str, Any]:
    """
    Fits full factorial model with main effects and 2-way interactions.
    """
    y_vals = [d.get("response_y") for d in design_matrix]
    if any(y is None for y in y_vals):
        return {"error": "All response Y values must be recorded before running DOE analysis."}

    k = len(factor_names)
    n = len(design_matrix)

    # Build model matrix with Intercept, Main Effects, 2-Factor Interactions
    feature_terms = ["Intercept"] + factor_names
    # 2-factor interactions
    interaction_pairs = list(itertools.combinations(factor_names, 2))
    for f1, f2 in interaction_pairs:
        feature_terms.append(f"{f1}*{f2}")

    X_mat = []
    for row in design_matrix:
        coded = row["coded"]
        x_row = [1.0]
        # Main effects
        for fn in factor_names:
            x_row.append(float(coded.get(fn, 0.0)))
        # Interactions
        for f1, f2 in interaction_pairs:
            x_row.append(float(coded.get(f1, 0.0)) * float(coded.get(f2, 0.0)))
        X_mat.append(x_row)

    reg_res = linear_regression_fit(X_mat, [float(y) for y in y_vals], feature_terms)
    if "error" in reg_res:
        return reg_res

    # Main effects table & Pareto chart data
    pareto_data = []
    for coef in reg_res["coefficients"]:
        if coef["term"] != "Intercept":
            effect = 2.0 * coef["coef"] # Factor effect = 2 * beta in 2-level coded (-1, +1)
            pareto_data.append({
                "term": coef["term"],
                "effect": effect,
                "abs_effect": abs(effect),
                "t_stat": abs(coef["t_stat"]),
                "p_value": coef["p_value"],
                "significant": coef["p_value"] <= 0.05
            })

    pareto_data.sort(key=lambda x: x["t_stat"], reverse=True)

    return {
        "model_summary": {
            "r_squared": reg_res["r_squared"],
            "adj_r_squared": reg_res["adj_r_squared"],
            "f_stat": reg_res["f_stat"],
            "f_p_value": reg_res["f_p_value"],
            "rmse": reg_res["rmse"]
        },
        "coefficients": reg_res["coefficients"],
        "pareto_effects": pareto_data,
        "num_runs": n
    }

# --- Response Surface Methodology (RSM) ---

def generate_rsm_design(factors: List[Dict[str, Any]], design_type: str = "CCD") -> Dict[str, Any]:
    """
    Generates Central Composite Design (CCD) or Box-Behnken Design (BBD).
    """
    k = len(factors)
    design_matrix = []

    if design_type.upper() == "BBD" and k in [3, 4, 5]:
        # Box-Behnken combinations
        combos = list(itertools.combinations(range(k), 2))
        for pair in combos:
            for sign1 in [-1.0, 1.0]:
                for sign2 in [-1.0, 1.0]:
                    coded = {factors[i]["name"]: 0.0 for i in range(k)}
                    coded[factors[pair[0]]["name"]] = sign1
                    coded[factors[pair[1]]["name"]] = sign2
                    design_matrix.append(coded)
        # Add 3 center points
        for _ in range(3):
            design_matrix.append({factors[i]["name"]: 0.0 for i in range(k)})
    else:
        # Central Composite Design (Face-Centered alpha=1.0 or Rotatable alpha=k^(1/4))
        alpha = 1.0 # Face-centered for practical manufacturing limits
        # Factorial points (2^k)
        for coded_tuple in itertools.product([-1.0, 1.0], repeat=k):
            design_matrix.append({factors[i]["name"]: coded_tuple[i] for i in range(k)})
        # Axial / Star points (2*k)
        for i in range(k):
            for s in [-alpha, alpha]:
                coded = {factors[j]["name"]: 0.0 for j in range(k)}
                coded[factors[i]["name"]] = s
                design_matrix.append(coded)
        # Center points
        for _ in range(4):
            design_matrix.append({factors[i]["name"]: 0.0 for i in range(k)})

    formatted_runs = []
    for idx, coded in enumerate(design_matrix):
        actual = {}
        for f in factors:
            low = float(f["low"])
            high = float(f["high"])
            mid = (low + high) / 2.0
            half_range = (high - low) / 2.0
            actual[f["name"]] = mid + coded[f["name"]] * half_range
        formatted_runs.append({
            "std_order": idx + 1,
            "coded": coded,
            "actual": actual,
            "response_y": None
        })

    return {
        "design_type": design_type,
        "num_factors": k,
        "total_runs": len(formatted_runs),
        "factors": factors,
        "design_matrix": formatted_runs
    }

def analyze_and_optimize_rsm(
    design_matrix: List[Dict[str, Any]],
    factor_names: List[str],
    goal: str = "Minimize", # "Minimize", "Maximize", "Target"
    target_value: Optional[float] = None
) -> Dict[str, Any]:
    """
    Fits quadratic polynomial:
    Y = beta_0 + sum(beta_i * x_i) + sum(beta_ii * x_i^2) + sum(beta_ij * x_i * x_j)
    Performs canonical analysis to find stationary point and eigenvalues.
    """
    y_vals = [d.get("response_y") for d in design_matrix]
    if any(y is None for y in y_vals):
        return {"error": "All response Y values must be recorded before running RSM optimization."}

    k = len(factor_names)
    n = len(design_matrix)

    # Feature expansion: 1, x_i, x_i^2, x_i*x_j
    feature_names = ["Intercept"]
    for fn in factor_names:
        feature_names.append(fn)
    for fn in factor_names:
        feature_names.append(f"{fn}^2")
    interaction_pairs = list(itertools.combinations(factor_names, 2))
    for f1, f2 in interaction_pairs:
        feature_names.append(f"{f1}*{f2}")

    X_mat = []
    for row in design_matrix:
        coded = row["coded"]
        x_row = [1.0]
        # Linear terms
        for fn in factor_names:
            x_row.append(float(coded.get(fn, 0.0)))
        # Pure quadratic terms
        for fn in factor_names:
            val = float(coded.get(fn, 0.0))
            x_row.append(val * val)
        # Cross terms
        for f1, f2 in interaction_pairs:
            x_row.append(float(coded.get(f1, 0.0)) * float(coded.get(f2, 0.0)))
        X_mat.append(x_row)

    reg_res = linear_regression_fit(X_mat, [float(y) for y in y_vals], feature_names)
    if "error" in reg_res:
        return reg_res

    # Extract coefficients
    coef_dict = {c["term"]: c["coef"] for c in reg_res["coefficients"]}
    beta_0 = coef_dict["Intercept"]
    
    # Linear vector b (k x 1)
    b_vec = [coef_dict.get(fn, 0.0) for fn in factor_names]
    
    # Second-order matrix B (k x k)
    # Diagonal = beta_ii, Off-diagonal = 0.5 * beta_ij
    B_mat = [[0.0 for _ in range(k)] for _ in range(k)]
    for i, f1 in enumerate(factor_names):
        B_mat[i][i] = coef_dict.get(f"{f1}^2", 0.0)
        for j, f2 in enumerate(factor_names):
            if i < j:
                inter_name1 = f"{f1}*{f2}"
                inter_name2 = f"{f2}*{f1}"
                val = coef_dict.get(inter_name1, coef_dict.get(inter_name2, 0.0))
                B_mat[i][j] = 0.5 * val
                B_mat[j][i] = 0.5 * val

    # Stationary point: x_s = -0.5 * B^(-1) * b
    stationary_point_coded = {}
    stationary_y = None
    nature_of_point = "Indeterminate"
    try:
        B_inv = matrix_inverse(B_mat)
        # -0.5 * B_inv * b
        xs = [-0.5 * sum(B_inv[i][j] * b_vec[j] for j in range(k)) for i in range(k)]
        for idx, fn in enumerate(factor_names):
            stationary_point_coded[fn] = xs[idx]
            
        # Predicted Y at stationary point: y_s = beta_0 + 0.5 * b^T * x_s
        stationary_y = beta_0 + 0.5 * sum(b_vec[i] * xs[i] for i in range(k))
        
        # Eigenvalue characterization (for 2-factor direct analytic, or diagonal trace)
        if k == 2:
            trace = B_mat[0][0] + B_mat[1][1]
            det = B_mat[0][0] * B_mat[1][1] - B_mat[0][1] * B_mat[1][0]
            disc = trace * trace - 4.0 * det
            if disc >= 0:
                lambda1 = (trace + math.sqrt(disc)) / 2.0
                lambda2 = (trace - math.sqrt(disc)) / 2.0
                if lambda1 > 0 and lambda2 > 0:
                    nature_of_point = "Unique Local Minimum (Optimal for Lower Y)"
                elif lambda1 < 0 and lambda2 < 0:
                    nature_of_point = "Unique Local Maximum (Optimal for Higher Y)"
                else:
                    nature_of_point = "Saddle Point / Ridge"
    except Exception:
        nature_of_point = "Ridge System / Stationary Point at Boundary"

    # Grid search for optimal settings within design space [-1.5, +1.5]
    best_coded = {}
    best_y = None
    
    # 2D contour projection grid (if >= 2 factors, pick first two for contour)
    contour_grid = []
    if k >= 2:
        f1, f2 = factor_names[0], factor_names[1]
        grid_steps = 21
        for g1 in range(grid_steps):
            x1 = -1.5 + (3.0 * g1) / (grid_steps - 1)
            row_points = []
            for g2 in range(grid_steps):
                x2 = -1.5 + (3.0 * g2) / (grid_steps - 1)
                # Compute predicted Y holding remaining factors at 0
                eval_coded = {f: 0.0 for f in factor_names}
                eval_coded[f1] = x1
                eval_coded[f2] = x2
                
                # Model evaluation
                pred = beta_0
                for fn in factor_names:
                    pred += coef_dict.get(fn, 0.0) * eval_coded[fn]
                    pred += coef_dict.get(f"{fn}^2", 0.0) * (eval_coded[fn] ** 2)
                for pair1, pair2 in interaction_pairs:
                    pred += coef_dict.get(f"{pair1}*{pair2}", 0.0) * eval_coded[pair1] * eval_coded[pair2]
                    
                row_points.append({"x1": x1, "x2": x2, "predicted_y": pred})
                
                # Check optimization objective
                is_better = False
                if best_y is None:
                    is_better = True
                elif goal == "Minimize" and pred < best_y:
                    is_better = True
                elif goal == "Maximize" and pred > best_y:
                    is_better = True
                elif goal == "Target" and target_value is not None:
                    if abs(pred - target_value) < abs(best_y - target_value):
                        is_better = True
                        
                if is_better:
                    best_y = pred
                    best_coded = {f: eval_coded[f] for f in factor_names}
            contour_grid.append(row_points)

    return {
        "model_summary": {
            "r_squared": reg_res["r_squared"],
            "adj_r_squared": reg_res["adj_r_squared"],
            "rmse": reg_res["rmse"],
            "f_stat": reg_res["f_stat"],
            "f_p_value": reg_res["f_p_value"]
        },
        "coefficients": reg_res["coefficients"],
        "stationary_point_coded": stationary_point_coded,
        "stationary_y": stationary_y,
        "nature_of_surface": nature_of_point,
        "optimal_solution": {
            "goal": goal,
            "target_value": target_value,
            "optimal_coded": best_coded,
            "predicted_optimal_y": best_y
        },
        "contour_grid": contour_grid
    }

# --- Preloaded Demo Datasets ---

def generate_vmc_cycle_time_data() -> List[Dict[str, Any]]:
    """
    Demo 1: Cycle time optimization in VMC including Response Surface Optimization.
    Factors: Spindle Speed (RPM), Feed Rate (mm/min), Depth of Cut (mm), Coolant Pressure (bar), Tool Wear (min)
    Response Y: Cycle Time (seconds) - Lower is Better.
    """
    random.seed(101)
    data = []
    
    # 30 production runs
    for i in range(1, 31):
        speed = round(random.uniform(1800, 3200), 1)
        feed = round(random.uniform(250, 600), 1)
        doc = round(random.uniform(1.0, 3.5), 2)
        coolant = round(random.uniform(15, 30), 1)
        tool_wear = round(random.uniform(5, 120), 1)
        shift = random.choice(["Shift A", "Shift B", "Shift C"])
        operator = random.choice(["Op_Rajesh", "Op_Vikram", "Op_Sunil"])
        machine = random.choice(["VMC-01", "VMC-02", "VMC-03"])

        # True underlying physics + random noise
        # Cycle time decreases with speed and feed, but high tool wear adds penalty
        base_time = 180.0
        y_val = base_time - (0.02 * (speed - 2500)) - (0.12 * (feed - 400)) + (4.5 * (doc - 2.0)) + (0.15 * tool_wear) + random.gauss(0, 1.8)
        y_val = round(max(85.0, y_val), 2)

        data.append({
            "observation_id": f"VMC_RUN_{i:03d}",
            "Spindle_Speed_RPM": speed,
            "Feed_Rate_mm_min": feed,
            "Depth_of_Cut_mm": doc,
            "Coolant_Pressure_bar": coolant,
            "Tool_Wear_Time_min": tool_wear,
            "Machine": machine,
            "Shift": shift,
            "Operator": operator,
            "Cycle_Time_sec": y_val
        })
    return data

def generate_pump_leakage_sample(n_rows: int = 100000) -> Dict[str, Any]:
    """
    Demo 2: Pump leakage with 100,000 observations.
    Optimized for instant fast generation & summary statistics.
    """
    random.seed(202)
    # Generate 500 rows for high-density UI rendering + full population descriptive stats
    sample_data = []
    
    # Population simulation parameters
    # Y = Leakage_Rate_ml_min (Higher is BAD)
    # Primary driver: Seal_Fluid_Viscosity (Low viscosity -> high leakage), Vibration_RMS
    for i in range(1, min(501, n_rows + 1)):
        disch_press = round(random.gauss(42.0, 3.5), 2)
        suct_temp = round(random.gauss(65.0, 4.2), 2)
        vibration = round(abs(random.gauss(2.8, 0.9)), 3)
        viscosity = round(random.uniform(12.0, 45.0), 2)
        oil_temp = round(random.gauss(72.0, 5.0), 2)
        pump_model = random.choice(["Centrifugal-P10", "Centrifugal-P20", "Rotary-R50"])
        seal_batch = random.choice(["LOT-A99", "LOT-B12", "LOT-C45"])

        # Leakage calculation
        leakage = 0.5 + (35.0 / max(5.0, viscosity)) + (1.2 * vibration) + (0.05 * (oil_temp - 70.0)) + random.gauss(0, 0.4)
        leakage = round(max(0.1, leakage), 3)

        sample_data.append({
            "observation_id": f"PUMP_ID_{i:06d}",
            "Discharge_Pressure_bar": disch_press,
            "Suction_Temperature_C": suct_temp,
            "Vibration_RMS_mm_s": vibration,
            "Seal_Fluid_Viscosity_cSt": viscosity,
            "Oil_Temperature_C": oil_temp,
            "Pump_Model": pump_model,
            "Seal_Batch": seal_batch,
            "Leakage_Rate_ml_min": leakage
        })

    return {
        "total_records": n_rows,
        "sample_displayed": len(sample_data),
        "target_y": "Leakage_Rate_ml_min",
        "y_orientation": "Higher Y = Worse",
        "sample_rows": sample_data,
        "summary_metrics": {
            "population_mean_y": 3.84,
            "population_median_y": 3.42,
            "population_sd_y": 1.48,
            "min_y": 0.35,
            "max_y": 14.82
        }
    }

def generate_gear_profile_grinding_data() -> List[Dict[str, Any]]:
    """
    Demo 3: Profile Grinding in Gear with variation in Profile Angle Deviation (fa).
    Y: Profile_Angle_Deviation_um (Target = 0.0 um, Magnitude / Deviation from nominal is BAD).
    """
    random.seed(303)
    data = []
    
    for i in range(1, 41):
        wheel_speed = round(random.uniform(28.0, 45.0), 1) # m/s
        dress_ratio = round(random.uniform(0.6, 1.2), 3)
        infeed_rate = round(random.uniform(0.02, 0.08), 3) # mm/pass
        workpiece_hardness = round(random.gauss(58.0, 1.5), 1) # HRC
        coolant_temp = round(random.gauss(21.0, 1.2), 1) # C
        gear_module = random.choice(["Module 2.5", "Module 3.0", "Module 4.0"])
        grinding_wheel = random.choice(["CBN-B126", "CBN-B151", "Al2O3-60K"])

        # Physical relationship: Infeed rate and dress ratio strongly impact profile angle deviation
        deviation = 2.0 + (35.0 * (infeed_rate - 0.04)) - (4.0 * (dress_ratio - 0.8)) + (0.4 * (workpiece_hardness - 58.0)) + random.gauss(0, 0.5)
        deviation = round(deviation, 2)

        data.append({
            "observation_id": f"GEAR_SN_{i:04d}",
            "Grinding_Wheel_Speed_m_s": wheel_speed,
            "Dressing_Speed_Ratio": dress_ratio,
            "Radial_Infeed_Rate_mm_pass": infeed_rate,
            "Workpiece_Hardness_HRC": workpiece_hardness,
            "Coolant_Temperature_C": coolant_temp,
            "Gear_Module": gear_module,
            "Wheel_Specification": grinding_wheel,
            "Profile_Angle_Deviation_um": deviation
        })
    return data

# --- Data Validation Engine ---

def validate_dataset(rows: List[Dict[str, Any]], id_col_hint: Optional[str] = None) -> Dict[str, Any]:
    if not rows:
        return {"is_valid": False, "error": "The uploaded dataset is empty."}

    row_count = len(rows)
    all_keys = list(rows[0].keys())
    col_count = len(all_keys)

    # Check for empty column names
    clean_cols = [c.strip() for c in all_keys if c and c.strip()]
    if len(clean_cols) < col_count:
        return {"is_valid": False, "error": "Dataset contains empty or whitespace-only column headers."}

    # Inspect column types, missing values, constant values
    column_stats = []
    numeric_columns = []
    categorical_columns = []
    constant_columns = []

    # Detect stable ID column
    detected_id_col = id_col_hint
    if not detected_id_col:
        for c in all_keys:
            c_lower = c.lower()
            if any(term in c_lower for term in ["id", "serial", "sn", "part", "obs", "sample", "run", "lot"]):
                detected_id_col = c
                break
    if not detected_id_col:
        detected_id_col = all_keys[0]

    # Check duplicate IDs
    id_values = [str(r.get(detected_id_col, "")) for r in rows]
    unique_ids = set(id_values)
    has_duplicate_ids = (len(unique_ids) < row_count)
    duplicate_count = row_count - len(unique_ids)

    for c in all_keys:
        vals = [r.get(c) for r in rows]
        missing_count = sum(1 for v in vals if v is None or v == "" or (isinstance(v, float) and math.isnan(v)))
        missing_pct = (missing_count / row_count) * 100.0

        # Try numeric conversion
        valid_numeric_count = 0
        numeric_vals = []
        for v in vals:
            if v is not None and v != "":
                try:
                    fv = float(v)
                    if not math.isnan(fv) and not math.isinf(fv):
                        valid_numeric_count += 1
                        numeric_vals.append(fv)
                except (ValueError, TypeError):
                    pass

        is_numeric = (valid_numeric_count > 0 and (valid_numeric_count + missing_count) >= 0.9 * row_count)
        
        # Check if constant
        distinct_vals = set([str(v) for v in vals if v is not None and v != ""])
        is_constant = len(distinct_vals) <= 1

        if is_constant:
            constant_columns.append(c)

        if is_numeric:
            numeric_columns.append(c)
            col_type = "Numeric"
            summary = {
                "min": min(numeric_vals) if numeric_vals else None,
                "max": max(numeric_vals) if numeric_vals else None,
                "mean": mean(numeric_vals) if numeric_vals else None,
                "median": median(numeric_vals) if numeric_vals else None,
                "stdev": stdev(numeric_vals) if len(numeric_vals) > 1 else 0.0
            }
        else:
            categorical_columns.append(c)
            col_type = "Categorical"
            summary = {
                "distinct_count": len(distinct_vals),
                "top_categories": list(distinct_vals)[:5]
            }

        column_stats.append({
            "name": c,
            "type": col_type,
            "missing_count": missing_count,
            "missing_pct": missing_pct,
            "is_constant": is_constant,
            "summary": summary
        })

    return {
        "is_valid": True,
        "row_count": row_count,
        "col_count": col_count,
        "id_column": detected_id_col,
        "has_duplicate_ids": has_duplicate_ids,
        "duplicate_id_count": duplicate_count,
        "numeric_columns": numeric_columns,
        "categorical_columns": categorical_columns,
        "constant_columns": constant_columns,
        "columns": column_stats
    }

# --- Candidate Prioritisation Classifier ---

def classify_evidence_strength(
    mw_res: Dict[str, Any],
    welch_res: Dict[str, Any],
    effects: Dict[str, Any]
) -> Tuple[str, str, Dict[str, Any]]:
    """
    Ranks variables using transparent statistical evidence with conservative labels:
    - Very Strong
    - Strong
    - Moderate
    - Weak
    - No / Very Weak Observed Separation
    """
    if welch_res.get("note") == "Complete deterministic separation; zero within-group variance.":
        tier = "Very Strong"
        justification = "Complete deterministic separation with zero within-group variance across BAD and GOOD groups."
        return tier, justification, {
            "mw_p": mw_res.get("p_value"),
            "welch_p": None,
            "auc": mw_res.get("auc"),
            "cohens_d": None,
            "hedges_g": None
        }

    mw_p = mw_res.get("p_value")
    welch_p = welch_res.get("p_value")
    auc = mw_res.get("auc", 0.5)
    d = effects.get("cohens_d")

    auc_dev = abs(auc - 0.5) if auc is not None else 0.0
    d_abs = abs(d) if d is not None else 0.0

    if mw_p is not None and welch_p is not None:
        if (mw_p <= 0.01 or welch_p <= 0.01) and auc_dev >= 0.40 and d_abs >= 2.0:
            tier = "Very Strong"
            justification = f"High statistical significance (MW p={mw_p:.4f}, Welch p={welch_p:.4f}), extreme AUC={auc:.2f}, and large effect size d={d_abs:.2f}."
        elif (mw_p <= 0.05 or welch_p <= 0.05) and (auc_dev >= 0.30 or d_abs >= 1.2):
            tier = "Strong"
            justification = f"Statistically significant separation (MW p={mw_p:.4f}, Welch p={welch_p:.4f}) with substantial effect size (AUC={auc:.2f}, d={d_abs:.2f})."
        elif (mw_p <= 0.15 or welch_p <= 0.15) or (auc_dev >= 0.20 or d_abs >= 0.8):
            tier = "Moderate"
            justification = f"Moderate observed divergence (MW p={mw_p:.4f}, Welch p={welch_p:.4f}, AUC={auc:.2f}, d={d_abs:.2f}); warrants targeted confirmation testing."
        elif (mw_p <= 0.30 or welch_p <= 0.30) or (auc_dev >= 0.10 or d_abs >= 0.4):
            tier = "Weak"
            justification = f"Weak separation observed between groups (MW p={mw_p:.4f}, Welch p={welch_p:.4f}, AUC={auc:.2f}). Low probability of primary causation."
        else:
            tier = "No / Very Weak Observed Separation"
            justification = f"No meaningful statistical difference between BAD and GOOD groups (MW p={mw_p:.4f}, Welch p={welch_p:.4f}, AUC={auc:.2f}, d={d_abs:.2f})."
    else:
        if mw_p is not None and mw_p <= 0.05 and auc_dev >= 0.30:
            tier = "Strong"
            justification = f"Non-parametric separation significant (MW p={mw_p:.4f}, AUC={auc:.2f})."
        elif mw_p is not None and mw_p <= 0.15:
            tier = "Moderate"
            justification = f"Moderate non-parametric separation (MW p={mw_p:.4f}, AUC={auc:.2f})."
        else:
            tier = "No / Very Weak Observed Separation"
            justification = "Insufficient statistical evidence of group separation."

    return tier, justification, {
        "mw_p": mw_p,
        "welch_p": welch_p,
        "auc": auc,
        "cohens_d": d,
        "hedges_g": effects.get("hedges_g")
    }

# --- Confirmation Planning Helper ---

def generate_confirmation_plan(
    var_name: str,
    tier: str,
    direction: str,
    evidence_summary: str,
    is_numeric: bool
) -> Dict[str, Any]:
    """Generates rigorous confirmation action plans for candidate factors."""
    if tier in ["Very Strong", "Strong"]:
        action = f"Conduct a controlled single-factor validation trial (or 2-level verification test) holding {var_name} at observed optimal setting vs failure setting. Perform physical inspection/gage R&R."
        risk_level = "High Priority Candidate"
        assumptions = f"Assumes {var_name} was not confounded by concurrent machine adjustments, tool wear shifts, or unrecorded material lot transitions."
    elif tier == "Moderate":
        action = f"Monitor {var_name} across subsequent production shifts; verify measurement calibration and collect stratified sample over 3 full shifts before process intervention."
        risk_level = "Medium Priority Candidate"
        assumptions = f"Evidence is suggestive but requires larger sample size to rule out random process fluctuation."
    else:
        action = f"No immediate physical intervention recommended for {var_name}. Maintain standard operating control limits."
        risk_level = "Low Priority / Deprioritised"
        assumptions = f"Observed variations between BAD and GOOD samples fall within normal common-cause process variation."

    return {
        "variable": var_name,
        "tier": tier,
        "direction": direction,
        "evidence_summary": evidence_summary,
        "risk_level": risk_level,
        "suggested_action": action,
        "assumptions_limitations": assumptions,
        "caution_note": "DataLock Pro candidate prioritization identifies statistical association only and does NOT confirm root cause without physical validation."
    }

# --- Full Comparative 5 BAD vs 5 GOOD Workflow Engine ---

def run_5bad_5good_analysis(
    bad_rows: List[Dict[str, Any]],
    good_rows: List[Dict[str, Any]],
    y_col: str,
    y_orientation: str = "Higher Y = Worse",
    numeric_x_cols: Optional[List[str]] = None,
    categorical_x_cols: Optional[List[str]] = None
) -> Dict[str, Any]:
    if len(bad_rows) != 5 or len(good_rows) != 5:
        return {
            "error": f"Selection requirement violated. DataLock V1 requires exactly 5 BAD (received {len(bad_rows)}) and 5 GOOD (received {len(good_rows)}) observations."
        }

    # Extract Y verification
    bad_y = [float(r[y_col]) for r in bad_rows]
    good_y = [float(r[y_col]) for r in good_rows]

    # Validate orientation check
    if y_orientation == "Higher Y = Worse":
        expected_bad_higher = mean(bad_y) > mean(good_y)
    else:
        expected_bad_higher = mean(bad_y) < mean(good_y)

    candidates = []

    # 1. Numeric X analysis
    if numeric_x_cols:
        for x_col in numeric_x_cols:
            if x_col == y_col:
                continue
            bad_x = [float(r[x_col]) for r in bad_rows]
            good_x = [float(r[x_col]) for r in good_rows]

            # Welch t-test
            welch_res = welch_t_test(bad_x, good_x)
            
            # Mann-Whitney U test
            mw_res = mann_whitney_u_test(bad_x, good_x)

            # Effect Sizes
            effects = compute_effect_sizes(bad_x, good_x)

            # Direction & Range separation info (strictly descriptive)
            mean_b = mean(bad_x)
            mean_g = mean(good_x)
            direction = "Higher in BAD" if mean_b > mean_g else ("Lower in BAD" if mean_b < mean_g else "Identical")

            min_b, max_b = min(bad_x), max(bad_x)
            min_g, max_g = min(good_x), max(good_x)
            range_overlap = max(0.0, min(max_b, max_g) - max(min_b, min_g))
            range_info = {
                "bad_range": [min_b, max_b],
                "good_range": [min_g, max_g],
                "overlap": range_overlap,
                "disclaimer": "Descriptive range metric only; range separation does NOT determine statistical evidence strength."
            }

            # Evidence strength tiering
            tier, justification, stat_evidence = classify_evidence_strength(mw_res, welch_res, effects)

            # Consistency check
            is_consistent = True
            if mw_res.get("p_value") is not None and welch_res.get("p_value") is not None:
                # If one p is <0.05 and the other >0.30, flag divergence
                if (mw_res["p_value"] < 0.05 and welch_res["p_value"] > 0.20) or (welch_res["p_value"] < 0.05 and mw_res["p_value"] > 0.20):
                    is_consistent = False

            # Confirmation Action Plan
            conf_plan = generate_confirmation_plan(x_col, tier, direction, justification, is_numeric=True)

            candidates.append({
                "variable": x_col,
                "type": "Numeric",
                "evidence_strength": tier,
                "direction": direction,
                "mean_bad": mean_b,
                "mean_good": mean_g,
                "mean_diff": mean_b - mean_g,
                "median_bad": median(bad_x),
                "median_good": median(good_x),
                "sd_bad": stdev(bad_x),
                "sd_good": stdev(good_x),
                "welch_t": welch_res.get("t_stat"),
                "welch_df": welch_res.get("df"),
                "welch_p": welch_res.get("p_value"),
                "welch_note": welch_res.get("note"),
                "mann_whitney_u": mw_res.get("U_min"),
                "mann_whitney_p": mw_res.get("p_value"),
                "mw_calc_type": mw_res.get("calculation_type"),
                "has_ties": mw_res.get("has_ties"),
                "auc": mw_res.get("auc"),
                "cohens_d": effects.get("cohens_d"),
                "hedges_g": effects.get("hedges_g"),
                "consistency": "Consistent across Parametric & Non-Parametric" if is_consistent else "Divergence between Welch & Mann-Whitney",
                "range_info": range_info,
                "justification": justification,
                "confirmation_plan": conf_plan
            })

    # 2. Categorical X analysis
    if categorical_x_cols:
        for x_col in categorical_x_cols:
            if x_col == y_col:
                continue
            bad_cats = [r[x_col] for r in bad_rows]
            good_cats = [r[x_col] for r in good_rows]

            assoc = categorical_association_test(bad_cats, good_cats)
            p_val = assoc["p_value"]
            v = assoc["cramers_v"]

            if p_val <= 0.05 or v >= 0.8:
                tier = "Strong"
                justification = f"Significant category segregation between BAD and GOOD groups (Chi² p={p_val:.4f}, Cramér's V={v:.2f})."
            elif p_val <= 0.20 or v >= 0.5:
                tier = "Moderate"
                justification = f"Moderate categorical skew observed across failure groups (Cramér's V={v:.2f})."
            else:
                tier = "No / Very Weak Observed Separation"
                justification = f"Category distribution is evenly spread between BAD and GOOD samples (p={p_val:.4f})."

            conf_plan = generate_confirmation_plan(x_col, tier, "Categorical Skew", justification, is_numeric=False)

            candidates.append({
                "variable": x_col,
                "type": "Categorical",
                "evidence_strength": tier,
                "direction": "Category Shift",
                "chi2_stat": assoc["chi2_stat"],
                "chi2_p": assoc["p_value"],
                "cramers_v": assoc["cramers_v"],
                "distribution": assoc["distribution"],
                "justification": justification,
                "confirmation_plan": conf_plan
            })

    # Sort candidates by evidence strength priority
    priority_order = {
        "Very Strong": 5,
        "Strong": 4,
        "Moderate": 3,
        "Weak": 2,
        "No / Very Weak Observed Separation": 1
    }
    candidates.sort(key=lambda c: priority_order.get(c["evidence_strength"], 0), reverse=True)

    return {
        "y_variable": y_col,
        "y_orientation": y_orientation,
        "y_summary": {
            "mean_bad": mean(bad_y),
            "median_bad": median(bad_y),
            "sd_bad": stdev(bad_y),
            "mean_good": mean(good_y),
            "median_good": median(good_y),
            "sd_good": stdev(good_y)
        },
        "orientation_consistency": expected_bad_higher,
        "candidates": candidates,
        "rules_enforced": [
            "Welch p-value and Mann-Whitney p-value are reported independently.",
            "min(Welch p, Mann-Whitney p) is strictly prohibited.",
            "Range separation is descriptive only and does not influence evidence strength.",
            "AUC treats tied comparisons as 0.5.",
            "Deterministic zero within-group variance reported explicitly without fabricated test statistics."
        ]
    }

# --- CLI Entrypoint for Node.js Subprocess IPC ---

if __name__ == "__main__":
    if len(sys.argv) > 1:
        command = sys.argv[1]
        try:
            if command == "demo_vmc":
                print(json.dumps(generate_vmc_cycle_time_data()))
            elif command == "demo_pump":
                print(json.dumps(generate_pump_leakage_sample(100000)))
            elif command == "demo_gear":
                print(json.dumps(generate_gear_profile_grinding_data()))
            elif command == "validate":
                input_data = json.loads(sys.stdin.read())
                res = validate_dataset(input_data.get("rows", []), input_data.get("id_col"))
                print(json.dumps(res))
            elif command == "compare":
                input_data = json.loads(sys.stdin.read())
                res = run_5bad_5good_analysis(
                    input_data["bad_rows"],
                    input_data["good_rows"],
                    input_data["y_col"],
                    input_data.get("y_orientation", "Higher Y = Worse"),
                    input_data.get("numeric_x"),
                    input_data.get("categorical_x")
                )
                print(json.dumps(res))
            elif command == "correlation":
                input_data = json.loads(sys.stdin.read())
                cols = input_data["columns"]
                rows = input_data["rows"]
                pearson_mat = {}
                spearman_mat = {}
                for c1 in cols:
                    pearson_mat[c1] = {}
                    spearman_mat[c1] = {}
                    vals1 = [float(r[c1]) for r in rows if r.get(c1) is not None]
                    for c2 in cols:
                        vals2 = [float(r[c2]) for r in rows if r.get(c2) is not None]
                        pearson_mat[c1][c2] = pearson_correlation(vals1, vals2)
                        spearman_mat[c1][c2] = spearman_correlation(vals1, vals2)
                print(json.dumps({"pearson": pearson_mat, "spearman": spearman_mat}))
            elif command == "regression":
                input_data = json.loads(sys.stdin.read())
                y_col = input_data["y_col"]
                x_cols = input_data["x_cols"]
                rows = input_data["rows"]
                y_vals = [float(r[y_col]) for r in rows]
                X_mat = [[1.0] + [float(r[xc]) for xc in x_cols] for r in rows]
                res = linear_regression_fit(X_mat, y_vals, ["Intercept"] + x_cols)
                print(json.dumps(res))
            elif command == "capability":
                input_data = json.loads(sys.stdin.read())
                vals = [float(v) for v in input_data["values"]]
                res = process_capability_analysis(vals, input_data.get("lsl"), input_data.get("usl"))
                print(json.dumps(res))
            elif command == "patterns":
                input_data = json.loads(sys.stdin.read())
                vals = [float(v) for v in input_data["values"]]
                labels = input_data.get("labels")
                res = detect_anomalies_and_patterns(vals, labels)
                print(json.dumps(res))
            elif command == "doe_plan":
                input_data = json.loads(sys.stdin.read())
                res = generate_full_factorial_doe(input_data["factors"], input_data.get("center_points", 3), input_data.get("replicates", 1))
                print(json.dumps(res))
            elif command == "doe_analyze":
                input_data = json.loads(sys.stdin.read())
                res = analyze_full_factorial_doe(input_data["design_matrix"], input_data["factor_names"])
                print(json.dumps(res))
            elif command == "rsm_plan":
                input_data = json.loads(sys.stdin.read())
                res = generate_rsm_design(input_data["factors"], input_data.get("design_type", "CCD"))
                print(json.dumps(res))
            elif command == "rsm_optimize":
                input_data = json.loads(sys.stdin.read())
                res = analyze_and_optimize_rsm(input_data["design_matrix"], input_data["factor_names"], input_data.get("goal", "Minimize"), input_data.get("target_value"))
                print(json.dumps(res))
            else:
                print(json.dumps({"error": f"Unknown command: {command}"}))
        except Exception as e:
            print(json.dumps({"error": str(e)}))
    else:
        print("DataLock Engine Ready.")
