#!/usr/bin/env python3
"""
Krisha Innovate - DataLock Pro Automated Test Suite
Verifies all 14 statistical rules, benchmarks, and numerical invariants.
"""

import sys
import json
import math
import time
import traceback
from datalock_engine import (
    welch_t_test,
    mann_whitney_u_test,
    compute_effect_sizes,
    validate_dataset,
    run_5bad_5good_analysis,
    pearson_correlation,
    spearman_correlation,
    linear_regression_fit,
    process_capability_analysis,
    detect_anomalies_and_patterns,
    generate_full_factorial_doe,
    analyze_full_factorial_doe,
    generate_rsm_design,
    analyze_and_optimize_rsm
)

def run_all_tests():
    tests = []
    
    # 1. Zero Variance Test
    # BAD = 10,10,10,10,10; GOOD = 20,20,20,20,20
    # Expected: "Complete deterministic separation; zero within-group variance."
    # No fake d=50, t=50 or p=0.0001
    t_start = time.perf_counter()
    try:
        bad_zero = [10.0, 10.0, 10.0, 10.0, 10.0]
        good_zero = [20.0, 20.0, 20.0, 20.0, 20.0]
        welch_zero = welch_t_test(bad_zero, good_zero)
        eff_zero = compute_effect_sizes(bad_zero, good_zero)
        mw_zero = mann_whitney_u_test(bad_zero, good_zero)
        
        t1_pass = (
            welch_zero.get("t_stat") is None and
            welch_zero.get("p_value") is None and
            "Complete deterministic separation" in welch_zero.get("note", "") and
            eff_zero.get("cohens_d") is None and
            mw_zero.get("auc") == 0.0
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T1",
            "name": "Zero-Variance Deterministic Separation",
            "category": "Parametric / Robustness",
            "description": "BAD=[10]*5, GOOD=[20]*5: Verifies no fabricated t/p/d values, reports deterministic separation note.",
            "status": "PASS" if t1_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Note: '{welch_zero.get('note')}', Welch p: {welch_zero.get('p_value')}, Cohen's d: {eff_zero.get('cohens_d')}, AUC: {mw_zero.get('auc')}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T1",
            "name": "Zero-Variance Deterministic Separation",
            "category": "Parametric / Robustness",
            "description": "BAD=[10]*5, GOOD=[20]*5: Verifies no fabricated t/p/d values, reports deterministic separation note.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 2. False Range Test
    # BAD = 0,50,50,50,100; GOOD = 45,48,50,52,55
    # Expected: mean diff = 0, median diff = 0, Cohen's d = 0, AUC = 0.5
    # The large range difference must NOT create strong evidence.
    t_start = time.perf_counter()
    try:
        bad_range = [0.0, 50.0, 50.0, 50.0, 100.0]
        good_range = [45.0, 48.0, 50.0, 52.0, 55.0]
        welch_fr = welch_t_test(bad_range, good_range)
        eff_fr = compute_effect_sizes(bad_range, good_range)
        mw_fr = mann_whitney_u_test(bad_range, good_range)
        
        mean_diff = welch_fr["mean_diff"]
        d_val = eff_fr["cohens_d"]
        auc_val = mw_fr["auc"]
        
        t2_pass = (
            math.isclose(mean_diff, 0.0, abs_tol=1e-9) and
            math.isclose(d_val, 0.0, abs_tol=1e-9) and
            math.isclose(auc_val, 0.5, abs_tol=1e-9) and
            welch_fr["p_value"] == 1.0
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T2",
            "name": "False Range Separation Resistance",
            "category": "Evidence & Range",
            "description": "BAD=[0,50,50,50,100], GOOD=[45,48,50,52,55]: Verifies range span does not artificially inflate evidence.",
            "status": "PASS" if t2_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Mean diff: {mean_diff}, Cohen's d: {d_val}, AUC: {auc_val}, Welch p: {welch_fr['p_value']:.4f}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T2",
            "name": "False Range Separation Resistance",
            "category": "Evidence & Range",
            "description": "BAD=[0,50,50,50,100], GOOD=[45,48,50,52,55]: Verifies range span does not artificially inflate evidence.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 3. Outlier Resistance Test
    # BAD = 10,11,12,13,100; GOOD = 10,11,12,13,14
    # Expected: U = 5, exact no-tie MW p ≈ 0.15079365 (or tied rank permutation p), AUC ≈ 0.52
    t_start = time.perf_counter()
    try:
        bad_outlier = [10.0, 11.0, 12.0, 13.0, 100.0]
        good_outlier = [10.0, 11.0, 12.0, 13.0, 14.0]
        mw_outlier = mann_whitney_u_test(bad_outlier, good_outlier)
        
        t3_pass = (
            mw_outlier["has_ties"] == True and
            math.isclose(mw_outlier["auc"], 0.52, abs_tol=1e-4) and
            mw_outlier["p_value"] > 0.05
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T3",
            "name": "Outlier Resistance & Tied AUC",
            "category": "Non-Parametric / Ties",
            "description": "BAD=[10,11,12,13,100], GOOD=[10,11,12,13,14]: Verifies non-parametric stability against isolated outlier.",
            "status": "PASS" if t3_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"AUC: {mw_outlier['auc']}, Has Ties: {mw_outlier['has_ties']}, Permutation p: {mw_outlier['p_value']:.4f}, Calc Type: {mw_outlier['calculation_type']}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T3",
            "name": "Outlier Resistance & Tied AUC",
            "category": "Non-Parametric / Ties",
            "description": "BAD=[10,11,12,13,100], GOOD=[10,11,12,13,14]: Verifies non-parametric stability against isolated outlier.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 4. Independent p-values (No min(Welch, MW))
    t_start = time.perf_counter()
    try:
        bad_sample = [1.2, 2.3, 1.8, 2.1, 2.5]
        good_sample = [4.1, 3.8, 4.5, 4.0, 3.9]
        welch_indep = welch_t_test(bad_sample, good_sample)
        mw_indep = mann_whitney_u_test(bad_sample, good_sample)
        
        t4_pass = (
            welch_indep["p_value"] is not None and
            mw_indep["p_value"] is not None and
            welch_indep["p_value"] != mw_indep["p_value"]
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T4",
            "name": "Independent Welch & Mann-Whitney Calculation",
            "category": "Hypothesis Testing",
            "description": "Ensures Welch and Mann-Whitney p-values are never conflated via min(p_welch, p_mw).",
            "status": "PASS" if t4_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Welch p: {welch_indep['p_value']:.6f}, Mann-Whitney p: {mw_indep['p_value']:.6f}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T4",
            "name": "Independent Welch & Mann-Whitney Calculation",
            "category": "Hypothesis Testing",
            "description": "Ensures Welch and Mann-Whitney p-values are never conflated via min(p_welch, p_mw).",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 5. Data Validation & Hygiene
    t_start = time.perf_counter()
    try:
        dummy_data = [
            {"id": "1", "temp": "100.5", "pressure": "2.1", "status": "PASS"},
            {"id": "2", "temp": "101.2", "pressure": "2.2", "status": "PASS"},
            {"id": "3", "temp": "", "pressure": "2.0", "status": "FAIL"},
            {"id": "4", "temp": "102.0", "pressure": "2.1", "status": "PASS"},
            {"id": "4", "temp": "103.1", "pressure": "2.1", "status": "FAIL"}, # duplicate ID
        ]
        val_res = validate_dataset(dummy_data)
        t5_pass = (
            val_res["is_valid"] == True and
            val_res["has_duplicate_ids"] == True and
            val_res["row_count"] == 5 and
            "temp" in val_res["numeric_columns"] and
            "status" in val_res["categorical_columns"]
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T5",
            "name": "Automated Data Validation & Hygiene",
            "category": "Data Hygiene",
            "description": "Detects missing values, duplicate row IDs, numeric/categorical typing.",
            "status": "PASS" if t5_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Duplicate IDs: {val_res['has_duplicate_ids']}, Numeric: {val_res['numeric_columns']}, Categorical: {val_res['categorical_columns']}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T5",
            "name": "Automated Data Validation & Hygiene",
            "category": "Data Hygiene",
            "description": "Detects missing values, duplicate row IDs, numeric/categorical typing.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 6. Pearson & Spearman Correlation
    t_start = time.perf_counter()
    try:
        x_c = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0]
        y_c = [2.1, 3.9, 6.2, 8.1, 9.9, 12.1, 14.0, 16.2]
        p_corr = pearson_correlation(x_c, y_c)
        s_corr = spearman_correlation(x_c, y_c)
        t6_pass = (
            p_corr["r"] > 0.99 and
            s_corr["rho"] == 1.0 and
            p_corr["p_value"] < 0.001
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T6",
            "name": "Pearson & Spearman Correlation",
            "category": "Correlation",
            "description": "Verifies linear and rank correlation coefficients with exact t-distribution p-values.",
            "status": "PASS" if t6_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Pearson r: {p_corr['r']:.4f} (p={p_corr['p_value']:.2e}), Spearman rho: {s_corr['rho']:.4f}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T6",
            "name": "Pearson & Spearman Correlation",
            "category": "Correlation",
            "description": "Verifies linear and rank correlation coefficients with exact t-distribution p-values.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 7. Linear & Multiple OLS Regression
    t_start = time.perf_counter()
    try:
        X_reg = [[1.0, 1.0], [1.0, 2.0], [1.0, 3.0], [1.0, 4.0], [1.0, 5.0]]
        y_reg = [3.0, 5.0, 7.0, 9.0, 11.0] # y = 1 + 2x
        reg_res = linear_regression_fit(X_reg, y_reg, ["Intercept", "X1"])
        t7_pass = (
            math.isclose(reg_res["coefficients"][0]["coef"], 1.0, abs_tol=1e-5) and
            math.isclose(reg_res["coefficients"][1]["coef"], 2.0, abs_tol=1e-5) and
            math.isclose(reg_res["r_squared"], 1.0, abs_tol=1e-5)
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T7",
            "name": "OLS Linear Regression",
            "category": "Regression",
            "description": "Verifies regression slope, intercept, R², ANOVA F-test, and residual computation.",
            "status": "PASS" if t7_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Intercept: {reg_res['coefficients'][0]['coef']:.4f}, Slope: {reg_res['coefficients'][1]['coef']:.4f}, R²: {reg_res['r_squared']:.4f}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T7",
            "name": "OLS Linear Regression",
            "category": "Regression",
            "description": "Verifies regression slope, intercept, R², ANOVA F-test, and residual computation.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 8. Process Capability (Cp, Cpk)
    t_start = time.perf_counter()
    try:
        spc_data = [10.0, 10.2, 9.9, 10.1, 10.0, 9.8, 10.2, 10.1, 10.0, 9.9]
        cap_res = process_capability_analysis(spc_data, lsl=9.0, usl=11.0)
        t8_pass = (
            cap_res["cp"] is not None and
            cap_res["cpk"] is not None and
            cap_res["cpk"] > 1.33 and
            "Capable" in cap_res["status"]
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T8",
            "name": "Process Capability Analysis (SPC)",
            "category": "SPC & Capability",
            "description": "Calculates Cp, Cpk, Pp, Ppk, short/long-term standard deviations with explicit tolerance limits.",
            "status": "PASS" if t8_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Cp: {cap_res['cp']:.3f}, Cpk: {cap_res['cpk']:.3f}, Status: {cap_res['status']}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T8",
            "name": "Process Capability Analysis (SPC)",
            "category": "SPC & Capability",
            "description": "Calculates Cp, Cpk, Pp, Ppk, short/long-term standard deviations with explicit tolerance limits.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 9. Anomaly Detection & Run Chart Rules
    t_start = time.perf_counter()
    try:
        shift_data = [10.0]*10 + [25.0]*10
        anom_res = detect_anomalies_and_patterns(shift_data)
        t9_pass = (
            len(anom_res["patterns"]) > 0 and
            any("Shift" in p["pattern"] for p in anom_res["patterns"])
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T9",
            "name": "Transparent Anomaly & Western Electric Rules",
            "category": "Anomalies & Patterns",
            "description": "Detects Tukey fences, Modified Z-score (MAD), and Western Electric shift/trend rules without asserting root cause.",
            "status": "PASS" if t9_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Patterns detected: {[p['pattern'] for p in anom_res['patterns']]}, Anomalies: {anom_res['anomaly_count']}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T9",
            "name": "Transparent Anomaly & Western Electric Rules",
            "category": "Anomalies & Patterns",
            "description": "Detects Tukey fences, Modified Z-score (MAD), and Western Electric shift/trend rules without asserting root cause.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 10. Full Factorial DOE Planning & Analysis
    t_start = time.perf_counter()
    try:
        factors_doe = [
            {"name": "Speed", "low": 1000, "high": 2000},
            {"name": "Feed", "low": 100, "high": 300}
        ]
        doe_plan = generate_full_factorial_doe(factors_doe, center_points=3)
        # Synthetic responses: Y = 50 + 10*Speed - 5*Feed + noise
        for row in doe_plan["design_matrix"]:
            coded = row["coded"]
            row["response_y"] = 50.0 + 10.0 * coded["Speed"] - 5.0 * coded["Feed"]
        doe_res = analyze_full_factorial_doe(doe_plan["design_matrix"], ["Speed", "Feed"])
        t10_pass = (
            "pareto_effects" in doe_res and
            len(doe_res["pareto_effects"]) >= 2 and
            doe_res["model_summary"]["r_squared"] > 0.99
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T10",
            "name": "Full Factorial DOE Engine",
            "category": "DOE",
            "description": "Generates 2^k design matrices and computes main effects, interactions, and Pareto rankings.",
            "status": "PASS" if t10_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"DOE R²: {doe_res['model_summary']['r_squared']:.4f}, Top factor: {doe_res['pareto_effects'][0]['term']} (Effect: {doe_res['pareto_effects'][0]['effect']:.2f})"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T10",
            "name": "Full Factorial DOE Engine",
            "category": "DOE",
            "description": "Generates 2^k design matrices and computes main effects, interactions, and Pareto rankings.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 11. Response Surface Methodology (RSM) Optimization
    t_start = time.perf_counter()
    try:
        factors_rsm = [
            {"name": "Temp", "low": 150, "high": 200},
            {"name": "Pressure", "low": 30, "high": 60}
        ]
        rsm_plan = generate_rsm_design(factors_rsm, "CCD")
        # Synthetic quadratic surface: Y = 100 + 4*Temp - 3*Pressure - 6*Temp^2 - 4*Pressure^2 (Maximum)
        for row in rsm_plan["design_matrix"]:
            c = row["coded"]
            t = c["Temp"]
            p = c["Pressure"]
            row["response_y"] = 100.0 + 4.0 * t - 3.0 * p - 6.0 * (t ** 2) - 4.0 * (p ** 2)
        rsm_res = analyze_and_optimize_rsm(rsm_plan["design_matrix"], ["Temp", "Pressure"], goal="Maximize")
        t11_pass = (
            "optimal_solution" in rsm_res and
            rsm_res["optimal_solution"]["predicted_optimal_y"] > 98.0 and
            rsm_res["model_summary"]["r_squared"] > 0.99
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T11",
            "name": "Response Surface Optimization (RSM)",
            "category": "RSM Optimization",
            "description": "Fits full quadratic response surface, identifies stationary points and generates 2D/3D contour predictions.",
            "status": "PASS" if t11_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"RSM R²: {rsm_res['model_summary']['r_squared']:.4f}, Surface: '{rsm_res['nature_of_surface']}', Optimal Y: {rsm_res['optimal_solution']['predicted_optimal_y']:.2f}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T11",
            "name": "Response Surface Optimization (RSM)",
            "category": "RSM Optimization",
            "description": "Fits full quadratic response surface, identifies stationary points and generates 2D/3D contour predictions.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 12. 5 BAD vs 5 GOOD Workflow & Conservative Prioritisation
    t_start = time.perf_counter()
    try:
        bad_rows = [
            {"id": f"B{i}", "Y": 95 + i, "Tool_Wear": 80 + i*2, "Shift": "Shift C"}
            for i in range(1, 6)
        ]
        good_rows = [
            {"id": f"G{i}", "Y": 20 + i, "Tool_Wear": 15 + i*2, "Shift": "Shift A"}
            for i in range(1, 6)
        ]
        comp_res = run_5bad_5good_analysis(
            bad_rows, good_rows, y_col="Y", y_orientation="Higher Y = Worse",
            numeric_x_cols=["Tool_Wear"], categorical_x_cols=["Shift"]
        )
        t12_pass = (
            len(comp_res["candidates"]) == 2 and
            comp_res["candidates"][0]["evidence_strength"] in ["VERY STRONG OBSERVED SEPARATION", "STRONG OBSERVED SEPARATION", "Very Strong", "Strong"] and
            "caution_note" in comp_res["candidates"][0]["confirmation_plan"]
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T12",
            "name": "5 BAD vs 5 GOOD Comparative Prioritization",
            "category": "5 BAD vs 5 GOOD Workflow",
            "description": "Enforces 5 BAD / 5 GOOD selection, conservative evidence labeling, and confirmation planning.",
            "status": "PASS" if t12_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Candidate 1: {comp_res['candidates'][0]['variable']} -> {comp_res['candidates'][0]['evidence_strength']}, Action: {comp_res['candidates'][0]['confirmation_plan']['suggested_action'][:45]}..."
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T12",
            "name": "5 BAD vs 5 GOOD Comparative Prioritization",
            "category": "5 BAD vs 5 GOOD Workflow",
            "description": "Enforces 5 BAD / 5 GOOD selection, conservative evidence labeling, and confirmation planning.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 13. Missing Value Preservation in Validation (Correction 2)
    # X = [10, 20, NaN/None, 40, 50] must remain missing and not converted to 0
    t_start = time.perf_counter()
    try:
        data_with_missing = [
            {"id": "1", "val": 10.0},
            {"id": "2", "val": 20.0},
            {"id": "3", "val": float("nan")},
            {"id": "4", "val": 40.0},
            {"id": "5", "val": 50.0},
        ]
        val_res2 = validate_dataset(data_with_missing)
        val_col = next((c for c in val_res2["columns"] if c["name"] == "val"), None)
        
        # Mean of [10, 20, 40, 50] is 30.0. If NaN were converted to 0, mean would be 24.0 (120/5).
        t13_pass = (
            val_col is not None and
            val_col["missing_count"] == 1 and
            val_col["summary"]["effective_n"] == 4 and
            val_col["zero_count"] == 0 and
            math.isclose(val_col["summary"]["mean"], 30.0, abs_tol=1e-5)
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T13",
            "name": "Missing Value Preservation (No Zero Conversion)",
            "category": "Data Hygiene & Ingestion",
            "description": "X=[10, 20, NaN, 40, 50]: Verifies missing values remain missing, effective_n=4, and mean is 30.0 (NOT 24.0).",
            "status": "PASS" if t13_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Missing count: {val_col['missing_count']}, Effective N: {val_col['summary']['effective_n']}, Zero count: {val_col['zero_count']}, Calculated mean: {val_col['summary']['mean']}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T13",
            "name": "Missing Value Preservation (No Zero Conversion)",
            "category": "Data Hygiene & Ingestion",
            "description": "X=[10, 20, NaN, 40, 50]: Verifies missing values remain missing, effective_n=4, and mean is 30.0 (NOT 24.0).",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 14. Missing Value Handling Across Statistical Functions
    t_start = time.perf_counter()
    try:
        # Pairwise correlation with missing value
        x_m = [10.0, 20.0, None, 40.0, 50.0]
        y_m = [100.0, 200.0, 300.0, 400.0, 500.0]
        p_corr_m = pearson_correlation(x_m, y_m)
        
        # Capability with missing value: [10.0, None, 10.2, 9.8, 10.0]
        cap_m = process_capability_analysis([10.0, None, "NaN", 10.2, 9.8, 10.0], lsl=9.0, usl=11.0)
        
        # 5 Bad vs 5 Good with missing values in X
        bad_with_nan = [
            {"id": "B1", "Y": 100, "X1": 50},
            {"id": "B2", "Y": 102, "X1": None},
            {"id": "B3", "Y": 98, "X1": 52},
            {"id": "B4", "Y": 105, "X1": 49},
            {"id": "B5", "Y": 101, "X1": 51}
        ]
        good_with_nan = [
            {"id": "G1", "Y": 20, "X1": 10},
            {"id": "G2", "Y": 22, "X1": 12},
            {"id": "G3", "Y": 19, "X1": "N/A"},
            {"id": "G4", "Y": 21, "X1": 11},
            {"id": "G5", "Y": 20, "X1": 10}
        ]
        comp_m = run_5bad_5good_analysis(bad_with_nan, good_with_nan, y_col="Y", numeric_x_cols=["X1"])
        cand = next((c for c in comp_m["candidates"] if c["variable"] == "X1"), None)

        t14_pass = (
            p_corr_m["n_used"] == 4 and
            p_corr_m["n_excluded"] == 1 and
            math.isclose(p_corr_m["r"], 1.0, abs_tol=1e-5) and
            cap_m["n_used"] == 4 and
            cap_m["n_excluded"] == 2 and
            cand is not None and
            cand["n_bad_used"] == 4 and
            cand["n_bad_excluded"] == 1 and
            cand["n_good_used"] == 4 and
            cand["n_good_excluded"] == 1
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T14",
            "name": "Missing Value Handling Across Analytics",
            "category": "Statistical Integrity",
            "description": "Verifies correlation, capability, and 5 BAD/5 GOOD exclude missing observations from calculations without 0-imputation.",
            "status": "PASS" if t14_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Correlation N_used: {p_corr_m['n_used']} (r={p_corr_m['r']:.2f}), Capability N_used: {cap_m['n_used']}, 5B5G Bad used: {cand['n_bad_used']}, Good used: {cand['n_good_used']}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T14",
            "name": "Missing Value Handling Across Analytics",
            "category": "Statistical Integrity",
            "description": "Verifies correlation, capability, and 5 BAD/5 GOOD exclude missing observations from calculations without 0-imputation.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 15. Evidence Ranking Test A — False Range Resistance in 5B vs 5G Ranking
    t_start = time.perf_counter()
    try:
        bad_rows_a = [
            {"id": "B1", "Y": 100, "X_FalseRange": 0.0, "X_TrueStrong": 100.0},
            {"id": "B2", "Y": 102, "X_FalseRange": 50.0, "X_TrueStrong": 102.0},
            {"id": "B3", "Y": 98, "X_FalseRange": 50.0, "X_TrueStrong": 104.0},
            {"id": "B4", "Y": 105, "X_FalseRange": 50.0, "X_TrueStrong": 106.0},
            {"id": "B5", "Y": 101, "X_FalseRange": 100.0, "X_TrueStrong": 108.0}
        ]
        good_rows_a = [
            {"id": "G1", "Y": 20, "X_FalseRange": 45.0, "X_TrueStrong": 10.0},
            {"id": "G2", "Y": 22, "X_FalseRange": 48.0, "X_TrueStrong": 12.0},
            {"id": "G3", "Y": 19, "X_FalseRange": 50.0, "X_TrueStrong": 14.0},
            {"id": "G4", "Y": 21, "X_FalseRange": 52.0, "X_TrueStrong": 16.0},
            {"id": "G5", "Y": 20, "X_FalseRange": 55.0, "X_TrueStrong": 18.0}
        ]
        res_a = run_5bad_5good_analysis(bad_rows_a, good_rows_a, y_col="Y", numeric_x_cols=["X_FalseRange", "X_TrueStrong"])
        c_false = next(c for c in res_a["candidates"] if c["variable"] == "X_FalseRange")
        c_true = next(c for c in res_a["candidates"] if c["variable"] == "X_TrueStrong")

        t15_pass = (
            math.isclose(c_false["mean_diff"], 0.0, abs_tol=1e-5) and
            math.isclose(c_false["median_diff"], 0.0, abs_tol=1e-5) and
            math.isclose(c_false["auc"], 0.50, abs_tol=1e-5) and
            c_false["evidence_strength"] == "NO / VERY WEAK OBSERVED SEPARATION" and
            res_a["candidates"][0]["variable"] == "X_TrueStrong" and
            res_a["candidates"][1]["variable"] == "X_FalseRange"
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T15",
            "name": "Evidence Ranking Test A — False Range Resistance",
            "category": "Evidence Prioritisation",
            "description": "BAD=[0,50,50,50,100], GOOD=[45,48,50,52,55]: Verifies mean diff=0, AUC=0.50, Tier=NO / VERY WEAK, ranked below true factors.",
            "status": "PASS" if t15_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"False Range Tier: {c_false['evidence_strength']}, AUC: {c_false['auc']}, Rank position: 2 of 2 (Rank 1: {res_a['candidates'][0]['variable']})"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T15",
            "name": "Evidence Ranking Test A — False Range Resistance",
            "category": "Evidence Prioritisation",
            "description": "BAD=[0,50,50,50,100], GOOD=[45,48,50,52,55]: Verifies mean diff=0, AUC=0.50, Tier=NO / VERY WEAK, ranked below true factors.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 16. Evidence Ranking Test B — Strong True Separation & Concordance
    t_start = time.perf_counter()
    try:
        bad_rows_b = [
            {"id": "B1", "Y": 100, "X_True": 100.0},
            {"id": "B2", "Y": 102, "X_True": 102.0},
            {"id": "B3", "Y": 98, "X_True": 104.0},
            {"id": "B4", "Y": 105, "X_True": 106.0},
            {"id": "B5", "Y": 101, "X_True": 108.0}
        ]
        good_rows_b = [
            {"id": "G1", "Y": 20, "X_True": 10.0},
            {"id": "G2", "Y": 22, "X_True": 12.0},
            {"id": "G3", "Y": 19, "X_True": 14.0},
            {"id": "G4", "Y": 21, "X_True": 16.0},
            {"id": "G5", "Y": 20, "X_True": 18.0}
        ]
        res_b = run_5bad_5good_analysis(bad_rows_b, good_rows_b, y_col="Y", numeric_x_cols=["X_True"])
        c_true_b = res_b["candidates"][0]

        t16_pass = (
            c_true_b["evidence_strength"] == "VERY STRONG OBSERVED SEPARATION" and
            c_true_b["consistency"] == "CONCORDANT" and
            c_true_b["auc"] == 1.0 and
            c_true_b["welch_p"] is not None and c_true_b["welch_p"] < 0.001 and
            c_true_b["mann_whitney_p"] is not None and c_true_b["mann_whitney_p"] <= 0.01
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T16",
            "name": "Evidence Ranking Test B — Strong True Separation",
            "category": "Evidence Prioritisation",
            "description": "BAD=[100..108], GOOD=[10..18]: Verifies large effect size, AUC=1.0, CONCORDANT label, VERY STRONG tier.",
            "status": "PASS" if t16_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Tier: {c_true_b['evidence_strength']}, Consistency: {c_true_b['consistency']}, AUC: {c_true_b['auc']}, Welch p: {c_true_b['welch_p']:.6f}, MW p: {c_true_b['mann_whitney_p']:.6f}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T16",
            "name": "Evidence Ranking Test B — Strong True Separation",
            "category": "Evidence Prioritisation",
            "description": "BAD=[100..108], GOOD=[10..18]: Verifies large effect size, AUC=1.0, CONCORDANT label, VERY STRONG tier.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 17. Evidence Ranking Test C — Identical Distributions
    t_start = time.perf_counter()
    try:
        bad_rows_c = [
            {"id": "B1", "Y": 100, "X_Identical": 10.0},
            {"id": "B2", "Y": 102, "X_Identical": 20.0},
            {"id": "B3", "Y": 98, "X_Identical": 30.0},
            {"id": "B4", "Y": 105, "X_Identical": 40.0},
            {"id": "B5", "Y": 101, "X_Identical": 50.0}
        ]
        good_rows_c = [
            {"id": "G1", "Y": 20, "X_Identical": 10.0},
            {"id": "G2", "Y": 22, "X_Identical": 20.0},
            {"id": "G3", "Y": 19, "X_Identical": 30.0},
            {"id": "G4", "Y": 21, "X_Identical": 40.0},
            {"id": "G5", "Y": 20, "X_Identical": 50.0}
        ]
        res_c = run_5bad_5good_analysis(bad_rows_c, good_rows_c, y_col="Y", numeric_x_cols=["X_Identical"])
        c_iden = res_c["candidates"][0]

        t17_pass = (
            math.isclose(c_iden["mean_diff"], 0.0, abs_tol=1e-5) and
            math.isclose(c_iden["auc"], 0.50, abs_tol=1e-5) and
            c_iden["evidence_strength"] == "NO / VERY WEAK OBSERVED SEPARATION"
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T17",
            "name": "Evidence Ranking Test C — Identical Distributions",
            "category": "Evidence Prioritisation",
            "description": "BAD=[10,20,30,40,50], GOOD=[10,20,30,40,50]: Verifies mean diff=0, AUC=0.50, Cohen's d=0, Tier=NO / VERY WEAK.",
            "status": "PASS" if t17_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Tier: {c_iden['evidence_strength']}, Mean Diff: {c_iden['mean_diff']}, AUC: {c_iden['auc']}, Cohen's d: {c_iden['cohens_d']}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T17",
            "name": "Evidence Ranking Test C — Identical Distributions",
            "category": "Evidence Prioritisation",
            "description": "BAD=[10,20,30,40,50], GOOD=[10,20,30,40,50]: Verifies mean diff=0, AUC=0.50, Cohen's d=0, Tier=NO / VERY WEAK.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 18. Evidence Ranking Test D — Effect Magnitude Prioritisation & P-Value Independence
    t_start = time.perf_counter()
    try:
        # Candidate 1: large effect separation
        # Candidate 2: tiny effect separation
        bad_rows_d = [
            {"id": "B1", "Y": 100, "X_LargeEffect": 50.0, "X_SmallEffect": 10.02},
            {"id": "B2", "Y": 102, "X_LargeEffect": 52.0, "X_SmallEffect": 10.01},
            {"id": "B3", "Y": 98, "X_LargeEffect": 51.0, "X_SmallEffect": 10.03},
            {"id": "B4", "Y": 105, "X_LargeEffect": 53.0, "X_SmallEffect": 10.02},
            {"id": "B5", "Y": 101, "X_LargeEffect": 49.0, "X_SmallEffect": 10.01}
        ]
        good_rows_d = [
            {"id": "G1", "Y": 20, "X_LargeEffect": 10.0, "X_SmallEffect": 10.00},
            {"id": "G2", "Y": 22, "X_LargeEffect": 12.0, "X_SmallEffect": 10.00},
            {"id": "G3", "Y": 19, "X_LargeEffect": 11.0, "X_SmallEffect": 10.00},
            {"id": "G4", "Y": 21, "X_LargeEffect": 9.0, "X_SmallEffect": 10.00},
            {"id": "G5", "Y": 20, "X_LargeEffect": 10.5, "X_SmallEffect": 10.00}
        ]
        res_d = run_5bad_5good_analysis(bad_rows_d, good_rows_d, y_col="Y", numeric_x_cols=["X_SmallEffect", "X_LargeEffect"])
        
        t18_pass = (
            res_d["candidates"][0]["variable"] == "X_LargeEffect" and
            res_d["candidates"][0]["evidence_strength"] in ["VERY STRONG OBSERVED SEPARATION", "STRONG OBSERVED SEPARATION"] and
            res_d["candidates"][1]["variable"] == "X_SmallEffect"
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T18",
            "name": "Evidence Ranking Test D — Effect Magnitude Prioritisation",
            "category": "Evidence Prioritisation",
            "description": "Verifies ranking prioritises effect magnitude and separation over p-values alone without arbitrary composite scores.",
            "status": "PASS" if t18_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Rank 1: {res_d['candidates'][0]['variable']} ({res_d['candidates'][0]['evidence_strength']}), Rank 2: {res_d['candidates'][1]['variable']} ({res_d['candidates'][1]['evidence_strength']})"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T18",
            "name": "Evidence Ranking Test D — Effect Magnitude Prioritisation",
            "category": "Evidence Prioritisation",
            "description": "Verifies ranking prioritises effect magnitude and separation over p-values alone without arbitrary composite scores.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    # 19. Evidence Ranking Test E — Zero Variance in 5B vs 5G Analysis
    t_start = time.perf_counter()
    try:
        bad_rows_e = [{"id": f"B{i}", "Y": 100, "X_ZeroVar": 10.0} for i in range(1, 6)]
        good_rows_e = [{"id": f"G{i}", "Y": 20, "X_ZeroVar": 20.0} for i in range(1, 6)]
        res_e = run_5bad_5good_analysis(bad_rows_e, good_rows_e, y_col="Y", numeric_x_cols=["X_ZeroVar"])
        c_zv = res_e["candidates"][0]

        t19_pass = (
            c_zv["evidence_strength"] == "VERY STRONG OBSERVED SEPARATION" and
            c_zv["welch_t"] is None and
            c_zv["welch_p"] is None and
            c_zv["cohens_d"] is None and
            c_zv["mann_whitney_p"] is not None and
            c_zv["consistency"] == "CONCORDANT" and
            "Complete deterministic separation" in c_zv["welch_note"]
        )
        t_dur = max(0.1, (time.perf_counter() - t_start) * 1000)
        tests.append({
            "id": "T19",
            "name": "Evidence Ranking Test E — Zero Variance Handling",
            "category": "Evidence Prioritisation",
            "description": "BAD=[10]*5, GOOD=[20]*5: Verifies complete deterministic separation note, no fabricated t/p/d, and clean top tiering.",
            "status": "PASS" if t19_pass else "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Tier: {c_zv['evidence_strength']}, Welch Note: '{c_zv['welch_note']}', Welch p: {c_zv['welch_p']}, Cohen's d: {c_zv['cohens_d']}"
        })
    except Exception as e:
        t_dur = (time.perf_counter() - t_start) * 1000
        tests.append({
            "id": "T19",
            "name": "Evidence Ranking Test E — Zero Variance Handling",
            "category": "Evidence Prioritisation",
            "description": "BAD=[10]*5, GOOD=[20]*5: Verifies complete deterministic separation note, no fabricated t/p/d, and clean top tiering.",
            "status": "FAIL",
            "duration_ms": round(t_dur, 2),
            "details": f"Exception: {str(e)}",
            "error": traceback.format_exc()
        })

    return tests

if __name__ == "__main__":
    suite_start = time.perf_counter()
    all_tests = run_all_tests()
    total_duration_ms = (time.perf_counter() - suite_start) * 1000
    passed_count = sum(1 for t in all_tests if t["status"] == "PASS")
    failed_count = len(all_tests) - passed_count
    all_passed = (failed_count == 0)

    if "--json" in sys.argv:
        print(json.dumps({
            "total": len(all_tests),
            "passed": passed_count,
            "failed": failed_count,
            "all_passed": all_passed,
            "overall_status": "PASS" if all_passed else "FAIL",
            "duration_ms": round(total_duration_ms, 2),
            "engine": "Python (test_engine.py)",
            "execution_type": "Real Python Statistical Suite Execution",
            "tests": all_tests
        }, indent=2))
        sys.exit(0 if all_passed else 1)

    print("=" * 70)
    print("KRISHA INNOVATE - DATALOCK PRO: STATISTICAL ENGINE TEST REPORT")
    print("=" * 70)
    for idx, t in enumerate(all_tests, 1):
        print(f"Test #{idx:02d} [{t.get('id', f'T{idx}')}]: [{t['status']}] {t['name']} ({t.get('duration_ms', 0):.2f}ms)")
        print(f"         {t['description']}")
        print(f"         Result: {t['details']}")
        print("-" * 70)
    print(f"SUMMARY: {passed_count}/{len(all_tests)} TESTS PASSED ({total_duration_ms:.2f}ms).")
    print(f"OVERALL STATUS: {'PASS' if all_passed else 'FAIL'}")
    print("=" * 70)
    if not all_passed:
        sys.exit(1)
